# SRI DHARANI MOBILES — POS App
### Setup, Build & Configuration Guide

This file covers everything needed to install, run, build, and configure the app —
plus notes on what each part of the project does. Keep it in the repo root.

---

## 1. What this app is

A fully offline point-of-sale app for a phone/electronics shop, built with:

| Layer         | Technology                                              |
|---------------|-----------------------------------------------------------|
| UI            | React 19 + React Router 7                                 |
| Native shell  | Capacitor 6 (packages the web app as an Android APK)      |
| Storage       | IndexedDB (built into the device — no server, no internet)|
| Printing      | Bluetooth LE ESC/POS thermal printer (58/80mm receipts)   |
| Build tool    | Vite 8                                                     |

Everything runs **on-device**. There is no backend server and no cloud sync —
all sales, products, repairs, and settings live in the phone's local IndexedDB.

---

## 2. Prerequisites

Install these on the computer you'll build from (not needed on the shop's phone):

| Tool                | Version used in this project | Notes                                   |
|---------------------|-------------------------------|------------------------------------------|
| Node.js             | 22.x (18+ also fine)          | https://nodejs.org                        |
| npm                 | comes with Node               |                                            |
| JDK                 | 21 (17+ required by Capacitor)| https://adoptium.net                      |
| Android Studio      | latest stable                 | needed to build/sign the APK              |
| Android SDK         | API 34 (compileSdk/targetSdk) | installed via Android Studio SDK Manager  |
| Capacitor CLI       | 6.x (installed as a dep)      | no separate global install needed         |

Minimum supported Android device: **Android 5.1 (API 22)**, per `minSdkVersion` in
`android/variables.gradle`.

---

## 3. First-time setup

```bash
# 1. Unzip the project, then from the project root:
cd phoneshop-cap

# 2. Install JS dependencies
npm install

# 3. (Android only, first time) let Capacitor confirm the native project is wired up
npx cap sync android
```

`npx cap sync` copies the built web app into `android/app/src/main/assets/public`
and updates native plugin registrations. Run it again any time you change
`capacitor.config.json` or add/remove a Capacitor plugin.

---

## 4. Day-to-day development

### Run in a regular browser (fastest feedback loop)
```bash
npm run dev
```
Opens a Vite dev server. Good for UI work. **Camera scanning, Bluetooth printing,
and the hardware back button won't work in a browser** — those need the Capacitor
native shell (see below). Everything else (cart, inventory, repairs, reports,
settings) works fine in-browser for quick iteration.

### Build + sync + open in Android Studio (to test on a real device/emulator)
```bash
npm run cap:android
```
This runs `vite build` → `npx cap sync` → opens the project in Android Studio.
From Android Studio, press **Run ▶** with a device or emulator selected.

### Build + sync only (no Android Studio launch)
```bash
npm run cap:sync
```

> **Important:** the web app only actually updates on the phone after you run
> `vite build` **and** `npx cap sync`. Editing files under `src/` alone does
> nothing to the installed APK until you rebuild and sync.

---

## 5. Building a release APK (to install on shop phones)

1. `npm run cap:sync`
2. Open `android/` in Android Studio (or `npm run cap:android`)
3. **Build → Generate Signed Bundle / APK**
4. Choose **APK**, create/select a keystore (keep this file + password safe —
   you need the *same* keystore for every future update, or Android will refuse
   to install the update over the old one)
5. Choose **release** build variant
6. The signed APK lands in `android/app/release/app-release.apk` — copy this to
   the phone (via USB, email, or a file-sharing app) and install it directly
   (enable "Install unknown apps" for whichever app you use to open the file).

There is no Play Store listing set up — this is a direct-install (sideloaded) APK.

---

## 6. App identity (already configured)

| Setting              | Where it lives                                              | Current value          |
|-----------------------|--------------------------------------------------------------|-------------------------|
| App/home-screen name  | `android/app/src/main/res/values/strings.xml` (`app_name`)   | SRI DHARANI MOBILES     |
| Package/App ID        | `capacitor.config.json` (`appId`), `android/app/build.gradle`| com.phoneshop.pos       |
| App icon              | `android/app/src/main/res/mipmap-*/ic_launcher*.png`         | cyan phone glyph on navy|
| Splash screen         | `android/app/src/main/res/drawable*/splash.png`               | icon + name + tagline   |
| Splash background     | `capacitor.config.json` → `plugins.SplashScreen.backgroundColor` | #0A0E1A            |
| Splash duration       | `capacitor.config.json` → `plugins.SplashScreen.launchShowDuration` | 1500 ms          |
| Status bar color      | `capacitor.config.json` → `plugins.StatusBar`                | dark style, #0A0E1A    |

**Note on the package ID:** it's still `com.phoneshop.pos` from the original template.
This is fine to keep, but if you ever plan to publish on the Play Store, the
package ID cannot be changed after the first publish — decide before you do.
To change it now: update `appId` in `capacitor.config.json`, `applicationId` and
`namespace` in `android/app/build.gradle`, and the folder path under
`android/app/src/main/java/...`, then run `npx cap sync android`.

### Regenerating the icon/splash art
The current icon is a generic placeholder (no real logo was supplied). It was
generated by a one-off Python/Pillow script — not part of the normal build.
If you get a real logo later, the simplest path is to use an online Capacitor
icon generator (e.g. `@capacitor/assets`) pointed at the new logo, or ask for
the icon/splash to be regenerated from the new artwork.

---

## 7. In-app configuration (no code changes needed)

Once installed, go to **More (bottom tab) → Settings** to configure:

- **Store details** — name, tagline, address, phone, GSTIN, UPI ID (all print on receipts)
- **GST rate** — applied at checkout; can also be overridden per-bill in Cart
- **Low/critical stock thresholds** — drive the Dashboard stock warnings
- **PIN lock** — 4-digit PIN required at app launch (see note below)
- **Theme** — dark/light toggle and brand accent color
- **Bluetooth printer** — scan, pair, and remember up to 10 printers; set paper width (58/80mm etc.)
- **Backup** — export all data (products, categories, invoices, repairs, settings) as JSON
- **Reset** — wipe sales only, or a full factory reset (also stops demo-data reseeding)

> **PIN lock note (carried over from the code review):** the PIN is stored in
> plain text locally and only checked once at app launch, not on resume from
> background. Treat it as a light deterrent (e.g. keeping curious customers out),
> not as real security for the device.

---

## 8. Project structure (quick map)

```
phoneshop-cap/
├── src/
│   ├── App.jsx              # Root component: routing, tab bar, PIN gate, theme/init
│   ├── main.jsx              # React entry point
│   ├── index.css             # Global styles & CSS variables (theme colors, spacing)
│   ├── state/context.jsx     # Cart state + Theme state (React Context)
│   ├── db/database.js        # ALL data access — IndexedDB schema, CRUD, invoices, backup
│   ├── printer/bluetooth.js  # BLE connection + ESC/POS receipt formatting/printing
│   ├── components/
│   │   └── BluetoothPrinterModal.jsx
│   └── screens/               # One file per app screen (Dashboard, Cart, Products, etc.)
├── android/                   # Native Android project (Capacitor-managed)
│   └── app/src/main/res/      # Icons, splash images, strings.xml
├── www/                       # Built web output (regenerated by `vite build`)
├── capacitor.config.json      # App ID, name, splash/status-bar config
├── vite.config.js
└── package.json
```

---

## 9. Known limitations worth knowing about (from the earlier code review)

These aren't blockers, just things to keep in mind or revisit later:

- **Checkout isn't fully atomic** — an invoice, its line items, and stock
  decrements are written in separate transactions. A crash mid-checkout could
  leave things slightly out of sync (rare in practice).
- **Barcode scanning** relies on the browser's `BarcodeDetector` API, which
  isn't available on every Android device/WebView version. On unsupported
  phones, scanning won't work and there's currently no manual-entry fallback
  on that screen (search-by-name/barcode in Cart still works, though).
- **Receipt printing uses UTF-8 text**, including the ₹ symbol. Most ESC/POS
  thermal printers use single-byte codepages and may not render ₹ correctly —
  worth test-printing on your actual printer model.

---

## 10. Quick command reference

```bash
npm install          # install dependencies
npm run dev           # browser dev server
npm run build          # production web build → www/
npm run cap:sync        # build + copy into Android project
npm run cap:android      # build + sync + open Android Studio
```
