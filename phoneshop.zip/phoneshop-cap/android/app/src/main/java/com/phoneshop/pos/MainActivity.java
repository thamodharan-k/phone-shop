package com.phoneshop.pos;

import android.os.Bundle;
import android.webkit.WebView;

import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // This app fully manages its own dark/light theme via CSS variables.
        // Android's WebView "Force Dark" heuristic can still repaint form
        // controls on top of that (a common cause of typed text becoming
        // invisible, e.g. white-on-white in input boxes), so it's switched
        // off here — the app's own CSS is the single source of truth for colors.
        WebView webView = getBridge().getWebView();
        if (webView != null && WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(webView.getSettings(), WebSettingsCompat.FORCE_DARK_OFF);
        }
    }
}
