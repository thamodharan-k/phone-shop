import { useEffect, useRef, useState } from 'react';
import { registerToastListener } from '../utils/toast.js';

const DEFAULT_DURATION_MS = 2200;

export default function ToastHost() {
  const [toast, setToast] = useState(null); // { message, tone }
  const timerRef = useRef(null);

  useEffect(() => {
    const off = registerToastListener((message, opts = {}) => {
      if (timerRef.current) clearTimeout(timerRef.current);
      setToast({ message, tone: opts.tone || 'success' });
      timerRef.current = setTimeout(() => setToast(null), opts.duration || DEFAULT_DURATION_MS);
    });
    return () => {
      off();
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  if (!toast) return null;

  const isSuccess = toast.tone === 'success';

  return (
    <div style={{
      position:'fixed', left:'50%', transform:'translateX(-50%)',
      bottom:`calc(var(--tab-height) + var(--safe-bottom) + 14px)`,
      display:'flex', alignItems:'center', gap:8,
      background:'var(--surface-inverse)', color:'var(--on-surface-inverse)',
      padding:'10px 20px', borderRadius:'var(--radius-pill)',
      fontSize:13, fontWeight:700, whiteSpace:'nowrap',
      boxShadow:'0 6px 20px rgba(0,0,0,0.3)', zIndex:600,
      animation:'fadeIn 0.15s ease',
    }}>
      {isSuccess && (
        <svg width={15} height={15} viewBox="0 0 24 24" fill="none" stroke="var(--success)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10" fill="var(--success)" opacity="0.18"/>
          <polyline points="7 12.5 10.5 16 17 8.5"/>
        </svg>
      )}
      {toast.message}
    </div>
  );
}
