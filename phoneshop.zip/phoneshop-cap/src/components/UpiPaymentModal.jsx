import { formatCurrency } from '../db/database.js';
import { useSheetOpen } from '../utils/sheetRegistry.js';

/**
 * Shown when the cashier selects UPI/GPay as the payment method — displays
 * the merchant's configured UPI ID and QR code so the customer can scan and
 * pay, then requires an explicit confirmation before the bill is finalized.
 */
export default function UpiPaymentModal({ amount, upiId, qrImage, busy, onConfirm, onClose }) {
  useSheetOpen(true);
  const configured = !!(upiId || qrImage);

  return (
    <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.8)', zIndex:600, display:'flex', alignItems:'center', justifyContent:'center', padding:'var(--space-lg)' }}>
      <div style={{ background:'var(--surface-elevated)', borderRadius:'var(--radius-xl)', maxWidth:360, width:'100%', overflow:'hidden', boxShadow:'0 20px 60px rgba(0,0,0,0.5)' }}>
        <div style={{ padding:'var(--space-lg)', textAlign:'center', borderBottom:'1.5px solid var(--border)' }}>
          <div style={{ fontSize:16, fontWeight:800, color:'var(--on-surface)' }}>Scan to Pay via UPI</div>
          <div style={{ color:'var(--brand)', fontWeight:900, fontSize:28, marginTop:6 }}>{formatCurrency(amount)}</div>
        </div>

        <div style={{ padding:'var(--space-lg)', display:'flex', flexDirection:'column', alignItems:'center', gap:'var(--space-md)' }}>
          {configured ? (
            <>
              {qrImage ? (
                <div style={{ background:'#fff', padding:12, borderRadius:'var(--radius-lg)' }}>
                  <img src={qrImage} alt="UPI QR Code" style={{ width:200, height:200, objectFit:'contain', display:'block' }} />
                </div>
              ) : (
                <div style={{ width:200, height:200, borderRadius:'var(--radius-lg)', background:'var(--surface-tertiary)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--muted)', fontSize:13, textAlign:'center', padding:'var(--space-md)' }}>
                  No QR image uploaded — ask the customer to pay using the UPI ID below.
                </div>
              )}
              {upiId && (
                <div style={{ textAlign:'center' }}>
                  <div style={{ color:'var(--muted)', fontSize:11, fontWeight:700, letterSpacing:0.5 }}>UPI ID</div>
                  <div style={{ color:'var(--on-surface)', fontWeight:800, fontSize:16, marginTop:2 }}>{upiId}</div>
                </div>
              )}
            </>
          ) : (
            <div style={{ textAlign:'center', color:'var(--muted)', fontSize:13, lineHeight:1.6 }}>
              No UPI ID or QR code configured yet.<br/>
              Add them in <strong>Settings → Billing</strong> so this screen can show them automatically next time.
            </div>
          )}
        </div>

        <div style={{ padding:'var(--space-lg)', paddingTop:0, display:'flex', flexDirection:'column', gap:8 }}>
          <button
            onClick={onConfirm}
            disabled={busy}
            style={{
              width:'100%', padding:15, borderRadius:'var(--radius-lg)',
              background:'var(--success)', border:'none', cursor:'pointer',
              color:'#04220F', fontWeight:800, fontFamily:'var(--font)', fontSize:15,
              display:'flex', alignItems:'center', justifyContent:'center', gap:8,
              opacity: busy ? 0.6 : 1,
            }}>
            {busy ? 'Saving…' : (<><svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg> Payment Received</>)}
          </button>
          <button
            onClick={onClose}
            disabled={busy}
            style={{
              width:'100%', padding:13, borderRadius:'var(--radius-lg)',
              background:'transparent', border:'1.5px solid var(--border-strong)', cursor:'pointer',
              color:'var(--muted)', fontWeight:700, fontFamily:'var(--font)', fontSize:14,
            }}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
