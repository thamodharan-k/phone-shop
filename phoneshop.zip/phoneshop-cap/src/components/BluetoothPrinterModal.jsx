import { useState, useCallback, useEffect } from 'react';
import { createPortal } from 'react-dom';
import * as BT from '../printer/bluetooth.js';
import { listKnownPrinters, removeKnownPrinter } from '../db/database.js';
import { useSheetOpen } from '../utils/sheetRegistry.js';

export default function BluetoothPrinterModal({ onClose, onConnected, activeAddress }) {
  useSheetOpen(true);
  const [phase, setPhase]   = useState('idle'); // idle | enabling | scanning | connecting
  const [devices, setDevices] = useState([]);   // freshly scanned (nearby)
  const [known, setKnown]   = useState([]);     // previously paired/connected
  const [connectingAddr, setConnectingAddr] = useState(null);
  const [error, setError]   = useState(null);
  const [radioOn, setRadioOn] = useState(true);

  // Load known printers + radio state on open
  useEffect(() => {
    (async () => {
      setKnown(await listKnownPrinters());
      setRadioOn(await BT.isRadioEnabled());
    })();
  }, []);

  const scan = useCallback(async () => {
    setError(null); setDevices([]); setPhase('enabling');
    const { ok, reason } = await BT.ensureEnabled();
    if (!ok) { setError(reason || 'Bluetooth unavailable.'); setPhase('idle'); return; }
    setRadioOn(true);

    // NOTE: this app initializes BLE with androidNeverForLocation:true, which
    // means it never derives physical location from scan results — so on
    // Android 12+ (API 31+) it does NOT need Location Services to be on at
    // all, and previously blocking the scan on isLocationEnabled() here was
    // actively wrong (it also proved unreliable on some OEM builds, reporting
    // "off" even when the user had confirmed Location was on). Location is
    // only relevant as a possible cause on older Android versions, so it's
    // now surfaced as a hint if a scan comes back empty, not a hard gate.
    setPhase('scanning');
    try {
      // Stream every device in as it's discovered, so the list fills up live
      // instead of appearing all at once after the scan window closes.
      const { found } = await BT.scanDevices((d) => {
        setDevices(prev => {
          if (prev.some(x => x.address === d.address)) return prev;
          if (known.some(k => k.address === d.address)) return prev; // already shown under Paired
          return [...prev, d];
        });
      });
      if (found.length === 0) {
        const locationOn = await BT.isLocationEnabled();
        setError(
          locationOn
            ? 'No devices found. Make sure your printer is powered on and in range, then try again.'
            : 'No devices found. Power on your printer and try again — on some Android versions, also make sure Location Services is on.'
        );
      }
    } catch (e) {
      setError(e?.message || 'Scan failed.');
    } finally {
      setPhase('idle');
    }
  }, [known]);

  const connectDevice = useCallback(async (device) => {
    setConnectingAddr(device.address); setPhase('connecting'); setError(null);
    try {
      await BT.connect(device.address);
      await onConnected(device.name, device.address);
      onClose();
    } catch (e) {
      setError(`Could not connect: ${e?.message || 'Try again.'}`);
    } finally {
      setPhase('idle'); setConnectingAddr(null);
    }
  }, [onConnected, onClose]);

  const forgetDevice = async (address, e) => {
    e.stopPropagation();
    if (!confirm('Remove this printer from your saved list?')) return;
    await removeKnownPrinter(address);
    setKnown(await listKnownPrinters());
  };

  const toggleRadio = async () => {
    setPhase('enabling');
    const next = !radioOn;
    const { ok, reason } = await BT.setRadioEnabled(next);
    if (ok) setRadioOn(next);
    else if (reason) setError(reason);
    setPhase('idle');
  };

  const busy = phase !== 'idle';
  const phaseLabel = { idle:'', enabling:'Working…', scanning:'Scanning for printers…', connecting:'Connecting…' }[phase];

  const DeviceRow = ({ d, section }) => {
    const isActive = activeAddress === d.address;
    const isConnecting = connectingAddr === d.address && phase === 'connecting';
    return (
      <div onClick={() => !busy && connectDevice(d)} style={{
        display:'flex', alignItems:'center', gap:'var(--space-md)',
        padding:'var(--space-md) 4px', cursor: busy ? 'not-allowed' : 'pointer',
      }}>
        <div style={{
          width:40, height:40, borderRadius:20,
          background: isActive ? 'var(--success-soft)' : 'var(--brand-soft)',
          display:'flex', alignItems:'center', justifyContent:'center', fontSize:18, flexShrink:0,
        }}>🖨️</div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:6 }}>
            <span style={{ color:'var(--on-surface)', fontWeight:700, fontSize:14 }}>{d.name || 'Unknown Device'}</span>
            {isActive && (
              <span style={{ background:'var(--success-soft)', color:'var(--success)', fontSize:9, fontWeight:800, padding:'2px 7px', borderRadius:999 }}>CONNECTED</span>
            )}
          </div>
          <div style={{ color:'var(--muted)', fontSize:11, marginTop:2 }}>{d.address} · {section}</div>
        </div>
        {section === 'Paired' && !isActive && (
          <button onClick={(e) => forgetDevice(d.address, e)} title="Forget"
            style={{ width:28, height:28, borderRadius:8, background:'var(--error-soft)', border:'1px solid var(--error)44', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
            <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="var(--error)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
            </svg>
          </button>
        )}
        {isConnecting
          ? <div style={{ width:16, height:16, borderRadius:8, border:'2px solid var(--brand)', borderTopColor:'transparent', animation:'spin 0.8s linear infinite' }} />
          : <span style={{ color:'var(--muted)', fontSize:18 }}>›</span>}
      </div>
    );
  };

  return createPortal(
    <div className="modal-overlay" onClick={onClose}>
      <div
        className="modal-sheet"
        onClick={e => e.stopPropagation()}
        style={{ display:'flex', flexDirection:'column', maxHeight:'85vh', padding:0, overflow:'hidden' }}
      >
        {/* Fixed header */}
        <div style={{ padding:'var(--space-md) var(--space-xl) 0' }}>
          <div className="modal-handle" />
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:'var(--space-md)' }}>
            <div>
              <div style={{ fontSize:18, fontWeight:800, color:'var(--on-surface)' }}>Bluetooth Printer</div>
              <div style={{ fontSize:12, color:'var(--muted)', marginTop:2 }}>Manage your thermal printer connection</div>
            </div>
            <button onClick={onClose} className="icon-btn">✕</button>
          </div>
        </div>

        {/* Scrollable middle — everything except the header and the Scan button */}
        <div className="scroll" style={{ flex:1, minHeight:0, overflowY:'auto', padding:'0 var(--space-xl)' }}>
          {/* Bluetooth radio ON/OFF */}
          <div style={{
            display:'flex', alignItems:'center', justifyContent:'space-between',
            padding:'var(--space-md)', background:'var(--surface-tertiary)',
            borderRadius:'var(--radius-md)', marginBottom:'var(--space-md)',
          }}>
            <div style={{ display:'flex', alignItems:'center', gap:10 }}>
              <span style={{ fontSize:18 }}>{radioOn ? '🔵' : '⚪'}</span>
              <div>
                <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:14 }}>Bluetooth</div>
                <div style={{ color:'var(--muted)', fontSize:11 }}>{radioOn ? 'On' : 'Off'}</div>
              </div>
            </div>
            <div onClick={toggleRadio} style={{
              width:48, height:28, borderRadius:14,
              background: radioOn ? 'var(--brand)' : 'var(--border-strong)',
              position:'relative', cursor: busy ? 'default' : 'pointer',
              transition:'background 0.2s', opacity: busy ? 0.6 : 1,
            }}>
              <div style={{
                width:22, height:22, borderRadius:11, background:'#fff',
                position:'absolute', top:3, left: radioOn ? 23 : 3,
                transition:'left 0.2s', boxShadow:'0 1px 4px rgba(0,0,0,0.3)',
              }} />
            </div>
          </div>

          {busy && (
            <div style={{ display:'flex', alignItems:'center', gap:10, background:'var(--brand-soft)', borderRadius:'var(--radius-md)', padding:'var(--space-md)', marginBottom:'var(--space-md)' }}>
              <div style={{ width:16, height:16, borderRadius:8, border:'2px solid var(--brand)', borderTopColor:'transparent', animation:'spin 0.8s linear infinite', flexShrink:0 }} />
              <span style={{ color:'var(--brand)', fontWeight:600, fontSize:13 }}>{phaseLabel}</span>
            </div>
          )}

          {error && !busy && (
            <div style={{ background:'var(--error-soft)', borderRadius:'var(--radius-md)', padding:'var(--space-md)', marginBottom:'var(--space-md)', color:'var(--error)', fontSize:13, lineHeight:1.6 }}>
              ⚠️ {error}
            </div>
          )}

          {/* Paired / known devices */}
          {known.length > 0 && (
            <>
              <div style={{ fontSize:11, fontWeight:700, color:'var(--muted)', letterSpacing:0.5, marginBottom:4 }}>
                PAIRED DEVICES
              </div>
              <div style={{ marginBottom:'var(--space-md)' }}>
                {known.map((d, i) => (
                  <div key={d.address} style={{ borderBottom: i < known.length-1 ? '1px solid var(--divider)' : 'none' }}>
                    <DeviceRow d={d} section="Paired" />
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Newly scanned nearby devices */}
          {devices.length > 0 && (
            <>
              <div style={{ fontSize:11, fontWeight:700, color:'var(--muted)', letterSpacing:0.5, marginBottom:4 }}>
                NEARBY DEVICES
              </div>
              <div style={{ marginBottom:'var(--space-md)' }}>
                {devices.map((d, i) => (
                  <div key={d.address} style={{ borderBottom: i < devices.length-1 ? '1px solid var(--divider)' : 'none' }}>
                    <DeviceRow d={d} section="Nearby" />
                  </div>
                ))}
              </div>
            </>
          )}

          {!busy && known.length === 0 && devices.length === 0 && !error && (
            <div style={{ display:'flex', flexDirection:'column', gap:6, marginBottom:'var(--space-md)', padding:'var(--space-md)', background:'var(--surface-tertiary)', borderRadius:'var(--radius-md)' }}>
              {['Power on your thermal printer first', 'Keep printer within 5 metres', 'Android 12+ needs Nearby Devices permission'].map(t => (
                <div key={t} style={{ display:'flex', alignItems:'center', gap:8, color:'var(--muted)', fontSize:13 }}><span>ℹ️</span>{t}</div>
              ))}
            </div>
          )}
          <div style={{ height:12 }} />
        </div>

        {/* Pinned footer — always visible, never scrolls out of view */}
        <div style={{ padding:'var(--space-md) var(--space-xl)', paddingBottom:'calc(var(--space-md) + var(--safe-bottom))', borderTop:'1px solid var(--border)', flexShrink:0 }}>
          <button className="btn-primary" style={{ width:'100%' }} onClick={scan} disabled={busy}>
            {busy ? phaseLabel : (known.length > 0 || devices.length > 0) ? '🔄 Scan for New Printers' : '🔍 Scan for Printers'}
          </button>
        </div>

        <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      </div>
    </div>,
    document.body
  );
}
