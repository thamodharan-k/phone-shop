/**
 * SRI DHARANI MOBILES — Offline POS Database
 * Uses IndexedDB via idb-keyval pattern for offline-first storage.
 * Compatible with Capacitor WebView on Android.
 */

const DB_NAME = 'phoneshop_pos';
const DB_VERSION = 1;
let _db = null;

// Timestamp + random suffix — avoids two records silently colliding (and one
// overwriting the other in IndexedDB) if created within the same millisecond.
const uid = (prefix) => `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

// ─── Open DB ─────────────────────────────────────────────────────────────────
export const openDb = () =>
  new Promise((resolve, reject) => {
    if (_db) return resolve(_db);
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => { _db = req.result; resolve(_db); };
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      // categories
      if (!db.objectStoreNames.contains('categories')) {
        const cs = db.createObjectStore('categories', { keyPath: 'id' });
        cs.createIndex('name', 'name', { unique: true });
      }
      // products
      if (!db.objectStoreNames.contains('products')) {
        const ps = db.createObjectStore('products', { keyPath: 'id' });
        ps.createIndex('barcode', 'barcode', { unique: false });
        ps.createIndex('category_id', 'category_id');
      }
      // invoices
      if (!db.objectStoreNames.contains('invoices')) {
        const is = db.createObjectStore('invoices', { keyPath: 'id' });
        is.createIndex('created_at', 'created_at');
      }
      // invoice_items
      if (!db.objectStoreNames.contains('invoice_items')) {
        const ii = db.createObjectStore('invoice_items', { keyPath: 'id' });
        ii.createIndex('invoice_id', 'invoice_id');
      }
      // repair_tickets
      if (!db.objectStoreNames.contains('repair_tickets')) {
        const rt = db.createObjectStore('repair_tickets', { keyPath: 'id' });
        rt.createIndex('status', 'status');
        rt.createIndex('created_at', 'created_at');
      }
      // settings
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' });
      }
    };
  });

// ─── Generic helpers ──────────────────────────────────────────────────────────
const tx = async (store, mode, fn) => {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction(store, mode);
    const s = t.objectStore(store);
    const req = fn(s);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
};

const getAll = async (store, indexName, value) => {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction(store, 'readonly');
    const s = t.objectStore(store);
    const req = indexName ? s.index(indexName).getAll(value) : s.getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
};

// ─── Settings ─────────────────────────────────────────────────────────────────
export const getSetting = async (key) => {
  try {
    const row = await tx('settings', 'readonly', s => s.get(key));
    return row?.value ?? null;
  } catch { return null; }
};

export const setSetting = async (key, value) => {
  await tx('settings', 'readwrite', s => s.put({ key, value }));
};

export const getAllSettings = async () => {
  const rows = await getAll('settings');
  const map = {};
  rows.forEach(r => map[r.key] = r.value);
  return map;
};

// ─── Known Bluetooth Printers ───────────────────────────────────────────────
// Remembers every printer the user has ever connected to, so they can
// switch between previously-paired printers without rescanning.
export const listKnownPrinters = async () => {
  const raw = await getSetting('bt_known_printers');
  try { return JSON.parse(raw || '[]'); } catch (_) { return []; }
};

export const addKnownPrinter = async (name, address) => {
  const list = await listKnownPrinters();
  const filtered = list.filter(d => d.address !== address);
  filtered.unshift({ name, address, last_used: Date.now() });
  // keep at most 10 remembered printers
  await setSetting('bt_known_printers', JSON.stringify(filtered.slice(0, 10)));
};

export const removeKnownPrinter = async (address) => {
  const list = await listKnownPrinters();
  await setSetting('bt_known_printers', JSON.stringify(list.filter(d => d.address !== address)));
};

// ─── Init / Seed ──────────────────────────────────────────────────────────────
export const initDb = async () => {
  await openDb();

  // After a factory reset, never auto-seed again — app stays blank
  // until the user manually adds their own data.
  let wasFactoryReset = false;
  try { wasFactoryReset = localStorage.getItem('phoneshop_factory_reset') === '1'; } catch (_) {}

  const existing = await getSetting('store_name');
  if (!existing && !wasFactoryReset) {
    const defaults = [
      ['store_name',    'SRI DHARANI MOBILES'],
      ['store_tagline', 'Phones · Accessories · Repairs'],
      ['store_address', 'Shop 12, Tech Plaza, Bengaluru'],
      ['store_phone',   '+91 98765 43210'],
      ['gst_number',    '29ABCDE1234F1Z5'],
      ['gst_rate',      '0'],
      ['upi_id',        'phoneshop@upi'],
      ['thank_you_msg', 'Thank you for shopping with us!'],
      ['return_policy', 'Devices: 7-day replacement. Accessories: 24hr only.'],
      ['critical_stock','2'],
      ['low_stock',     '5'],
      ['critical_stock_alert_enabled','1'],
      ['low_stock_alert_enabled','1'],
      ['upi_qr_print_enabled','1'],
      ['pin_enabled',   '0'],
      ['pin_code',      ''],
      ['invoice_counter','0'],
      ['repair_counter', '0'],
      ['bt_printer_name',''],
      ['bt_printer_address',''],
      ['bt_known_printers','[]'],
      ['paper_width','57'],
      ['dark_mode',     '1'],
      ['theme_color',   '#00E5FF'],
    ];
    for (const [key, value] of defaults) await setSetting(key, value);
  } else if (!existing && wasFactoryReset) {
    // Still need minimal settings to exist so the app doesn't crash —
    // but with neutral/blank values, no demo data.
    const blank = [
      ['store_name', ''], ['store_tagline', ''], ['store_address', ''],
      ['store_phone', ''], ['gst_number', ''], ['gst_rate', '0'],
      ['upi_id', ''], ['thank_you_msg', ''], ['return_policy', ''],
      ['critical_stock', '2'], ['low_stock', '5'],
      ['critical_stock_alert_enabled', '1'], ['low_stock_alert_enabled', '1'],
      ['upi_qr_print_enabled', '1'],
      ['pin_enabled', '0'], ['pin_code', ''],
      ['invoice_counter', '0'], ['repair_counter', '0'],
      ['bt_printer_name', ''], ['bt_printer_address', ''], ['bt_known_printers', '[]'], ['paper_width', '57'],
      ['dark_mode', '1'], ['theme_color', '#00E5FF'],
    ];
    for (const [key, value] of blank) await setSetting(key, value);
  }

  // Seed categories & products ONLY if never factory-reset
  const cats = await getAll('categories');
  if (cats.length === 0 && !wasFactoryReset) {
    const now = Date.now();
    const categories = [
      { id: 'cat_phone',       name: 'Smartphones',     icon: '📱' },
      { id: 'cat_acc',         name: 'Accessories',     icon: '🔌' },
      { id: 'cat_audio',       name: 'Audio',           icon: '🎧' },
      { id: 'cat_power',       name: 'Power & Charging',icon: '🔋' },
      { id: 'cat_case',        name: 'Cases & Covers',  icon: '🛡️' },
      { id: 'cat_tablet',      name: 'Tablets',         icon: '📲' },
      { id: 'cat_smartwatch',  name: 'Smartwatches',    icon: '⌚' },
    ];
    for (const c of categories)
      await tx('categories', 'readwrite', s => s.put({ ...c, created_at: now }));

    const products = [
      { name: 'iPhone 15 128GB Black',    barcode: '8901501000001', cat: 'cat_phone', price: 74900, stock: 6 },
      { name: 'iPhone 15 Pro 256GB',      barcode: '8901501000002', cat: 'cat_phone', price: 134900,stock: 3 },
      { name: 'Samsung Galaxy S24 256GB', barcode: '8901501000003', cat: 'cat_phone', price: 79999, stock: 8 },
      { name: 'Google Pixel 8 128GB',     barcode: '8901501000004', cat: 'cat_phone', price: 69999, stock: 4 },
      { name: 'OnePlus Nord CE 4 128GB',  barcode: '8901501000005', cat: 'cat_phone', price: 24999, stock: 12 },
      { name: 'Redmi Note 13 Pro 5G',     barcode: '8901501000016', cat: 'cat_phone', price: 27999, stock: 10 },
      { name: 'AirPods Pro (2nd Gen)',     barcode: '8901501000006', cat: 'cat_audio', price: 24900, stock: 9 },
      { name: 'Samsung Galaxy Buds 2 Pro',barcode: '8901501000007', cat: 'cat_audio', price: 17999, stock: 7 },
      { name: 'JBL Tune 510BT',           barcode: '8901501000008', cat: 'cat_audio', price: 2999,  stock: 18 },
      { name: 'boAt Rockerz 450',         barcode: '8901501000017', cat: 'cat_audio', price: 1499,  stock: 25 },
      { name: '20W USB-C Fast Charger',   barcode: '8901501000009', cat: 'cat_power', price: 1499,  stock: 32 },
      { name: '20000mAh Power Bank',      barcode: '8901501000010', cat: 'cat_power', price: 2499,  stock: 14 },
      { name: '65W GaN Wall Charger',     barcode: '8901501000018', cat: 'cat_power', price: 2199,  stock: 20 },
      { name: 'USB-C to Lightning Cable', barcode: '8901501000011', cat: 'cat_acc',   price: 999,   stock: 45 },
      { name: 'Tempered Glass Guard',     barcode: '8901501000012', cat: 'cat_acc',   price: 299,   stock: 80 },
      { name: 'MagSafe Car Mount',        barcode: '8901501000015', cat: 'cat_acc',   price: 1799,  stock: 5 },
      { name: 'OTG Adapter USB-C',        barcode: '8901501000019', cat: 'cat_acc',   price: 349,   stock: 60 },
      { name: 'iPhone 15 Silicone Case',  barcode: '8901501000013', cat: 'cat_case',  price: 899,   stock: 22 },
      { name: 'Samsung S24 Clear Cover',  barcode: '8901501000014', cat: 'cat_case',  price: 599,   stock: 17 },
      { name: 'Spigen Rugged Case',       barcode: '8901501000020', cat: 'cat_case',  price: 1199,  stock: 14 },
      { name: 'iPad 10th Gen 64GB Wi-Fi', barcode: '8901501000021', cat: 'cat_tablet',price: 44900, stock: 3 },
      { name: 'Samsung Galaxy Tab A9+',   barcode: '8901501000022', cat: 'cat_tablet',price: 27999, stock: 4 },
      { name: 'Apple Watch Series 9 41mm',barcode: '8901501000023', cat: 'cat_smartwatch',price:41900,stock:2},
      { name: 'Samsung Galaxy Watch 6',   barcode: '8901501000024', cat: 'cat_smartwatch',price:26999,stock:5},
    ];
    for (const p of products) {
      await tx('products', 'readwrite', s => s.put({
        id: `p_${p.barcode}`, name: p.name, barcode: p.barcode,
        category_id: p.cat, price: p.price, stock: p.stock,
        size: null, location: null, created_at: now, updated_at: now,
      }));
    }
  }
};

// ─── Categories ───────────────────────────────────────────────────────────────
export const listCategories = async () => {
  const rows = await getAll('categories');
  return rows.sort((a, b) => a.name.localeCompare(b.name));
};

export const addCategory = async (name, icon = 'pricetag', image_uri = null) => {
  const id = uid('cat');
  await tx('categories', 'readwrite', s => s.put({ id, name: name.trim(), icon, image_uri, created_at: Date.now() }));
  return id;
};

export const updateCategory = async (id, name, icon, image_uri = null) => {
  const existing = await tx('categories', 'readonly', s => s.get(id));
  if (!existing) throw new Error('Not found');
  await tx('categories', 'readwrite', s => s.put({ ...existing, name: name.trim(), icon, image_uri }));
};

export const deleteCategory = async (id) => {
  // Cascade: delete all products in this category
  const prods = await getAll('products', 'category_id', id);
  for (const p of prods) await tx('products', 'readwrite', s => s.delete(p.id));
  await tx('categories', 'readwrite', s => s.delete(id));
};

export const getCategoryProductCount = async (id) => {
  const prods = await getAll('products', 'category_id', id);
  return prods.length;
};

// ─── Products ─────────────────────────────────────────────────────────────────
export const listProducts = async (categoryId = null) => {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction(['products', 'categories'], 'readonly');
    const ps = t.objectStore('products');
    const cs = t.objectStore('categories');
    const req = categoryId ? ps.index('category_id').getAll(categoryId) : ps.getAll();
    req.onsuccess = async () => {
      const products = req.result;
      // Join category names
      const catMap = {};
      const allCats = await new Promise(res => { const r = cs.getAll(); r.onsuccess = () => res(r.result); });
      allCats.forEach(c => catMap[c.id] = c.name);
      resolve(products.map(p => ({ ...p, category_name: catMap[p.category_id] || null })).sort((a,b) => a.name.localeCompare(b.name)));
    };
    req.onerror = () => reject(req.error);
  });
};

export const getProductByBarcode = async (barcode) => {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction('products', 'readonly');
    const req = t.objectStore('products').index('barcode').getAll(barcode);
    req.onsuccess = () => resolve(req.result[0] || null);
    req.onerror = () => reject(req.error);
  });
};

export const addProduct = async (p) => {
  if (p.barcode) {
    const dup = await getProductByBarcode(p.barcode);
    if (dup) throw new Error('A product with this barcode already exists.');
  }
  const id = uid('p');
  const now = Date.now();
  await tx('products', 'readwrite', s => s.put({ id, ...p, created_at: now, updated_at: now }));
  return id;
};

export const updateProduct = async (id, patch) => {
  const existing = await tx('products', 'readonly', s => s.get(id));
  if (!existing) throw new Error('Product not found');
  await tx('products', 'readwrite', s => s.put({ ...existing, ...patch, updated_at: Date.now() }));
};

export const deleteProduct = async (id) => {
  await tx('products', 'readwrite', s => s.delete(id));
};

export const decrementStock = async (productId, qty) => {
  const p = await tx('products', 'readonly', s => s.get(productId));
  if (p) await tx('products', 'readwrite', s => s.put({ ...p, stock: Math.max(0, p.stock - qty), updated_at: Date.now() }));
};

// ─── Invoices ─────────────────────────────────────────────────────────────────
const pad = n => String(n).padStart(4, '0');

export const createInvoice = async (items, meta) => {
  const counter = parseInt(await getSetting('invoice_counter') || '0', 10) + 1;
  await setSetting('invoice_counter', String(counter));

  const invoice_no = `INV-${pad(counter)}`;
  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
  const afterDiscount = Math.max(0, subtotal - (meta.discount_amount || 0));
  const gst_amount = parseFloat((afterDiscount * ((meta.gst_rate || 0) / 100)).toFixed(2));
  const total = parseFloat((afterDiscount + gst_amount).toFixed(2));
  const id = uid('inv');
  const now = Date.now();

  // Credit bills start UNPAID with ₹0 collected.
  // Cash / UPI / Card are always fully paid at the time of billing.
  const isCredit = meta.payment_mode === 'Credit';
  const paid_amount = isCredit ? 0 : total;
  const paid = isCredit ? 0 : 1;

  await tx('invoices', 'readwrite', s => s.put({
    id, invoice_no,
    customer_name: meta.customer_name || null,
    customer_phone: meta.customer_phone || null,
    subtotal, gst_amount,
    discount_amount: meta.discount_amount || 0,
    total, payment_mode: meta.payment_mode,
    paid,
    paid_amount,
    created_at: now,
  }));

  for (const it of items) {
    await tx('invoice_items', 'readwrite', s => s.put({
      id: `iit_${Date.now()}_${Math.random().toString(36).slice(2,6)}`,
      invoice_id: id,
      product_id: it.product_id,
      name: it.name, price: it.price, qty: it.qty,
      amount: it.price * it.qty,
    }));
    await decrementStock(it.product_id, it.qty);
  }

  return { id, invoice_no, subtotal, gst_amount, total, items, created_at: now };
};

/**
 * Record a payment against an existing invoice (used to settle Credit bills).
 * amount: rupees being paid right now (added to existing paid_amount).
 * Marks paid=1 once paid_amount >= total. Payment mode is never changed —
 * it stays "Credit" forever as the original transaction record.
 */
export const recordPayment = async (invoiceId, amount) => {
  const db = await openDb();
  const inv = await tx('invoices', 'readonly', s => s.get(invoiceId));
  if (!inv) throw new Error('Invoice not found');

  const add = Math.max(0, parseFloat(amount) || 0);
  const currentPaid = inv.paid_amount ?? (inv.paid ? inv.total : 0);
  const newPaidAmount = Math.min(inv.total, parseFloat((currentPaid + add).toFixed(2)));
  const isFullyPaid = newPaidAmount >= inv.total - 0.01; // tolerate rounding

  await tx('invoices', 'readwrite', s => s.put({
    ...inv,
    paid_amount: newPaidAmount,
    paid: isFullyPaid ? 1 : 0,
  }));

  return { paid_amount: newPaidAmount, balance_due: parseFloat((inv.total - newPaidAmount).toFixed(2)), paid: isFullyPaid };
};

/** Mark an invoice as fully paid in one tap. */
export const markInvoicePaid = async (invoiceId) => {
  const inv = await tx('invoices', 'readonly', s => s.get(invoiceId));
  if (!inv) throw new Error('Invoice not found');
  await tx('invoices', 'readwrite', s => s.put({
    ...inv,
    paid_amount: inv.total,
    paid: 1,
  }));
  return { paid_amount: inv.total, balance_due: 0, paid: true };
};

export const listInvoices = async (limit = 100) => {
  const all = await getAll('invoices');
  return all.sort((a, b) => b.created_at - a.created_at).slice(0, limit);
};

// ── Date-scoped lookups (Reports "search by date" / "from–to" range) ──────
// Date strings are local 'YYYY-MM-DD', e.g. from an <input type="date">.
// rangeBoundsMs(from, to) returns [startMs, endMs) covering every full local
// day from `from` through `to` inclusive. Pass the same value for both to
// scope to a single day.
const rangeBoundsMs = (fromDateStr, toDateStr = fromDateStr) => {
  const [fy, fm, fd] = fromDateStr.split('-').map(Number);
  const [ty, tm, td] = toDateStr.split('-').map(Number);
  const start = new Date(fy, fm - 1, fd, 0, 0, 0, 0).getTime();
  const end   = new Date(ty, tm - 1, td + 1, 0, 0, 0, 0).getTime();
  return [start, end];
};

export const listInvoicesForDate = async (fromDateStr, toDateStr = fromDateStr) => {
  const [start, end] = rangeBoundsMs(fromDateStr, toDateStr);
  const all = await getAll('invoices');
  return all
    .filter(i => i.created_at >= start && i.created_at < end)
    .sort((a, b) => b.created_at - a.created_at);
};

export const getStatsForDate = async (fromDateStr, toDateStr = fromDateStr) => {
  const [start, end] = rangeBoundsMs(fromDateStr, toDateStr);
  const all = await getAll('invoices');
  const filtered = all.filter(i => i.created_at >= start && i.created_at < end);
  const revenue = filtered.reduce((s, i) => s + i.total, 0);
  const allItems = await getAll('invoice_items');
  const items_sold = allItems
    .filter(i => filtered.some(inv => inv.id === i.invoice_id))
    .reduce((s, i) => s + i.qty, 0);
  return { revenue, count: filtered.length, items_sold };
};

export const listRepairTicketsForDate = async (fromDateStr, toDateStr = fromDateStr) => {
  const [start, end] = rangeBoundsMs(fromDateStr, toDateStr);
  const all = await getAll('repair_tickets');
  return all
    .filter(t => t.created_at >= start && t.created_at < end)
    .sort((a, b) => b.created_at - a.created_at);
};

/**
 * Combined revenue breakdown across sales invoices AND repair tickets,
 * grouped by the payment method selected at billing time. Pass either a
 * rangeMs window (Today/Week/Month/All) OR a from/to date pair — not both.
 * For a single specific day, pass the same value for from and to.
 * "Credit" bucket reflects the bill's total (its category at billing time),
 * regardless of whether it has since been collected — see paid/outstanding
 * status per-bill for that.
 */
export const getRevenueBreakdown = async (rangeMs, fromDateStr = null, toDateStr = fromDateStr) => {
  const [invAll, repAll] = await Promise.all([getAll('invoices'), getAll('repair_tickets')]);
  let invoices, repairs;
  if (fromDateStr) {
    const [start, end] = rangeBoundsMs(fromDateStr, toDateStr);
    invoices = invAll.filter(i => i.created_at >= start && i.created_at < end);
    repairs  = repAll.filter(t => t.created_at >= start && t.created_at < end);
  } else {
    const since = Date.now() - rangeMs;
    invoices = invAll.filter(i => i.created_at >= since);
    repairs  = repAll.filter(t => t.created_at >= since);
  }

  const by_mode = { Cash: 0, UPI: 0, Card: 0, Credit: 0 };
  let sales_revenue = 0, repair_revenue = 0;

  for (const inv of invoices) {
    sales_revenue += inv.total;
    const mode = by_mode.hasOwnProperty(inv.payment_mode) ? inv.payment_mode : 'Cash';
    by_mode[mode] += inv.total;
  }
  for (const t of repairs) {
    const cost = t.total_cost || 0;
    repair_revenue += cost;
    const mode = by_mode.hasOwnProperty(t.payment_mode) ? t.payment_mode : 'Cash';
    by_mode[mode] += cost;
  }

  return {
    total: parseFloat((sales_revenue + repair_revenue).toFixed(2)),
    sales_revenue: parseFloat(sales_revenue.toFixed(2)),
    repair_revenue: parseFloat(repair_revenue.toFixed(2)),
    by_mode,
    sales_count: invoices.length,
    repair_count: repairs.length,
  };
};

export const getInvoiceWithItems = async (id) => {
  const inv = await tx('invoices', 'readonly', s => s.get(id));
  if (!inv) return null;
  const items = await getAll('invoice_items', 'invoice_id', id);
  return { ...inv, items };
};

// ─── Stats ────────────────────────────────────────────────────────────────────
export const getStats = async (rangeMs) => {
  const since = Date.now() - rangeMs;
  const all = await getAll('invoices');
  const filtered = all.filter(i => i.created_at >= since);
  const revenue = filtered.reduce((s, i) => s + i.total, 0);
  const allItems = await getAll('invoice_items');
  const items_sold = allItems
    .filter(i => filtered.some(inv => inv.id === i.invoice_id))
    .reduce((s, i) => s + i.qty, 0);
  return { revenue, count: filtered.length, items_sold };
};

export const getLowStockCount = async () => {
  const critical = parseInt(await getSetting('critical_stock') || '2', 10);
  const low = parseInt(await getSetting('low_stock') || '5', 10);
  const products = await getAll('products');
  const total_stock = products.reduce((s, p) => s + p.stock, 0);
  return {
    critical: products.filter(p => p.stock <= critical).length,
    low: products.filter(p => p.stock > critical && p.stock <= low).length,
    total_stock,
  };
};

// ─── Repairs ──────────────────────────────────────────────────────────────────
export const listRepairTickets = async (status = null) => {
  const all = await getAll('repair_tickets');
  const filtered = status ? all.filter(t => t.status === status) : all;
  return filtered.sort((a, b) => b.created_at - a.created_at);
};

export const createRepairTicket = async (data) => {
  const counter = parseInt(await getSetting('repair_counter') || '0', 10) + 1;
  await setSetting('repair_counter', String(counter));
  const ticket_no = `RPR-${pad(counter)}`;
  const id = uid('rpr');
  const now = Date.now();
  const total_cost = (data.labour_charge || 0) + (data.parts_cost || 0);
  await tx('repair_tickets', 'readwrite', s => s.put({
    id, ticket_no, payment_mode: 'Cash', ...data, total_cost, created_at: now, updated_at: now,
  }));
  return { id, ticket_no };
};

export const updateRepairTicket = async (id, patch) => {
  const existing = await tx('repair_tickets', 'readonly', s => s.get(id));
  if (!existing) throw new Error('Ticket not found');
  const merged = { ...existing, ...patch };
  merged.total_cost = (merged.labour_charge || 0) + (merged.parts_cost || 0);
  merged.updated_at = Date.now();
  await tx('repair_tickets', 'readwrite', s => s.put(merged));
};

export const deleteRepairTicket = async (id) => {
  await tx('repair_tickets', 'readwrite', s => s.delete(id));
};

// ─── Reset ────────────────────────────────────────────────────────────────────
export const resetAllData = async () => {
  // Total wipe — close and DELETE the entire IndexedDB database.
  // This guarantees zero leftover data, including anything from old schema versions.
  if (_db) { _db.close(); _db = null; }
  await new Promise((resolve, reject) => {
    const req = indexedDB.deleteDatabase(DB_NAME);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
    req.onblocked = () => resolve(); // proceed anyway
  });
  // Mark that auto-seeding must NOT happen on next launch
  try { localStorage.setItem('phoneshop_factory_reset', '1'); } catch (_) {}
};

export const resetSalesData = async () => {
  const db = await openDb();
  for (const store of ['invoice_items','invoices']) {
    await new Promise((res, rej) => {
      const t = db.transaction(store, 'readwrite');
      const req = t.objectStore(store).clear();
      req.onsuccess = res; req.onerror = rej;
    });
  }
  await setSetting('invoice_counter', '0');
};

export const exportBackup = async () => {
  const [products, categories, invoices, invoice_items, settings, repair_tickets] = await Promise.all([
    getAll('products'), getAll('categories'), getAll('invoices'),
    getAll('invoice_items'), getAll('settings'), getAll('repair_tickets'),
  ]);
  return { version: 1, exported_at: Date.now(), products, categories, invoices, invoice_items, settings, repair_tickets };
};

export const formatCurrency = n => '₹' + (n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });

/**
 * Bill-level payment status label, shared by Receipt/RepairReceipt/Reports so
 * the wording is identical everywhere: "Paid via Cash", "Paid via UPI",
 * "Credit — Settled", or "Credit — Outstanding (₹X due)".
 * Works for both sales invoices (total/paid_amount) and repair tickets
 * (total_cost/paid_amount) — pass whichever fields the record has.
 */
export const formatPaymentStatus = (bill) => {
  const total = bill.total ?? bill.total_cost ?? 0;
  const paidAmount = bill.paid_amount ?? (bill.paid ? total : 0);
  const balance = Math.max(0, parseFloat((total - paidAmount).toFixed(2)));
  const mode = bill.payment_mode || 'Cash';

  if (mode === 'Credit') {
    return balance <= 0.01
      ? 'Credit — Settled'
      : `Credit — Outstanding (${formatCurrency(balance)} due)`;
  }
  return `Paid via ${mode}`;
};
