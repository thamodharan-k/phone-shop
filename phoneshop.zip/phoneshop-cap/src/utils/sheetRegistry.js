// ─── Global full-screen sheet registry ─────────────────────────────────────
// Full-screen bottom sheets (bill details, revenue breakdown, UPI QR, etc.)
// render with `position: fixed` at a high z-index so they cover the whole
// screen, including the bottom tab bar. That depends on the WebView
// stacking `position: fixed` elements strictly by z-index — some Android
// WebView builds don't, which let the tab bar's floating Cart button bleed
// through on top of a sheet (visible below/over it instead of hidden
// behind it).
//
// Rather than keep depending on stacking behaving perfectly on every
// device, any open sheet registers itself here via useSheetOpen(), and the
// tab bar (see App.jsx) simply un-mounts itself while at least one sheet is
// open. With the tab bar not rendered at all, there's nothing left for it
// to bleed through, regardless of how a given WebView handles z-index.
import { useEffect } from 'react';

let openCount = 0;
const listeners = new Set();

function notify() {
  const isOpen = openCount > 0;
  listeners.forEach(fn => fn(isOpen));
}

// Call from any full-screen sheet component. It registers on mount and
// unregisters on unmount (or whenever `open` flips to false).
export function useSheetOpen(open) {
  useEffect(() => {
    if (!open) return;
    openCount += 1;
    notify();
    return () => {
      openCount = Math.max(0, openCount - 1);
      notify();
    };
  }, [open]);
}

// Call from the tab bar (or anything else that needs to react live).
export function subscribeSheetOpen(fn) {
  listeners.add(fn);
  fn(openCount > 0);
  return () => listeners.delete(fn);
}
