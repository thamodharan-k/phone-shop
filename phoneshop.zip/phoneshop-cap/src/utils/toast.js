// ─── Global toast ───────────────────────────────────────────────────────────
// One <ToastHost/> is mounted at the app root (see App.jsx) and stays mounted
// across route changes. Any screen can call showToast('...') — including
// right before it navigates away — without needing to lift state up or wire
// context through every screen.

let listener = null;

export function registerToastListener(fn) {
  listener = fn;
  return () => { if (listener === fn) listener = null; };
}

export function showToast(message, opts = {}) {
  if (listener) listener(message, opts);
}
