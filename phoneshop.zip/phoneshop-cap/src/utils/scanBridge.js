// ─── Scan result mailbox ────────────────────────────────────────────────────
// Used only for the Scanner → Add Product handoff. Previously the Scanner
// screen delivered the scanned code by pushing a *new* '/add-product' history
// entry (with replace:true) on top of the one already there, leaving two
// stacked entries for the same screen. Add Product's later nav(-1) (meant to
// leave the screen after saving) only popped back to that duplicate entry —
// since React Router doesn't remount a component for a same-path history
// entry, the screen appeared to do nothing.
//
// Instead, Scanner just goes back to the Add Product entry that's already in
// history (nav(-1)) and drops the scanned code here; Add Product picks it up
// on mount.

let pendingBarcode = null;

export function setPendingBarcode(code) {
  pendingBarcode = code;
}

// Reads and clears the pending value (one-shot).
export function takePendingBarcode() {
  const code = pendingBarcode;
  pendingBarcode = null;
  return code;
}
