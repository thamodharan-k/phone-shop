// ─── Shared audio helper ────────────────────────────────────────────────────
// A single AudioContext for the whole app. Browsers / Android WebViews only
// allow audio to actually play once the context has been created/resumed as
// part of a real user gesture (tap/click). If we wait and create it lazily
// inside an async callback (e.g. from the barcode-scan detection loop) it
// stays "suspended" forever and no sound comes out — that was the bug.
//
// Fix: create the context once, and unlock it on the very first tap anywhere
// in the app (attached in App.jsx). By the time the user has navigated to the
// Scanner screen they've already tapped something, so the context is ready.

let audioCtx = null;

function getCtx() {
  if (!audioCtx) {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return null;
    audioCtx = new Ctx();
  }
  return audioCtx;
}

// Call once on app start — attaches a one-time listener that resumes/creates
// the AudioContext on the first user interaction.
export function unlockAudioOnFirstGesture() {
  const unlock = () => {
    const ctx = getCtx();
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
    window.removeEventListener('pointerdown', unlock);
    window.removeEventListener('touchend', unlock);
    window.removeEventListener('click', unlock);
  };
  window.addEventListener('pointerdown', unlock, { once: true });
  window.addEventListener('touchend', unlock, { once: true });
  window.addEventListener('click', unlock, { once: true });
}

// Short "barcode scanner" style beep.
export function playBeep() {
  try {
    const ctx = getCtx();
    if (!ctx) return;
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});

    const osc  = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'square';
    osc.frequency.value = 1800; // classic barcode-scanner beep pitch
    gain.gain.setValueAtTime(0.001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.005);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.13);
  } catch (_) { /* audio not available — scan still proceeds silently */ }
}
