import { createContext, useContext, useState, useCallback, useEffect } from 'react';

// ─── Cart ─────────────────────────────────────────────────────────────────────
const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [items, setItems] = useState([]);

  const addItem = useCallback((product) => {
    setItems(prev => {
      const existing = prev.find(i => i.product_id === product.id);
      if (existing) {
        // Cap at available stock
        const maxQty = product.stock ?? existing.stock ?? 9999;
        if (existing.qty >= maxQty) {
          alert(`Only ${maxQty} unit${maxQty !== 1 ? 's' : ''} of "${product.name}" available.`);
          return prev;
        }
        return prev.map(i => i.product_id === product.id ? { ...i, qty: i.qty + 1 } : i);
      }
      return [...prev, {
        product_id: product.id,
        name:       product.name,
        price:      product.price,
        qty:        1,
        stock:      product.stock ?? 9999, // store available stock for cap check
      }];
    });
  }, []);

  const removeItem  = useCallback((id) => setItems(p => p.filter(i => i.product_id !== id)), []);

  const updateQty = useCallback((id, qty) => {
    if (qty <= 0) {
      setItems(p => p.filter(i => i.product_id !== id));
    } else {
      setItems(prev => prev.map(i => {
        if (i.product_id !== id) return i;
        const maxQty = i.stock ?? 9999;
        if (qty > maxQty) {
          alert(`Only ${maxQty} unit${maxQty !== 1 ? 's' : ''} of "${i.name}" available.`);
          return i; // don't change
        }
        return { ...i, qty };
      }));
    }
  }, []);
  const clearCart   = useCallback(() => setItems([]), []);

  const totalQty = items.reduce((s, i) => s + i.qty, 0);
  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);

  return (
    <CartContext.Provider value={{ items, addItem, removeItem, updateQty, clearCart, totalQty, subtotal }}>
      {children}
    </CartContext.Provider>
  );
}
export const useCart = () => useContext(CartContext);

// ─── Theme ────────────────────────────────────────────────────────────────────
const ThemeContext = createContext(null);

const applyTheme = (isDark, brand) => {
  const root = document.documentElement;
  // Toggle light class — dark is the default :root, light uses :root.light
  if (isDark) root.classList.remove('light');
  else        root.classList.add('light');
  // Brand color
  root.style.setProperty('--brand', brand);
  root.style.setProperty('--brand-soft', brand + '26');
  root.style.setProperty('--on-brand', isDark ? '#001722' : '#FFFFFF');
};

export function ThemeProvider({ children }) {
  const [isDark, setIsDark] = useState(true);
  const [brandColor, setBrandColorState] = useState('#00E5FF');

  // Load saved prefs on mount
  useEffect(() => {
    (async () => {
      try {
        const { getSetting } = await import('../db/database.js');
        const [dm, tc] = await Promise.all([getSetting('dark_mode'), getSetting('theme_color')]);
        const dark  = dm !== '0';
        const brand = tc || '#00E5FF';
        setIsDark(dark);
        setBrandColorState(brand);
        applyTheme(dark, brand);
      } catch (_) {}
    })();
  }, []);

  const toggleDark = useCallback(async () => {
    const next = !isDark;
    setIsDark(next);
    applyTheme(next, brandColor);
    try {
      const { setSetting } = await import('../db/database.js');
      await setSetting('dark_mode', next ? '1' : '0');
    } catch (_) {}
  }, [isDark, brandColor]);

  const setBrandColor = useCallback(async (color) => {
    setBrandColorState(color);
    applyTheme(isDark, color);
    try {
      const { setSetting } = await import('../db/database.js');
      await setSetting('theme_color', color);
    } catch (_) {}
  }, [isDark]);

  return (
    <ThemeContext.Provider value={{ isDark, brandColor, toggleDark, setBrandColor }}>
      {children}
    </ThemeContext.Provider>
  );
}
export const useTheme = () => useContext(ThemeContext);
