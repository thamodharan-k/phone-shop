/**
 * Bluetooth ESC/POS Printer — Capacitor
 * Uses @capacitor-community/bluetooth-le for scanning & connecting,
 * then writes ESC/POS bytes over BLE GATT characteristic.
 *
 * For classic BT serial printers, falls back to navigator.bluetooth (Web BT API)
 * if available. Works on Android 6+ with the production APK.
 */

import { BleClient } from '@capacitor-community/bluetooth-le';

// ESC/POS printer GATT service & characteristic UUIDs (standard for most BT thermal printers)
const PRINTER_SERVICE   = '000018f0-0000-1000-8000-00805f9b34fb';
const PRINTER_CHAR      = '00002af1-0000-1000-8000-00805f9b34fb';
const SCAN_TIMEOUT_MS   = 8000;

let connectedDeviceId = null;

// ─── ESC/POS byte helpers ─────────────────────────────────────────────────────
const ESC = 0x1B;
const GS  = 0x1D;
const LF  = 0x0A;

const CMD = {
  INIT:        new Uint8Array([ESC, 0x40]),
  ALIGN_LEFT:  new Uint8Array([ESC, 0x61, 0x00]),
  ALIGN_CENTER:new Uint8Array([ESC, 0x61, 0x01]),
  ALIGN_RIGHT: new Uint8Array([ESC, 0x61, 0x02]),
  BOLD_ON:     new Uint8Array([ESC, 0x45, 0x01]),
  BOLD_OFF:    new Uint8Array([ESC, 0x45, 0x00]),
  DOUBLE_SIZE: new Uint8Array([GS,  0x21, 0x11]),
  NORMAL_SIZE: new Uint8Array([GS,  0x21, 0x00]),
  CUT:         new Uint8Array([GS,  0x56, 0x00]),
  FEED3:       new Uint8Array([ESC, 0x64, 0x03]),
};

const textBytes = (str) => new TextEncoder().encode(str);
const line      = (str = '') => new Uint8Array([...textBytes(str), LF]);
const sep       = (width, char = '-') => line(char.repeat(width));

const merge = (...arrays) => {
  const total = arrays.reduce((s, a) => s + a.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const a of arrays) { out.set(a, offset); offset += a.length; }
  return out;
};

const colLine = (left, right, width) => {
  const r = String(right).slice(0, width - 1);
  const l = String(left).slice(0, Math.max(1, width - r.length - 1));
  const spaces = Math.max(1, width - l.length - r.length);
  return line((l + ' '.repeat(spaces) + r).slice(0, width));
};

/**
 * Map a thermal paper width (mm) to the printable character width
 * for a standard monospace ESC/POS font (Font A, 12 cols/inch typical).
 * These are the de-facto standard char counts used by ESC/POS firmware
 * across 58/80/112mm printers.
 */
export const PAPER_SIZES = [
  { mm: 48,  chars: 24, label: '48 mm'  },
  { mm: 57,  chars: 30, label: '57 mm'  },
  { mm: 72,  chars: 38, label: '72 mm'  },
  { mm: 80,  chars: 32, label: '80 mm' }, // 80mm printers commonly run Font A @ 32 cols by default firmware setting
  { mm: 112, chars: 48, label: '112 mm' },
];

export const charsForWidth = (mm) => {
  const exact = PAPER_SIZES.find(p => p.mm === mm);
  if (exact) return exact.chars;

  // Custom width not in the preset list — interpolate between the two
  // nearest known sizes (or extrapolate from the nearest one at the edges)
  // so any merchant-entered width still gets a sensible character count
  // instead of silently falling back to a generic default.
  const sorted = [...PAPER_SIZES].sort((a, b) => a.mm - b.mm);
  if (mm <= sorted[0].mm) {
    const ratio = sorted[0].chars / sorted[0].mm;
    return Math.max(16, Math.round(mm * ratio));
  }
  if (mm >= sorted[sorted.length - 1].mm) {
    const last = sorted[sorted.length - 1];
    const ratio = last.chars / last.mm;
    return Math.round(mm * ratio);
  }
  for (let i = 0; i < sorted.length - 1; i++) {
    const a = sorted[i], b = sorted[i + 1];
    if (mm >= a.mm && mm <= b.mm) {
      const t = (mm - a.mm) / (b.mm - a.mm);
      return Math.round(a.chars + t * (b.chars - a.chars));
    }
  }
  return 32;
};

/** Approximate printable dot width (203dpi ESC/POS heads) for sizing raster images. */
const dotsForWidth = (mm) => Math.max(200, Math.round(mm * 6.6));

// ─── Write chunk to device ────────────────────────────────────────────────────
const CHUNK_SIZE = 128; // BLE MTU safe size

const writeBytes = async (deviceId, data) => {
  for (let i = 0; i < data.length; i += CHUNK_SIZE) {
    const chunk = data.slice(i, i + CHUNK_SIZE);
    await BleClient.write(deviceId, PRINTER_SERVICE, PRINTER_CHAR, chunk);
    await new Promise(r => setTimeout(r, 30)); // small delay between chunks
  }
};

/**
 * Convert a base64 image (data URL) into ESC/POS GS v 0 raster bytes,
 * thresholded to 1-bit monochrome — used to print the merchant's uploaded
 * UPI QR code image directly on the thermal printer.
 */
const imageToRaster = (dataUrl, targetWidthDots = 300) => new Promise((resolve, reject) => {
  try {
    const img = new Image();
    img.onload = () => {
      try {
        const w = Math.min(targetWidthDots, img.width);
        const scale = w / img.width;
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h); // flatten transparency to white
        ctx.drawImage(img, 0, 0, w, h);
        const { data } = ctx.getImageData(0, 0, w, h);

        const bytesPerRow = Math.ceil(w / 8);
        const raster = new Uint8Array(bytesPerRow * h);
        for (let y = 0; y < h; y++) {
          for (let x = 0; x < w; x++) {
            const idx = (y * w + x) * 4;
            const lum = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
            if (lum < 160) { // dark pixel → printed dot
              raster[y * bytesPerRow + (x >> 3)] |= (0x80 >> (x & 7));
            }
          }
        }
        const header = new Uint8Array([
          GS, 0x76, 0x30, 0x00,
          bytesPerRow & 0xFF, (bytesPerRow >> 8) & 0xFF,
          h & 0xFF, (h >> 8) & 0xFF,
        ]);
        resolve(merge(header, raster));
      } catch (e) { reject(e); }
    };
    img.onerror = () => reject(new Error('Could not load QR image.'));
    img.src = dataUrl;
  } catch (e) { reject(e); }
});

// ─── Public API ───────────────────────────────────────────────────────────────

export const isAvailable = () => typeof BleClient !== 'undefined';

/** Initialize BLE & request permissions */
export const ensureEnabled = async () => {
  try {
    await BleClient.initialize({ androidNeverForLocation: true });
    return { ok: true };
  } catch (e) {
    return { ok: false, reason: e?.message || 'Bluetooth unavailable.' };
  }
};

/** Check if the phone's Bluetooth radio is currently ON. */
export const isRadioEnabled = async () => {
  try {
    await BleClient.initialize({ androidNeverForLocation: true });
    return await BleClient.isEnabled();
  } catch (_) {
    return false;
  }
};

/**
 * Many Android devices still silently return zero scan results if
 * system Location Services are OFF, even though this app never uses
 * location itself. Used to warn the user instead of a mystery empty scan.
 */
export const isLocationEnabled = async () => {
  try {
    const res = await BleClient.isLocationEnabled();
    return !!res?.value;
  } catch (_) {
    return true; // unknown / not applicable (e.g. iOS) — don't block
  }
};

/**
 * Turn the phone's Bluetooth radio ON or OFF.
 * - Turning ON: shows the system "Allow Bluetooth?" prompt (requestEnable).
 * - Turning OFF: Android 13+ blocks apps from silently disabling Bluetooth,
 *   so we attempt disable() and fall back to opening system Bluetooth
 *   settings so the user can flip it off themselves.
 */
export const setRadioEnabled = async (enable) => {
  await BleClient.initialize({ androidNeverForLocation: true });
  if (enable) {
    await BleClient.requestEnable();
    return { ok: true };
  }
  try {
    await BleClient.disable();
    return { ok: true };
  } catch (_) {
    // Modern Android refuses programmatic disable — send user to settings.
    try { await BleClient.openBluetoothSettings(); } catch (_) {}
    return { ok: false, reason: 'Please turn off Bluetooth from system settings.' };
  }
};

/** Open the device's native Bluetooth settings screen. */
export const openBluetoothSettings = async () => {
  try { await BleClient.openBluetoothSettings(); } catch (_) {}
};

/** Scan for BLE devices, streaming each one live via onDevice as it's found. */
export const scanDevices = (onDevice) =>
  new Promise(async (resolve) => {
    const found = [];
    try {
      await BleClient.requestLEScan(
        { services: [], allowDuplicates: false }, // no filter — surfaces every advertising BLE device nearby
        (result) => {
          if (!result.device?.deviceId) return;
          if (found.find(d => d.address === result.device.deviceId)) return;
          const device = {
            name: result.localName || result.device.name || 'Unknown Device',
            address: result.device.deviceId,
            rssi: result.rssi,
          };
          found.push(device);
          onDevice && onDevice(device);
        }
      );
      setTimeout(async () => {
        try { await BleClient.stopLEScan(); } catch (_) {}
        resolve({ paired: [], found });
      }, SCAN_TIMEOUT_MS);
    } catch (e) {
      resolve({ paired: [], found });
    }
  });

/** Connect to a device */
export const connect = async (address) => {
  if (connectedDeviceId && connectedDeviceId !== address) {
    try { await BleClient.disconnect(connectedDeviceId); } catch (_) {}
  }
  await BleClient.connect(address, () => { connectedDeviceId = null; });
  connectedDeviceId = address;
};

/** Disconnect */
export const disconnect = async () => {
  if (connectedDeviceId) {
    try { await BleClient.disconnect(connectedDeviceId); } catch (_) {}
    connectedDeviceId = null;
  }
};

/**
 * Actually attempts to reach the printer right now (radio on + GATT connect),
 * rather than trusting the "last known" saved status. Returns a clear ok/reason
 * result so the UI can show the real, live connection state.
 */
export const checkConnectivity = async (address) => {
  if (!address) return { ok: false, reason: 'No printer selected.' };
  const { ok, reason } = await ensureEnabled();
  if (!ok) return { ok: false, reason: reason || 'Bluetooth is unavailable.' };
  if (!(await isRadioEnabled())) return { ok: false, reason: 'Bluetooth is turned off.' };
  try {
    await connect(address);
    return { ok: true };
  } catch (e) {
    return { ok: false, reason: e?.message || 'Printer not reachable. Make sure it is powered on and in range.' };
  }
};

/** Returns the currently connected device's address, or null. */
export const getConnectedDeviceId = () => connectedDeviceId;

/** Test print — uses saved paper width and the shop's own store info */
export const printTest = async (widthMm = 57, store = {}) => {
  if (!connectedDeviceId) throw new Error('No printer connected.');
  const W = charsForWidth(widthMm);
  const parts = [
    CMD.INIT,
    CMD.ALIGN_CENTER,
    CMD.BOLD_ON,
    CMD.DOUBLE_SIZE,
    line(store.store_name || 'SRI DHARANI MOBILES'),
    CMD.NORMAL_SIZE,
    CMD.BOLD_OFF,
  ];
  if (store.store_tagline) parts.push(line(store.store_tagline));
  if (store.store_address) parts.push(line(store.store_address));
  if (store.store_phone)   parts.push(line('Ph: ' + store.store_phone));
  if (store.gst_number)    parts.push(line('GSTIN: ' + store.gst_number));

  parts.push(
    sep(W),
    CMD.BOLD_ON,
    line('--- TEST PRINT ---'),
    CMD.BOLD_OFF,
    line(new Date().toLocaleString('en-IN')),
    sep(W),
    CMD.ALIGN_LEFT,
    colLine('Paper Width', widthMm + ' mm', W),
    colLine('Char Width',  W + ' cols',     W),
    colLine('Connection',  'OK',             W),
    sep(W),
    CMD.ALIGN_CENTER,
    line('If you can read this clearly,'),
    line('your printer is ready!'),
    CMD.FEED3,
    CMD.CUT,
  );
  await writeBytes(connectedDeviceId, merge(...parts));
};

/** Print a full sales receipt */
export const printReceipt = async (r, widthMm = 57) => {
  if (!connectedDeviceId) throw new Error('No printer connected. Go to Settings → Hardware.');
  const W = charsForWidth(widthMm);
  const nameW = Math.max(8, W - 16);

  const parts = [
    CMD.INIT,
    CMD.ALIGN_CENTER,
    CMD.BOLD_ON,
    CMD.DOUBLE_SIZE,
    line(r.store_name || 'SRI DHARANI MOBILES'),
    CMD.NORMAL_SIZE,
    CMD.BOLD_OFF,
  ];

  if (r.store_tagline) parts.push(line(r.store_tagline));
  if (r.store_address) parts.push(line(r.store_address));
  if (r.store_phone)   parts.push(line('Ph: ' + r.store_phone));
  if (r.gst_number)    parts.push(line('GSTIN: ' + r.gst_number));

  parts.push(sep(W));
  parts.push(CMD.ALIGN_LEFT);
  parts.push(colLine('Invoice : ' + r.invoice_no, r.date, W));
  parts.push(line('Customer: ' + (r.customer || 'Walk-in')));
  parts.push(line('Payment : ' + r.payment_mode));
  parts.push(sep(W));

  parts.push(CMD.BOLD_ON);
  const hdrItem = 'ITEM'.padEnd(nameW);
  const hdrRest = 'RATE'.padStart(5) + 'QTY'.padStart(4) + 'AMT'.padStart(6);
  parts.push(line(hdrItem + hdrRest));
  parts.push(CMD.BOLD_OFF);
  parts.push(sep(W));

  for (const it of (r.items || [])) {
    const name = String(it.name).slice(0, nameW).padEnd(nameW);
    const rate = String(it.price.toFixed(0)).padStart(5);
    const qty  = ('x' + it.qty).padStart(4);
    const amt  = it.amount.toFixed(0).padStart(6);
    parts.push(line(`${name}${rate}${qty}${amt}`));
  }

  parts.push(sep(W));
  parts.push(colLine('Subtotal', '\u20b9' + r.subtotal.toFixed(2), W));
  if (r.discount > 0) parts.push(colLine('Discount', '-\u20b9' + r.discount.toFixed(2), W));
  parts.push(colLine('GST', '\u20b9' + r.gst.toFixed(2), W));
  parts.push(sep(W, '='));
  parts.push(CMD.ALIGN_CENTER, CMD.BOLD_ON, CMD.DOUBLE_SIZE);
  parts.push(line('TOTAL: \u20b9' + r.total.toFixed(2)));
  parts.push(CMD.NORMAL_SIZE, CMD.BOLD_OFF);
  parts.push(sep(W, '='));

  if (r.payment_mode === 'UPI') {
    parts.push(CMD.ALIGN_CENTER, CMD.BOLD_ON);
    parts.push(line('Scan to Pay via UPI'));
    parts.push(CMD.BOLD_OFF);
    if (r.upi_qr_image) {
      try {
        const qrBytes = await imageToRaster(r.upi_qr_image, Math.min(300, dotsForWidth(widthMm) - 20));
        parts.push(qrBytes);
        parts.push(line());
      } catch (_) { /* QR image failed to render — still print the UPI ID text below */ }
    }
    if (r.upi_id) parts.push(line(r.upi_id));
    parts.push(sep(W));
  }
  parts.push(CMD.ALIGN_CENTER);
  if (r.thank_you) parts.push(line(r.thank_you));
  if (r.return_policy) { parts.push(sep(W)); parts.push(line(r.return_policy)); }
  parts.push(CMD.FEED3, CMD.CUT);

  await writeBytes(connectedDeviceId, merge(...parts));
};

/** Print a repair job receipt */
export const printRepairReceipt = async (t, widthMm = 57) => {
  if (!connectedDeviceId) throw new Error('No printer connected. Go to Settings → Hardware.');
  const W = charsForWidth(widthMm);

  const parts = [
    CMD.INIT,
    CMD.ALIGN_CENTER,
    CMD.BOLD_ON,
    CMD.DOUBLE_SIZE,
    line(t.store_name || 'SRI DHARANI MOBILES'),
    CMD.NORMAL_SIZE,
    CMD.BOLD_OFF,
  ];

  if (t.store_address) parts.push(line(t.store_address));
  if (t.store_phone)   parts.push(line('Ph: ' + t.store_phone));

  parts.push(sep(W));
  parts.push(CMD.ALIGN_CENTER, CMD.BOLD_ON);
  parts.push(line('REPAIR JOB RECEIPT'));
  parts.push(CMD.BOLD_OFF);
  parts.push(sep(W));

  parts.push(CMD.ALIGN_LEFT);
  parts.push(colLine('Ticket  : ' + t.ticket_no, t.status, W));
  parts.push(line('Date    : ' + t.date));
  parts.push(line('Customer: ' + (t.customer || 'Walk-in')));
  if (t.phone) parts.push(line('Phone   : ' + t.phone));
  parts.push(sep(W));

  parts.push(CMD.BOLD_ON, line('DEVICE'), CMD.BOLD_OFF);
  parts.push(line(t.device_model || '-'));
  if (t.imei) parts.push(line('IMEI: ' + t.imei));
  parts.push(sep(W));

  if (t.issue) {
    parts.push(CMD.BOLD_ON, line('ISSUE REPORTED'), CMD.BOLD_OFF);
    parts.push(line(t.issue));
    parts.push(sep(W));
  }
  if (t.parts) {
    parts.push(CMD.BOLD_ON, line('PARTS USED'), CMD.BOLD_OFF);
    parts.push(line(t.parts));
    parts.push(sep(W));
  }

  parts.push(colLine('Labour Charge', '\u20b9' + (t.labour_charge||0).toFixed(2), W));
  parts.push(colLine('Parts Cost',    '\u20b9' + (t.parts_cost||0).toFixed(2),    W));
  parts.push(sep(W, '='));
  parts.push(CMD.BOLD_ON);
  parts.push(colLine('TOTAL COST', '\u20b9' + (t.total_cost||0).toFixed(2), W));
  parts.push(CMD.BOLD_OFF);
  parts.push(sep(W));

  parts.push(colLine('Amount Paid', '\u20b9' + (t.paid_amount||0).toFixed(2), W));
  if (t.balance_due > 0) {
    parts.push(CMD.BOLD_ON);
    parts.push(colLine('BALANCE DUE', '\u20b9' + t.balance_due.toFixed(2), W));
    parts.push(CMD.BOLD_OFF);
  } else {
    parts.push(CMD.ALIGN_CENTER, line('** FULLY PAID **'), CMD.ALIGN_LEFT);
  }
  parts.push(sep(W, '='));

  if (t.payment_mode === 'UPI') {
    parts.push(CMD.ALIGN_CENTER, CMD.BOLD_ON);
    parts.push(line('Scan to Pay via UPI'));
    parts.push(CMD.BOLD_OFF);
    if (t.upi_qr_image) {
      try {
        const qrBytes = await imageToRaster(t.upi_qr_image, Math.min(300, dotsForWidth(widthMm) - 20));
        parts.push(qrBytes);
        parts.push(line());
      } catch (_) { /* still print the UPI ID text below */ }
    }
    if (t.upi_id) parts.push(line(t.upi_id));
    parts.push(sep(W));
    parts.push(CMD.ALIGN_LEFT);
  }

  parts.push(CMD.ALIGN_CENTER);
  parts.push(line('Thank you for your business!'));
  parts.push(line('Please retain this receipt.'));
  parts.push(CMD.FEED3, CMD.CUT);

  await writeBytes(connectedDeviceId, merge(...parts));
};
