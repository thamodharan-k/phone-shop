import { useState, useEffect, useRef } from 'react';
import { HashRouter, Routes, Route, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { CartProvider, ThemeProvider, useCart } from './state/context.jsx';
import { initDb, getSetting } from './db/database.js';
import { App as CapApp } from '@capacitor/app';
import { Keyboard } from '@capacitor/keyboard';
import { unlockAudioOnFirstGesture } from './utils/sound.js';
import { subscribeSheetOpen } from './utils/sheetRegistry.js';

// Screens
import Dashboard    from './screens/Dashboard.jsx';
import Products     from './screens/Products.jsx';
import Cart         from './screens/Cart.jsx';
import Repairs      from './screens/Repairs.jsx';
import Settings     from './screens/Settings.jsx';
import AddProduct   from './screens/AddProduct.jsx';
import Categories   from './screens/Categories.jsx';
import Receipt      from './screens/Receipt.jsx';
import RepairTicket from './screens/RepairTicket.jsx';
import RepairReceipt from './screens/RepairReceipt.jsx';
import Scanner      from './screens/Scanner.jsx';
import Reports      from './screens/Reports.jsx';
import PinLock      from './screens/PinLock.jsx';
import ToastHost    from './components/ToastHost.jsx';

// ─── SVG Icons ───────────────────────────────────────────────────────────────
const Icon = ({ name, size = 22, color = 'currentColor' }) => {
  const paths = {
    home: <><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/></>,
    'phone-portrait': <><rect x="7" y="2" width="10" height="20" rx="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></>,
    'bag-handle': <><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09a1.65 1.65 0 00-1-1.51 1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09a1.65 1.65 0 001.51-1 1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      {paths[name] || <circle cx="12" cy="12" r="10"/>}
    </svg>
  );
};

// ─── Crossed-tools icon (wrench + screwdriver, X shape) for the Repairs tab ──
const CrossedToolsIcon = ({ size = 28, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Screwdriver — diagonal NW→SE */}
    <g transform="rotate(-45 12 12)">
      <rect x="10.6" y="2.2" width="2.8" height="5.6" rx="1" fill={color}/>
      <rect x="11.15" y="7.6" width="1.7" height="9.4" fill={color}/>
      <path d="M9.6 17h4.8l-1.4 4.4a1 1 0 01-1 0L9.6 17z" fill={color}/>
    </g>
    {/* Wrench — diagonal NE→SW */}
    <g transform="rotate(45 12 12)">
      <path d="M7.2 3.6a3.6 3.6 0 004.6 5l7 7-2 2-7-7a3.6 3.6 0 01-5-4.6l1.8 1.8 1.4-1.4z" fill={color}/>
    </g>
  </svg>
);

// ─── Modern Scan Icon (barcode lines + corner brackets) ──────────────────────
const ScanIcon = ({ size = 26, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    {/* Corner brackets */}
    <path d="M3 7V5a2 2 0 012-2h2"/>
    <path d="M17 3h2a2 2 0 012 2v2"/>
    <path d="M21 17v2a2 2 0 01-2 2h-2"/>
    <path d="M7 21H5a2 2 0 01-2-2v-2"/>
    {/* Barcode lines */}
    <line x1="7"  y1="8" x2="7"  y2="16" strokeWidth="1.5"/>
    <line x1="10" y1="8" x2="10" y2="16" strokeWidth="2.5"/>
    <line x1="13" y1="8" x2="13" y2="16" strokeWidth="1.5"/>
    <line x1="16" y1="8" x2="16" y2="16" strokeWidth="2.5"/>
  </svg>
);

// ─── Cart Badge ───────────────────────────────────────────────────────────────
function CartBadge() {
  const { totalQty } = useCart();
  const [bounce, setBounce] = useState(false);
  const prevQty = useRef(totalQty);

  useEffect(() => {
    if (totalQty > prevQty.current) {
      setBounce(true);
      const t = setTimeout(() => setBounce(false), 350);
      prevQty.current = totalQty;
      return () => clearTimeout(t);
    }
    prevQty.current = totalQty;
  }, [totalQty]);

  if (!totalQty) return null;
  return (
    <span className={bounce ? 'anim-badge-bounce' : ''} style={{
      position:'absolute', top:-4, right:-6,
      background:'var(--brand)', color:'var(--on-brand)',
      borderRadius:9, minWidth:18, height:18,
      fontSize:10, fontWeight:800,
      display:'flex', alignItems:'center', justifyContent:'center',
      padding:'0 4px',
    }}>{totalQty}</span>
  );
}

// ─── Tab Bar ──────────────────────────────────────────────────────────────────
function TabBar() {
  const { totalQty } = useCart();
  const loc = useLocation();
  const nav = useNavigate();
  const [sheetOpen, setSheetOpen] = useState(false);

  useEffect(() => subscribeSheetOpen(setSheetOpen), []);

  const hide = sheetOpen || ['/scanner','/receipt','/add-product','/repair-ticket','/repair-receipt']
    .some(p => loc.pathname.startsWith(p));
  if (hide) return null;

  // Side tabs flank the curved notch; Cart lives in the floating center FAB.
  const sideTabs = [
    { to:'/',         icon:'home',           label:'Home' },
    { to:'/products', icon:'phone-portrait', label:'Inventory' },
    { to:'/repairs',  icon:'crossed-tools',  label:'Repairs' },
    { to:'/settings', icon:'settings',       label:'Settings' },
  ];
  const isCartActive = loc.pathname.startsWith('/cart');

  const tabStyle = { flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:3, textDecoration:'none', paddingTop:14 };
  const iconWrap = (isActive) => ({ width:36, height:36, borderRadius:10, background: isActive ? 'var(--brand-soft)' : 'transparent', display:'flex', alignItems:'center', justifyContent:'center', position:'relative', transition:'background 0.15s' });
  const labelStyle = (isActive) => ({ fontSize:10, fontWeight:700, color: isActive ? 'var(--brand)' : 'var(--muted-strong)' });

  const BAR_H = 68; // height of the curved bar itself (excludes safe-area inset) — must match --tab-height in index.css

  return (
    <nav style={{
      position:'fixed', bottom:0, left:0, right:0,
      height:`calc(${BAR_H}px + var(--safe-bottom))`,
      paddingBottom:'var(--safe-bottom)',
      zIndex:100,
    }}>
      {/* Curved background shape */}
      <svg
        viewBox={`0 0 400 ${BAR_H}`} preserveAspectRatio="none"
        style={{ position:'absolute', inset:0, width:'100%', height:BAR_H, filter:'drop-shadow(0 -4px 16px rgba(0,0,0,0.22))' }}
      >
        <path
          d={`M0,0 L124,0 C162,0 154,22 200,22 C246,22 238,0 276,0 L400,0 L400,${BAR_H} L0,${BAR_H} Z`}
          fill="var(--surface-secondary)"
        />
      </svg>

      {/* Side tabs, split around the center notch */}
      <div style={{ position:'relative', display:'flex', height:BAR_H }}>
        {sideTabs.slice(0,2).map(t => (
          <NavLink key={t.to} to={t.to} end={t.to==='/'} style={tabStyle}>
            {({ isActive }) => (
              <>
                <span style={iconWrap(isActive)}>
                  {t.icon === 'crossed-tools'
                    ? <CrossedToolsIcon size={22} color={isActive ? 'var(--brand)' : 'var(--muted-strong)'} />
                    : <Icon name={t.icon} size={22} color={isActive ? 'var(--brand)' : 'var(--muted-strong)'} />}
                </span>
                <span style={labelStyle(isActive)}>{t.label}</span>
              </>
            )}
          </NavLink>
        ))}

        <div style={{ width:96, flexShrink:0 }} /> {/* space reserved for the notch/FAB */}

        {sideTabs.slice(2).map(t => (
          <NavLink key={t.to} to={t.to} end={t.to==='/'} style={tabStyle}>
            {({ isActive }) => (
              <>
                <span style={iconWrap(isActive)}>
                  {t.icon === 'crossed-tools'
                    ? <CrossedToolsIcon size={22} color={isActive ? 'var(--brand)' : 'var(--muted-strong)'} />
                    : <Icon name={t.icon} size={22} color={isActive ? 'var(--brand)' : 'var(--muted-strong)'} />}
                </span>
                <span style={labelStyle(isActive)}>{t.label}</span>
              </>
            )}
          </NavLink>
        ))}
      </div>

      {/* Floating Cart FAB — larger than the other tabs, bag icon with quantity badge */}
      <button
        onClick={() => nav('/cart')}
        aria-label="Cart"
        style={{
          position:'absolute', top:-26, left:'50%', transform:'translateX(-50%)',
          width:66, height:66, borderRadius:33,
          background: isCartActive ? 'var(--brand)' : 'var(--surface-elevated)',
          border: isCartActive ? 'none' : '2px solid var(--brand)',
          display:'flex', alignItems:'center', justifyContent:'center',
          cursor:'pointer', boxShadow:'0 6px 18px rgba(0,0,0,0.3)',
          transition:'background 0.15s, border-color 0.15s',
        }}
      >
        <Icon name="bag-handle" size={30} color={isCartActive ? 'var(--on-brand)' : 'var(--brand)'} />
        {totalQty > 0 && <CartBadge />}
      </button>
      <div style={{ position:'absolute', top:44, left:'50%', transform:'translateX(-50%)', fontSize:10, fontWeight:700, color: isCartActive ? 'var(--brand)' : 'var(--muted-strong)' }}>
        Cart
      </div>
    </nav>
  );
}

// ─── Exit confirmation toast ────────────────────────────────────────────────
function ExitToast() {
  return (
    <div style={{
      position:'fixed', left:'50%', transform:'translateX(-50%)',
      bottom:`calc(var(--tab-height) + var(--safe-bottom) + 14px)`,
      background:'var(--surface-inverse)', color:'var(--on-surface-inverse)',
      padding:'10px 20px', borderRadius:'var(--radius-pill)',
      fontSize:13, fontWeight:700, whiteSpace:'nowrap',
      boxShadow:'0 6px 20px rgba(0,0,0,0.3)', zIndex:300,
      animation:'fadeIn 0.15s ease',
    }}>
      Press back again to exit
    </div>
  );
}

// ─── App Inner ────────────────────────────────────────────────────────────────
// Root tab paths — the hardware back button treats these as the "top" of each
// tab's own stack: from a nested screen it steps back through history one
// screen at a time; from any root tab other than the Dashboard it steps back
// up to the Dashboard; only from the Dashboard itself does a second press exit.
const ROOT_PATHS = ['/', '/products', '/cart', '/repairs', '/settings'];
const EXIT_CONFIRM_WINDOW_MS = 2000;

function AppInner() {
  const nav = useNavigate();
  const loc = useLocation();
  const [showExitToast, setShowExitToast] = useState(false);
  const exitTimerRef = useRef(null);
  const exitArmedRef = useRef(false); // avoids stale-closure issues inside the listener

  // ── Android hardware back button ────────────────────────────────────────
  useEffect(() => {
    let listener;
    const setup = async () => {
      try {
        listener = await CapApp.addListener('backButton', () => {
          const isRoot = ROOT_PATHS.includes(loc.pathname);

          if (!isRoot) {
            // On a nested screen — step back one screen at a time
            nav(-1);
            return;
          }

          if (loc.pathname !== '/') {
            // On a root tab other than the Dashboard — step back up to it first
            nav('/');
            return;
          }

          // On the Dashboard itself — require a second press within the window to exit
          if (exitArmedRef.current) {
            CapApp.exitApp();
            return;
          }
          exitArmedRef.current = true;
          setShowExitToast(true);
          if (exitTimerRef.current) clearTimeout(exitTimerRef.current);
          exitTimerRef.current = setTimeout(() => {
            exitArmedRef.current = false;
            setShowExitToast(false);
          }, EXIT_CONFIRM_WINDOW_MS);
        });
      } catch (_) {
        // Not running in Capacitor (e.g. browser dev) — ignore
      }
    };
    setup();
    return () => {
      listener?.remove?.();
      if (exitTimerRef.current) clearTimeout(exitTimerRef.current);
    };
  }, [loc.pathname, nav]);

  // Leaving the Dashboard disarms the exit-confirmation window
  useEffect(() => {
    if (loc.pathname !== '/') {
      exitArmedRef.current = false;
      setShowExitToast(false);
      if (exitTimerRef.current) clearTimeout(exitTimerRef.current);
    }
  }, [loc.pathname]);

  return (
    <div style={{ height:'100%', display:'flex', flexDirection:'column', position:'relative' }}>
      <div style={{ flex:1, overflow:'hidden', position:'relative' }}>
        <div key={loc.pathname} className="anim-route" style={{ height:'100%' }}>
          <Routes>
            <Route path="/"               element={<Dashboard />} />
            <Route path="/products"       element={<Products />} />
            <Route path="/cart"           element={<Cart />} />
            <Route path="/repairs"        element={<Repairs />} />
            <Route path="/settings"       element={<Settings />} />
            <Route path="/reports"        element={<Reports />} />
            <Route path="/add-product"    element={<AddProduct />} />
            <Route path="/categories"     element={<Categories />} />
            <Route path="/receipt/:id"    element={<Receipt />} />
            <Route path="/repair-ticket"  element={<RepairTicket />} />
            <Route path="/repair-receipt/:id" element={<RepairReceipt />} />
            <Route path="/scanner"        element={<Scanner />} />
          </Routes>
        </div>
      </div>
      {showExitToast && <ExitToast />}
      <ToastHost />
      <TabBar />
    </div>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [ready,    setReady]    = useState(false);
  const [splashExiting, setSplashExiting] = useState(false);
  const [showSplash, setShowSplash] = useState(true);
  const [pinLocked, setPinLocked] = useState(false);

  useEffect(() => {
    unlockAudioOnFirstGesture(); // enables scan beep: primes AudioContext on first tap

    // ── Keyboard-aware app height ────────────────────────────────────────
    // Android's adjustResize (AndroidManifest) is meant to shrink the WebView
    // when the keyboard opens, but this is unreliable across WebView/Android
    // versions (notably edge-to-edge layouts on API 30+, where adjustResize
    // is largely ignored). visualViewport reports the true visible height
    // regardless, so #root's height is driven from that directly — this is
    // what makes fixed/absolute footers and the tab bar actually move above
    // the keyboard instead of being covered by it.
    const applyVisibleHeight = () => {
      const h = window.visualViewport ? window.visualViewport.height : window.innerHeight;
      document.documentElement.style.setProperty('--app-vh', `${h}px`);
    };
    applyVisibleHeight();
    window.visualViewport?.addEventListener('resize', applyVisibleHeight);
    window.addEventListener('resize', applyVisibleHeight);

    // ── Keep the real input visible AND show a synced mirror above the keyboard ──
    // Previously the focused input was physically moved out of its normal
    // spot and pinned above the keyboard, leaving an empty gap where it used
    // to be — the text looked like it "disappeared" while typing. Now the
    // real input is never touched: it stays exactly where it is, fully
    // visible and interactive, and is nudged into view with scrollIntoView
    // (respecting the scroll-margin set in index.css so our own fixed
    // header/footers aren't covering it). A separate, read-only bar is
    // pinned just above the keyboard that mirrors the same text live, purely
    // as an easy-to-glance confirmation — it can never capture taps or hide
    // anything since it's pointer-events:none, so both stay visible together.
    let kbHeight = 0;
    let mirrorEl = null, mirrorLabelEl = null, mirrorValueEl = null;
    let mirroredField = null;

    const ensureMirrorEl = () => {
      if (mirrorEl) return;
      mirrorEl = document.createElement('div');
      mirrorEl.className = 'field-mirror';
      mirrorLabelEl = document.createElement('div');
      mirrorLabelEl.className = 'field-mirror-label';
      mirrorValueEl = document.createElement('div');
      mirrorValueEl.className = 'field-mirror-value';
      mirrorEl.appendChild(mirrorLabelEl);
      mirrorEl.appendChild(mirrorValueEl);
      document.body.appendChild(mirrorEl);
    };

    const positionMirror = () => {
      if (!mirrorEl) return;
      mirrorEl.style.bottom = `${kbHeight + 12}px`;
    };

    const fieldLabelFor = (el) => {
      // Best-effort label lookup: the app's own Field/F components render a
      // sibling `.label` div right before the input inside the same wrapper.
      const wrapper = el.closest('div');
      const labelEl = wrapper?.querySelector(':scope > .label');
      return labelEl?.textContent || el.placeholder || 'Typing…';
    };

    const updateMirrorValue = () => {
      if (!mirrorEl || !mirroredField) return;
      mirrorValueEl.textContent = mirroredField.value || '';
    };

    const showMirror = (el) => {
      if (!el || !(el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) return;
      ensureMirrorEl();
      mirroredField = el;
      mirrorLabelEl.textContent = fieldLabelFor(el);
      updateMirrorValue();
      positionMirror();
      mirrorEl.style.display = 'flex';
      el.addEventListener('input', updateMirrorValue);
    };

    const hideMirror = () => {
      if (mirroredField) mirroredField.removeEventListener('input', updateMirrorValue);
      mirroredField = null;
      if (mirrorEl) mirrorEl.style.display = 'none';
    };

    // Nudge the real (untouched) field into view, clear of the keyboard —
    // 'nearest' + the scroll-margin in index.css keeps it clear of our own
    // fixed header/footers without overshooting like 'center' can.
    const scrollFocusedIntoView = () => {
      const el = document.activeElement;
      if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) {
        el.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      }
    };

    const onFocusIn = (e) => {
      const el = e.target;
      if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) {
        showMirror(el);
        setTimeout(scrollFocusedIntoView, 300); // fallback for WebViews without visualViewport/Keyboard events
      }
    };
    const onFocusOut = (e) => {
      // Small delay — tapping a search-result row or the next field shouldn't
      // cause a visible flash of the mirror disappearing and reappearing.
      setTimeout(() => { if (document.activeElement !== mirroredField) hideMirror(); }, 80);
    };
    document.addEventListener('focusin', onFocusIn);
    document.addEventListener('focusout', onFocusOut);

    const onViewportResizeForMirror = () => {
      if (window.visualViewport) kbHeight = Math.max(0, window.innerHeight - window.visualViewport.height);
      positionMirror();
      scrollFocusedIntoView();
    };
    window.visualViewport?.addEventListener('resize', onViewportResizeForMirror);

    // ── Native Keyboard plugin (Android) — the reliable primary source ──────
    // capacitor.config.json sets Keyboard.resize:"body"; these events fire
    // precisely when the keyboard animates open/closed (no polling, no
    // timeout guessing). The visualViewport listener above is the fallback
    // for browser/dev preview, where this native plugin isn't available.
    let kbShowHandle, kbHideHandle;
    (async () => {
      try {
        kbShowHandle = await Keyboard.addListener('keyboardWillShow', (info) => {
          kbHeight = info?.keyboardHeight || 0;
          document.documentElement.style.setProperty('--app-vh', `${window.innerHeight - kbHeight}px`);
          positionMirror();
          scrollFocusedIntoView();
        });
        kbHideHandle = await Keyboard.addListener('keyboardWillHide', () => {
          kbHeight = 0;
          document.documentElement.style.setProperty('--app-vh', `${window.innerHeight}px`);
          hideMirror();
        });
      } catch (_) {
        // Not running in Capacitor (e.g. browser dev) — visualViewport fallback above covers it.
      }
    })();

    (async () => {
      await initDb();
      const pinEnabled = await getSetting('pin_enabled');
      if (pinEnabled === '1') setPinLocked(true);

      // Apply saved theme
      const dm = await getSetting('dark_mode');
      const tc = await getSetting('theme_color');
      const isDark = dm !== '0';
      const brand  = tc || '#00E5FF';
      if (!isDark) document.documentElement.classList.add('light');
      document.documentElement.style.setProperty('--brand', brand);
      document.documentElement.style.setProperty('--brand-soft', brand + '26');
      document.documentElement.style.setProperty('--on-brand', isDark ? '#001722' : '#FFFFFF');
      setReady(true);
    })();

    return () => {
      document.removeEventListener('focusin', onFocusIn);
      document.removeEventListener('focusout', onFocusOut);
      hideMirror();
      mirrorEl?.parentNode?.removeChild(mirrorEl);
      window.visualViewport?.removeEventListener('resize', onViewportResizeForMirror);
      window.visualViewport?.removeEventListener('resize', applyVisibleHeight);
      window.removeEventListener('resize', applyVisibleHeight);
      kbShowHandle?.remove?.();
      kbHideHandle?.remove?.();
    };
  }, []);

  // When loading finishes, play a brief fade-out instead of an abrupt swap
  useEffect(() => {
    if (!ready) return;
    setSplashExiting(true);
    const t = setTimeout(() => setShowSplash(false), 320);
    return () => clearTimeout(t);
  }, [ready]);

  if (!ready) return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%', background:'var(--surface)' }}>
      <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:16 }}>
        <div style={{
          width:64, height:64, borderRadius:18, background:'var(--brand)',
          display:'flex', alignItems:'center', justifyContent:'center',
          animation:'splashIconPop 0.6s cubic-bezier(.34,1.56,.64,1) forwards, splashGlow 1.8s ease-in-out 0.6s infinite',
        }}>
          <ScanIcon size={32} color="#001722" />
        </div>
        <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:8, animation:'splashTextIn 0.5s ease 0.25s both' }}>
          <span style={{ color:'var(--on-surface)', fontWeight:900, fontSize:18, letterSpacing:0.3 }}>SRI DHARANI MOBILES</span>
          <div style={{ display:'flex', gap:5 }}>
            {[0,1,2].map(i => (
              <span key={i} style={{
                width:6, height:6, borderRadius:3, background:'var(--muted)',
                animation:`splashDotBounce 1.1s ease-in-out ${i*0.15}s infinite`,
              }} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  if (showSplash) return (
    <div className={splashExiting ? 'splash-fade-out' : ''} style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%', background:'var(--surface)' }}>
      <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:16 }}>
        <div style={{ width:64, height:64, borderRadius:18, background:'var(--brand)', display:'flex', alignItems:'center', justifyContent:'center' }}>
          <ScanIcon size={32} color="#001722" />
        </div>
        <span style={{ color:'var(--on-surface)', fontWeight:900, fontSize:18, letterSpacing:0.3 }}>SRI DHARANI MOBILES</span>
      </div>
    </div>
  );

  if (pinLocked) return <PinLock onUnlock={() => setPinLocked(false)} />;

  return (
    <HashRouter>
      <ThemeProvider>
        <CartProvider>
          <AppInner />
        </CartProvider>
      </ThemeProvider>
    </HashRouter>
  );
}
