import { useState, useEffect } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { getInvoiceWithItems, getAllSettings, formatCurrency, formatPaymentStatus } from '../db/database.js';
import * as BT from '../printer/bluetooth.js';

export default function Receipt() {
  const { id } = useParams();
  const nav    = useNavigate();
  const loc    = useLocation();
  const [inv,      setInv]      = useState(null);
  const [store,    setStore]    = useState({});
  const [printing, setPrinting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(!!loc.state?.justCompleted);

  useEffect(() => {
    if (!showSuccess) return;
    const t = setTimeout(() => setShowSuccess(false), 1400);
    return () => clearTimeout(t);
  }, [showSuccess]);

  useEffect(() => {
    (async () => {
      const [i, s] = await Promise.all([getInvoiceWithItems(id), getAllSettings()]);
      setInv(i); setStore(s);
    })();
  }, [id]);

  if (!inv) return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%', color:'var(--muted)', background:'var(--surface)' }}>
      Loading receipt…
    </div>
  );

  const date = new Date(inv.created_at).toLocaleString('en-IN');

  const handleBTPrint = async () => {
    if (!store.bt_printer_address) {
      alert('No printer paired. Go to Settings → Hardware.');
      return;
    }
    setPrinting(true);
    try {
      const { ok, reason } = await BT.ensureEnabled();
      if (!ok) { alert(reason || 'Bluetooth unavailable.'); return; }
      await BT.connect(store.bt_printer_address);
      await BT.printReceipt({
        store_name:    store.store_name,
        store_tagline: store.store_tagline,
        store_address: store.store_address,
        store_phone:   store.store_phone,
        gst_number:    store.gst_number,
        invoice_no:    inv.invoice_no,
        date,
        customer:      inv.customer_name,
        payment_mode:  inv.payment_mode,
        items:         inv.items || [],
        subtotal:      inv.subtotal,
        discount:      inv.discount_amount,
        gst:           inv.gst_amount,
        total:         inv.total,
        thank_you:     store.thank_you_msg,
        return_policy: store.return_policy,
        upi_id:        store.upi_id,
        upi_qr_image:  store.upi_qr_print_enabled !== '0' ? store.upi_qr_image : '',
      }, parseInt(store.paper_width || '57', 10));
      // ✅ Post-print: auto-close receipt view, return to previous screen
      nav(-1);
    } catch(e) {
      alert('Print error: ' + e.message);
    } finally {
      setPrinting(false);
    }
  };

  const handleShare = () => {
    const lines = [
      store.store_name || 'SRI DHARANI MOBILES',
      `${inv.invoice_no} | ${date}`,
      `Customer: ${inv.customer_name||'Walk-in'} | ${inv.payment_mode}`,
      '─'.repeat(32),
      ...(inv.items||[]).map(i => `${i.name.slice(0,22).padEnd(22)} x${i.qty}  ${formatCurrency(i.amount)}`),
      '─'.repeat(32),
      `Subtotal: ${formatCurrency(inv.subtotal)}`,
      inv.discount_amount > 0 ? `Discount: -${formatCurrency(inv.discount_amount)}` : null,
      `GST:      ${formatCurrency(inv.gst_amount)}`,
      `TOTAL:    ${formatCurrency(inv.total)}`,
      '',
      store.thank_you_msg || 'Thank you!',
    ].filter(l => l !== null).join('\n');

    if (navigator.share) navigator.share({ title: inv.invoice_no, text: lines });
    else { navigator.clipboard?.writeText(lines); alert('Receipt copied to clipboard!'); }
  };

  return (
    <div style={{ height:'100%', display:'flex', flexDirection:'column', background:'#E8EAED' }}>
      {/* Header */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'var(--space-lg)', paddingTop:'calc(var(--safe-top)+16px)', background:'var(--surface)', borderBottom:'1px solid var(--border)' }}>
        <button onClick={()=>nav(-1)}
          className="icon-btn">✕</button>
        <span style={{ fontSize:16, fontWeight:700, color:'var(--on-surface)' }}>Receipt Preview</span>
        <button onClick={handleShare}
          className="icon-btn">📤</button>
      </div>

      {/* Paper receipt */}
      <div className="scroll" style={{ flex:1, padding:'var(--space-lg)', paddingBottom:100 }}>
        <div style={{ background:'#fff', borderRadius:6, padding:20, boxShadow:'0 2px 12px rgba(0,0,0,0.12)', fontFamily:'var(--font-mono)', color:'#111', maxWidth:340, margin:'0 auto' }}>
          {/* Store header */}
          <div style={{ textAlign:'center', marginBottom:8 }}>
            <div style={{ fontWeight:800, fontSize:16 }}>{store.store_name||'SRI DHARANI MOBILES'}</div>
            {store.store_tagline && <div style={{ fontSize:11, color:'#555', marginTop:2 }}>{store.store_tagline}</div>}
            {store.store_address && <div style={{ fontSize:11, color:'#555', marginTop:1 }}>{store.store_address}</div>}
            {store.store_phone   && <div style={{ fontSize:11, color:'#555', marginTop:1 }}>Ph: {store.store_phone}</div>}
            {store.gst_number    && <div style={{ fontSize:11, color:'#555', marginTop:1 }}>GSTIN: {store.gst_number}</div>}
          </div>
          <div style={{ borderTop:'1px dashed #bbb', margin:'8px 0' }} />

          {/* Invoice meta */}
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:11, marginBottom:2 }}>
            <span style={{ fontWeight:700 }}>{inv.invoice_no}</span>
            <span style={{ color:'#555' }}>{date}</span>
          </div>
          <div style={{ fontSize:11, marginBottom:1, color:'#333' }}>Customer: {inv.customer_name||'Walk-in'}</div>
          {inv.customer_phone && <div style={{ fontSize:11, marginBottom:1, color:'#333' }}>Phone: {inv.customer_phone}</div>}
          <div style={{ fontSize:11, marginBottom:4, fontWeight:700, color: inv.payment_mode==='Credit' && !inv.paid ? '#dc2626' : '#16a34a' }}>{formatPaymentStatus(inv)}</div>
          <div style={{ borderTop:'1px dashed #bbb', margin:'8px 0' }} />

          {/* Items header */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 40px 70px', fontSize:10, fontWeight:800, color:'#555', marginBottom:6, gap:4 }}>
            <span>ITEM</span><span style={{ textAlign:'right' }}>QTY</span><span style={{ textAlign:'right' }}>AMT</span>
          </div>

          {(inv.items||[]).map((it,i) => (
            <div key={i} style={{ display:'grid', gridTemplateColumns:'1fr 40px 70px', fontSize:11, marginBottom:4, gap:4, alignItems:'start' }}>
              <div>
                <div style={{ fontWeight:600, wordBreak:'break-word' }}>{it.name}</div>
                <div style={{ color:'#777', fontSize:10 }}>{formatCurrency(it.price)} × {it.qty}</div>
              </div>
              <span style={{ textAlign:'right', fontWeight:700 }}>×{it.qty}</span>
              <span style={{ textAlign:'right', fontWeight:700 }}>{formatCurrency(it.amount)}</span>
            </div>
          ))}

          <div style={{ borderTop:'1px dashed #bbb', margin:'8px 0' }} />

          {/* Totals */}
          {[
            ['Subtotal', formatCurrency(inv.subtotal)],
            inv.discount_amount > 0 && ['Discount', `-${formatCurrency(inv.discount_amount)}`],
            ['GST',      formatCurrency(inv.gst_amount)],
          ].filter(Boolean).map(([k,v]) => (
            <div key={k} style={{ display:'flex', justifyContent:'space-between', fontSize:11, marginBottom:2 }}>
              <span style={{ color:'#555' }}>{k}</span><span style={{ fontWeight:700 }}>{v}</span>
            </div>
          ))}
          <div style={{ borderTop:'2px solid #111', margin:'8px 0' }} />
          <div style={{ display:'flex', justifyContent:'space-between', fontWeight:800, fontSize:15 }}>
            <span>TOTAL</span><span>₹{inv.total.toFixed(2)}</span>
          </div>

          <div style={{ borderTop:'1px dashed #bbb', margin:'10px 0 6px' }} />
          {inv.payment_mode === 'UPI' && (
            <>
              <div style={{ textAlign:'center', fontWeight:800, fontSize:11, color:'#333', marginBottom:6 }}>SCAN TO PAY VIA UPI</div>
              {store.upi_qr_print_enabled !== '0' && store.upi_qr_image && (
                <div style={{ display:'flex', justifyContent:'center', marginBottom:6 }}>
                  <img src={store.upi_qr_image} alt="UPI QR" style={{ width:120, height:120, objectFit:'contain' }} />
                </div>
              )}
              {store.upi_id && <div style={{ textAlign:'center', fontSize:11, fontWeight:700, color:'#333', marginBottom:8 }}>{store.upi_id}</div>}
              <div style={{ borderTop:'1px dashed #bbb', margin:'8px 0' }} />
            </>
          )}
          <div style={{ textAlign:'center', fontSize:11, color:'#444' }}>{store.thank_you_msg||'Thank you!'}</div>
          {store.return_policy && <div style={{ textAlign:'center', fontSize:10, color:'#888', marginTop:4 }}>{store.return_policy}</div>}
          {!inv.paid && <div style={{ textAlign:'center', color:'#dc2626', fontWeight:800, fontSize:12, marginTop:8 }}>** UNPAID — CREDIT **</div>}
        </div>
      </div>

      {/* Print button */}
      <div style={{ position:'absolute', bottom:0, left:0, right:0, background:'var(--surface)', borderTop:'1px solid var(--border)', padding:'var(--space-md) var(--space-lg)', paddingBottom:'calc(var(--space-md) + var(--safe-bottom))' }}>
        <button onClick={handleBTPrint} disabled={printing}
          style={{ width:'100%', display:'flex', alignItems:'center', justifyContent:'center', gap:10, padding:16, borderRadius:'var(--radius-lg)', background:'var(--brand)', border:'none', cursor:'pointer', color:'var(--on-brand)', fontFamily:'var(--font)', fontWeight:800, fontSize:15, opacity:printing?0.7:1 }}>
          {printing ? '⏳ Printing…' : '🖨️ Print via Bluetooth'}
        </button>
      </div>

      {/* Brief success confirmation right after checkout */}
      {showSuccess && (
        <div onClick={()=>setShowSuccess(false)} style={{ position:'absolute', inset:0, background:'rgba(0,0,0,0.55)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:200 }}>
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:14 }}>
            <div className="anim-check-pop anim-check-ring" style={{ width:84, height:84, borderRadius:42, background:'var(--success)', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <svg width={42} height={42} viewBox="0 0 24 24" fill="none" stroke="#04220F" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
            </div>
            <div style={{ color:'#fff', fontWeight:800, fontSize:16 }}>Sale Completed!</div>
          </div>
        </div>
      )}
    </div>
  );
}
