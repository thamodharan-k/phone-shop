import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { listRepairTickets, formatCurrency } from '../db/database.js';

const STATUSES = ['All','Received','In-Progress','Ready','Delivered','Cancelled'];
const COLORS = { Received:'#7BB7FF','In-Progress':'#FFB84D',Ready:'#B8FF5E',Delivered:'#5EE5A0',Cancelled:'#FF5E78' };

const PrintIcon = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="6 9 6 2 18 2 18 9"/>
    <path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/>
    <rect x="6" y="14" width="12" height="8"/>
  </svg>
);

export default function Repairs() {
  const nav = useNavigate();
  const [tickets, setTickets] = useState([]);
  const [filter, setFilter] = useState('All');

  const load = useCallback(async () => {
    setTickets(await listRepairTickets());
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = filter === 'All' ? tickets : tickets.filter(t => t.status === filter);

  return (
    <div style={{ height:'100%', display:'flex', flexDirection:'column', background:'var(--surface)' }}>
      <div style={{ padding:'var(--space-lg)', paddingTop:'calc(var(--safe-top)+16px)', borderBottom:'1px solid var(--border)' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'var(--space-md)' }}>
          <span style={{ fontSize:28, fontWeight:800, color:'var(--on-surface)' }}>Repairs</span>
          <button onClick={()=>nav('/repair-ticket')} style={{ width:40, height:40, borderRadius:20, background:'var(--brand)', border:'none', cursor:'pointer', fontSize:20, color:'var(--on-brand)', display:'flex', alignItems:'center', justifyContent:'center' }}>+</button>
        </div>
        <div className="scroll-x" style={{ display:'flex', gap:8, height:40, alignItems:'center' }}>
          {STATUSES.map(st=>(
            <button key={st} onClick={()=>setFilter(st)} style={{ flexShrink:0, height:36, padding:'0 var(--space-md)', borderRadius:'var(--radius-pill)', background:filter===st?'var(--brand)':'var(--surface-secondary)', border:'none', cursor:'pointer', fontFamily:'var(--font)', fontWeight:700, fontSize:12, color:filter===st?'var(--on-brand)':'var(--on-surface)', whiteSpace:'nowrap' }}>{st}</button>
          ))}
        </div>
      </div>

      <div className="scroll" style={{ flex:1, padding:'var(--space-lg)', display:'flex', flexDirection:'column', gap:'var(--space-md)', paddingBottom:'calc(var(--tab-height) + 16px)' }}>
        {filtered.length===0 ? (
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', padding:'64px 0', gap:8 }}>
            <span style={{ fontSize:48 }}>🔧</span>
            <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:16 }}>No repair tickets</div>
            <div style={{ color:'var(--muted)' }}>Tap + to create a new ticket</div>
          </div>
        ) : filtered.map((t,i) => {
          const color = COLORS[t.status]||'#7BB7FF';
          const outstanding = t.total_cost - t.paid_amount;
          return (
            <div key={t.id} onClick={()=>nav('/repair-ticket',{state:{id:t.id}})} className="anim-fade-up" style={{ animationDelay:`${i*0.03}s`, background:'var(--surface-secondary)', border:'1px solid var(--border)', borderRadius:'var(--radius-lg)', padding:'var(--space-md)', cursor:'pointer', display:'flex', gap:'var(--space-md)', alignItems:'flex-start' }}>
              <div style={{ width:40, height:40, borderRadius:20, background:color+'22', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, fontSize:18 }}>🔧</div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:4 }}>
                  <span style={{ color:'var(--muted)', fontSize:11, fontWeight:700 }}>{t.ticket_no}</span>
                  <span style={{ padding:'2px 8px', borderRadius:999, background:color+'22', color, fontSize:10, fontWeight:800 }}>{t.status}</span>
                </div>
                <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:15 }}>{t.customer_name}</div>
                <div style={{ color:'var(--muted-strong)', fontSize:12, marginTop:2 }}>{t.device_model}</div>
                {t.issue && <div style={{ color:'var(--muted)', fontSize:11, marginTop:4 }}>{t.issue}</div>}
              </div>
              <div style={{ textAlign:'right', flexShrink:0, display:'flex', flexDirection:'column', alignItems:'flex-end', gap:6 }}>
                <div style={{ color:'var(--brand)', fontWeight:800, fontSize:14 }}>{formatCurrency(t.total_cost)}</div>
                {outstanding>0 && <div style={{ color:'var(--error)', fontSize:11, fontWeight:700 }}>Due: {formatCurrency(outstanding)}</div>}
                {(t.paid_amount || 0) > 0 && (
                  <button
                    onClick={(e) => { e.stopPropagation(); nav(`/repair-receipt/${t.id}`); }}
                    title="Print bill"
                    style={{
                      width:30, height:30, borderRadius:9,
                      background:'var(--brand-soft)', border:'1.5px solid var(--brand)55',
                      cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center',
                      color:'var(--brand)',
                    }}>
                    <PrintIcon size={14} />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
