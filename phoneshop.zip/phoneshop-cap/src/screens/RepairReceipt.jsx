import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { listRepairTickets, getAllSettings, formatCurrency, formatPaymentStatus } from '../db/database.js';
import * as BT from '../printer/bluetooth.js';

export default function RepairReceipt() {
  const { id } = useParams();
  const nav    = useNavigate();
  const [ticket,   setTicket]   = useState(null);
  const [store,    setStore]    = useState({});
  const [printing, setPrinting] = useState(false);

  useEffect(() => {
    (async () => {
      const [all, s] = await Promise.all([listRepairTickets(), getAllSettings()]);
      setTicket(all.find(t => t.id === id) || null);
      setStore(s);
    })();
  }, [id]);

  if (!ticket) return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%', color:'var(--muted)', background:'var(--surface)' }}>
      Loading bill…
    </div>
  );

  const date    = new Date(ticket.updated_at || ticket.created_at).toLocaleString('en-IN');
  const balance = Math.max(0, parseFloat((ticket.total_cost - ticket.paid_amount).toFixed(2)));

  const handleBTPrint = async () => {
    if (!store.bt_printer_address) {
      alert('No printer paired. Go to Settings → Hardware.');
      return;
    }
    setPrinting(true);
    try {
      const { ok, reason } = await BT.ensureEnabled();
      if (!ok) { alert(reason || 'Bluetooth unavailable.'); return; }
      await BT.connect(store.bt_printer_address);
      await BT.printRepairReceipt({
        store_name:    store.store_name,
        store_address: store.store_address,
        store_phone:   store.store_phone,
        ticket_no:     ticket.ticket_no,
        date,
        customer:      ticket.customer_name,
        phone:         ticket.customer_phone,
        device_model:  ticket.device_model,
        imei:          ticket.imei,
        issue:         ticket.issue,
        parts:         ticket.parts,
        labour_charge: ticket.labour_charge,
        parts_cost:    ticket.parts_cost,
        total_cost:    ticket.total_cost,
        paid_amount:   ticket.paid_amount,
        balance_due:   balance,
        status:        ticket.status,
        payment_mode:  ticket.payment_mode || 'Cash',
        upi_id:        store.upi_id,
        upi_qr_image:  store.upi_qr_print_enabled !== '0' ? store.upi_qr_image : '',
      }, parseInt(store.paper_width || '57', 10));
      // Auto-close after print, return to previous screen
      nav(-1);
    } catch(e) {
      alert('Print error: ' + e.message);
    } finally {
      setPrinting(false);
    }
  };

  const handleShare = () => {
    const lines = [
      store.store_name || 'SRI DHARANI MOBILES',
      'REPAIR JOB RECEIPT',
      `${ticket.ticket_no} | ${date}`,
      `Customer: ${ticket.customer_name}${ticket.customer_phone ? ' | ' + ticket.customer_phone : ''}`,
      '─'.repeat(32),
      `Device: ${ticket.device_model}`,
      ticket.imei ? `IMEI: ${ticket.imei}` : null,
      ticket.issue ? `Issue: ${ticket.issue}` : null,
      ticket.parts ? `Parts: ${ticket.parts}` : null,
      '─'.repeat(32),
      `Labour:      ${formatCurrency(ticket.labour_charge)}`,
      `Parts Cost:  ${formatCurrency(ticket.parts_cost)}`,
      `TOTAL:       ${formatCurrency(ticket.total_cost)}`,
      `Paid:        ${formatCurrency(ticket.paid_amount)}`,
      balance > 0 ? `BALANCE DUE: ${formatCurrency(balance)}` : '** FULLY PAID **',
    ].filter(l => l !== null).join('\n');

    if (navigator.share) navigator.share({ title: ticket.ticket_no, text: lines });
    else { navigator.clipboard?.writeText(lines); alert('Receipt copied to clipboard!'); }
  };

  return (
    <div style={{ height:'100%', display:'flex', flexDirection:'column', background:'#E8EAED' }}>
      {/* Header */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'var(--space-lg)', paddingTop:'calc(var(--safe-top)+16px)', background:'var(--surface)', borderBottom:'1px solid var(--border)' }}>
        <button onClick={()=>nav(-1)} className="icon-btn">✕</button>
        <span style={{ fontSize:16, fontWeight:700, color:'var(--on-surface)' }}>Repair Bill</span>
        <button onClick={handleShare} className="icon-btn">📤</button>
      </div>

      {/* Paper receipt */}
      <div className="scroll" style={{ flex:1, padding:'var(--space-lg)', paddingBottom:100 }}>
        <div style={{ background:'#fff', borderRadius:6, padding:20, boxShadow:'0 2px 12px rgba(0,0,0,0.12)', fontFamily:'var(--font-mono)', color:'#111', maxWidth:340, margin:'0 auto' }}>
          {/* Store header */}
          <div style={{ textAlign:'center', marginBottom:8 }}>
            <div style={{ fontWeight:800, fontSize:16 }}>{store.store_name||'SRI DHARANI MOBILES'}</div>
            {store.store_address && <div style={{ fontSize:11, color:'#555', marginTop:2 }}>{store.store_address}</div>}
            {store.store_phone   && <div style={{ fontSize:11, color:'#555', marginTop:1 }}>Ph: {store.store_phone}</div>}
          </div>
          <div style={{ borderTop:'1px dashed #bbb', margin:'8px 0' }} />

          <div style={{ textAlign:'center', fontWeight:800, fontSize:12, letterSpacing:0.5, color:'#333', marginBottom:6 }}>
            REPAIR JOB RECEIPT
          </div>
          <div style={{ borderTop:'1px dashed #bbb', margin:'8px 0' }} />

          {/* Ticket meta */}
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:11, marginBottom:2 }}>
            <span style={{ fontWeight:700 }}>{ticket.ticket_no}</span>
            <span style={{ color:'#555' }}>{date}</span>
          </div>
          <div style={{ fontSize:11, marginBottom:1, color:'#333' }}>Customer: {ticket.customer_name}</div>
          {ticket.customer_phone && <div style={{ fontSize:11, marginBottom:1, color:'#333' }}>Phone: {ticket.customer_phone}</div>}
          <div style={{ fontSize:11, marginBottom:4, color:'#333' }}>Status: {ticket.status}</div>
          <div style={{ fontSize:11, marginBottom:4, fontWeight:700, color: ticket.payment_mode==='Credit' && balance>0 ? '#dc2626' : '#16a34a' }}>{formatPaymentStatus(ticket)}</div>
          <div style={{ borderTop:'1px dashed #bbb', margin:'8px 0' }} />

          {/* Device */}
          <div style={{ fontWeight:800, fontSize:11, marginBottom:2 }}>DEVICE</div>
          <div style={{ fontSize:12, fontWeight:600, marginBottom:1 }}>{ticket.device_model}</div>
          {ticket.imei && <div style={{ fontSize:11, color:'#555' }}>IMEI: {ticket.imei}</div>}

          {ticket.issue && (
            <>
              <div style={{ borderTop:'1px dashed #bbb', margin:'8px 0' }} />
              <div style={{ fontWeight:800, fontSize:11, marginBottom:2 }}>ISSUE REPORTED</div>
              <div style={{ fontSize:11, color:'#333', wordBreak:'break-word' }}>{ticket.issue}</div>
            </>
          )}

          {ticket.parts && (
            <>
              <div style={{ borderTop:'1px dashed #bbb', margin:'8px 0' }} />
              <div style={{ fontWeight:800, fontSize:11, marginBottom:2 }}>PARTS USED</div>
              <div style={{ fontSize:11, color:'#333', wordBreak:'break-word' }}>{ticket.parts}</div>
            </>
          )}

          <div style={{ borderTop:'1px dashed #bbb', margin:'8px 0' }} />

          {/* Cost breakdown */}
          {[
            ['Labour Charge', formatCurrency(ticket.labour_charge)],
            ['Parts Cost',    formatCurrency(ticket.parts_cost)],
          ].map(([k,v]) => (
            <div key={k} style={{ display:'flex', justifyContent:'space-between', fontSize:11, marginBottom:2 }}>
              <span style={{ color:'#555' }}>{k}</span><span style={{ fontWeight:700 }}>{v}</span>
            </div>
          ))}
          <div style={{ borderTop:'2px solid #111', margin:'8px 0' }} />
          <div style={{ display:'flex', justifyContent:'space-between', fontWeight:800, fontSize:15 }}>
            <span>TOTAL</span><span>{formatCurrency(ticket.total_cost)}</span>
          </div>

          <div style={{ borderTop:'1px dashed #bbb', margin:'8px 0' }} />
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:11, marginBottom:2 }}>
            <span style={{ color:'#555' }}>Amount Paid</span>
            <span style={{ fontWeight:700, color:'#16a34a' }}>{formatCurrency(ticket.paid_amount)}</span>
          </div>

          {balance > 0 ? (
            <div style={{ display:'flex', justifyContent:'space-between', fontWeight:800, fontSize:13, marginTop:4 }}>
              <span style={{ color:'#dc2626' }}>BALANCE DUE</span>
              <span style={{ color:'#dc2626' }}>{formatCurrency(balance)}</span>
            </div>
          ) : (
            <div style={{ textAlign:'center', color:'#16a34a', fontWeight:800, fontSize:12, marginTop:8 }}>
              ** FULLY PAID **
            </div>
          )}

          <div style={{ borderTop:'1px dashed #bbb', margin:'10px 0 6px' }} />
          {ticket.payment_mode === 'UPI' && (
            <>
              <div style={{ textAlign:'center', fontWeight:800, fontSize:11, color:'#333', marginBottom:6 }}>SCAN TO PAY VIA UPI</div>
              {store.upi_qr_print_enabled !== '0' && store.upi_qr_image && (
                <div style={{ display:'flex', justifyContent:'center', marginBottom:6 }}>
                  <img src={store.upi_qr_image} alt="UPI QR" style={{ width:120, height:120, objectFit:'contain' }} />
                </div>
              )}
              {store.upi_id && <div style={{ textAlign:'center', fontSize:11, fontWeight:700, color:'#333', marginBottom:8 }}>{store.upi_id}</div>}
              <div style={{ borderTop:'1px dashed #bbb', margin:'8px 0' }} />
            </>
          )}
          <div style={{ textAlign:'center', fontSize:11, color:'#444' }}>Thank you for your business!</div>
          <div style={{ textAlign:'center', fontSize:10, color:'#888', marginTop:4 }}>Please retain this receipt.</div>
        </div>
      </div>

      {/* Print button */}
      <div style={{ position:'absolute', bottom:0, left:0, right:0, background:'var(--surface)', borderTop:'1px solid var(--border)', padding:'var(--space-md) var(--space-lg)', paddingBottom:'calc(var(--space-md) + var(--safe-bottom))' }}>
        <button onClick={handleBTPrint} disabled={printing}
          style={{ width:'100%', display:'flex', alignItems:'center', justifyContent:'center', gap:10, padding:16, borderRadius:'var(--radius-lg)', background:'var(--brand)', border:'none', cursor:'pointer', color:'var(--on-brand)', fontFamily:'var(--font)', fontWeight:800, fontSize:15, opacity:printing?0.7:1 }}>
          {printing ? '⏳ Printing…' : '🖨️ Print via Bluetooth'}
        </button>
      </div>
    </div>
  );
}
