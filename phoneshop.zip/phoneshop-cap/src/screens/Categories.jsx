// Categories.jsx — standalone route (navigated to from AddProduct etc.)
// The main Inventory tab now has its own embedded Categories tab,
// but this route is kept for deep-link compatibility.
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';

// Redirect straight to the Inventory screen's Categories tab
export default function Categories() {
  const nav = useNavigate();
  useEffect(() => { nav('/products', { replace: true, state: { tab: 'categories' } }); }, [nav]);
  return null;
}
