import { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  listProducts, listCategories, deleteProduct,
  deleteCategory, updateCategory, addCategory,
  getCategoryProductCount, getSetting, formatCurrency,
} from '../db/database.js';
import { useSheetOpen } from '../utils/sheetRegistry.js';

// ─── Constants ───────────────────────────────────────────────────────────────
const CAT_ICON_MAP = {
  Smartphones:'📱', Audio:'🎧', 'Power & Charging':'🔋',
  Accessories:'🔌', 'Cases & Covers':'🛡️', Tablets:'📲',
  Smartwatches:'⌚', Laptops:'💻', Gaming:'🎮', Cameras:'📷',
};
const ICON_OPTS = [
  // Core mobile shop
  '📱','📲','☎️','📞','🔋','🔌','⚡','🎧','🎤','🔊',
  '⌚','💻','🖥️','🖱️','⌨️','🖨️','📠','🕹️','🎮','📷',
  '📹','🛡️','🔧','🔩','🛠️','📡','💡','🧲','🔍','🪫',
  // Accessories & cases
  '🎒','👜','🧰','📦','🗂️','🏷️','💎','⭐','🎁','🏠',
  // Screens / SIM / storage
  '🖼️','💳','💾','📶','🛰️','🪪','🔐','🔑','🆔','🧷',
];

const stockColor = (n, crit, low) =>
  n <= 0 ? 'var(--error)' : n <= crit ? 'var(--error)' : n <= low ? 'var(--warning)' : 'var(--success)';

const catIcon = (c) => c?.icon || CAT_ICON_MAP[c?.name] || '📦';

// ─── Shared back SVG ─────────────────────────────────────────────────────────
const BackIcon = () => (
  <svg width={18} height={18} viewBox="0 0 24 24" fill="none"
    strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="15 18 9 12 15 6"/>
  </svg>
);

// ─── Add / Edit Category Sheet ───────────────────────────────────────────────
function CategorySheet({ initial, onSave, onClose }) {
  useSheetOpen(true);
  const [name, setName]     = useState(initial?.name || '');
  const [icon, setIcon]     = useState(initial?.icon || '🏷️');
  const [saving, setSaving] = useState(false);
  const isEdit = Boolean(initial?.id);

  const save = async () => {
    if (!name.trim()) return alert('Category name is required.');
    setSaving(true);
    try {
      await onSave(name.trim(), icon);
      onClose();
    } catch(e) { alert(e.message); }
    finally { setSaving(false); }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-sheet" onClick={e => e.stopPropagation()}>
        <div className="modal-handle" />
        <div style={{ fontSize:18, fontWeight:800, color:'var(--on-surface)', marginBottom:'var(--space-lg)' }}>
          {isEdit ? 'Edit Category' : 'New Category'}
        </div>

        <div className="label">NAME *</div>
        <input className="input" value={name} onChange={e=>setName(e.target.value)}
          placeholder="e.g. Smartphones" autoFocus style={{ marginBottom:16 }} />

        <div className="label">ICON</div>
        <div style={{ display:'flex', flexWrap:'wrap', gap:8, marginBottom:20 }}>
          {ICON_OPTS.map(ic => (
            <button key={ic} onClick={()=>setIcon(ic)} style={{
              width:46, height:46, borderRadius:'var(--radius-md)',
              background: icon===ic ? 'var(--brand-soft)' : 'var(--surface-tertiary)',
              border:`2px solid ${icon===ic ? 'var(--brand)' : 'transparent'}`,
              cursor:'pointer', fontSize:22,
              display:'flex', alignItems:'center', justifyContent:'center',
              transition:'all 0.12s',
            }}>{ic}</button>
          ))}
        </div>

        <button className="btn-primary" style={{ width:'100%' }} onClick={save} disabled={saving}>
          {saving ? 'Saving…' : isEdit ? 'Save Changes' : 'Add Category'}
        </button>
      </div>
    </div>
  );
}

// ─── Delete Confirm Modal ─────────────────────────────────────────────────────
function DeleteConfirm({ cat, prodCount, onConfirm, onClose }) {
  useSheetOpen(true);
  const [input, setInput] = useState('');
  const ready = input.toLowerCase() === 'delete';
  return (
    <div className="modal-overlay">
      <div style={{
        background:'var(--surface-secondary)', borderRadius:'var(--radius-lg)',
        padding:'var(--space-xl)', margin:'var(--space-lg)', width:'calc(100% - 32px)',
      }}>
        <div style={{ fontSize:17, fontWeight:800, color:'var(--on-surface)', marginBottom:8 }}>
          Delete "{cat.name}"?
        </div>
        <div style={{ color:'var(--muted)', marginBottom:16, lineHeight:1.6, fontSize:14 }}>
          This will permanently delete this category and{' '}
          <strong style={{ color:'var(--error)' }}>{prodCount} product{prodCount!==1?'s':''}</strong> inside it.
          This cannot be undone.{'\n\n'}
          Type <strong style={{ color:'var(--on-surface)' }}>delete</strong> to confirm.
        </div>
        <input className="input" value={input} onChange={e=>setInput(e.target.value)}
          placeholder="Type 'delete' here" autoCapitalize="none"
          style={{ marginBottom:16 }} autoFocus />
        <div style={{ display:'flex', gap:10 }}>
          <button className="btn-ghost" style={{ flex:1 }} onClick={onClose}>Cancel</button>
          <button onClick={()=>ready && onConfirm()} style={{
            flex:1, padding:12, borderRadius:'var(--radius-md)',
            background:'var(--error)', border:'none', cursor:'pointer',
            color:'#fff', fontWeight:700, fontFamily:'var(--font)',
            opacity: ready ? 1 : 0.35, transition:'opacity 0.15s',
          }}>Delete</button>
        </div>
      </div>
    </div>
  );
}

// ─── CATEGORY PRODUCTS (drill-down list) ──────────────────────────────────────
function CategoryProducts({ cat, products, critical, low, onBack, onReload }) {
  const nav = useNavigate();
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    let list = products.filter(p => p.category_id === cat.id);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(p =>
        p.name.toLowerCase().includes(q) || (p.location||'').toLowerCase().includes(q)
      );
    }
    return list;
  }, [products, cat.id, query]);

  const handleDelete = (p) => {
    if (!confirm(`Delete "${p.name}"? This cannot be undone.`)) return;
    deleteProduct(p.id).then(onReload);
  };

  return (
    <div style={{ flex:1, display:'flex', flexDirection:'column', minHeight:0 }}>
      {/* Sub-header */}
      <div style={{ display:'flex', alignItems:'center', gap:'var(--space-md)', padding:'var(--space-md) var(--space-lg)' }}>
        <button onClick={onBack} className="icon-btn" title="Back to categories">
          <BackIcon />
        </button>
        <div style={{
          width:40, height:40, borderRadius:'var(--radius-md)',
          background:'var(--brand-soft)', border:'1.5px solid var(--brand)33',
          display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, flexShrink:0,
        }}>{catIcon(cat)}</div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ color:'var(--on-surface)', fontWeight:800, fontSize:16 }}>{cat.name}</div>
          <div style={{ color:'var(--muted)', fontSize:11 }}>{filtered.length} product{filtered.length!==1?'s':''}</div>
        </div>
        <button onClick={()=>nav('/add-product', { state:{ defaultCategoryId: cat.id } })}
          style={{
            display:'flex', alignItems:'center', gap:6,
            background:'var(--brand)', color:'var(--on-brand)',
            border:'none', borderRadius:'var(--radius-md)',
            padding:'8px 12px', fontFamily:'var(--font)',
            fontWeight:700, fontSize:12, cursor:'pointer', flexShrink:0,
          }}>
          <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Add Product
        </button>
      </div>

      {/* Search */}
      <div style={{ padding:'0 var(--space-lg) var(--space-md)' }}>
        <div style={{
          display:'flex', alignItems:'center',
          background:'var(--surface-secondary)', border:'1.5px solid var(--border-strong)',
          borderRadius:'var(--radius-lg)', padding:'0 var(--space-md)', height:44, gap:8,
        }}>
          <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="var(--muted)" strokeWidth="2.5" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input value={query} onChange={e=>setQuery(e.target.value)}
            placeholder={`Search in ${cat.name}…`}
            style={{ flex:1, background:'none', border:'none', outline:'none', color:'var(--on-surface)', fontFamily:'var(--font)', fontSize:14 }} />
          {query && (
            <button onClick={()=>setQuery('')} style={{ background:'none', border:'none', color:'var(--muted)', cursor:'pointer', fontSize:18, lineHeight:1 }}>✕</button>
          )}
        </div>
      </div>

      {/* Product list */}
      <div className="scroll" style={{ flex:1, padding:'0 var(--space-lg)', paddingBottom:'calc(var(--tab-height) + 16px)', display:'flex', flexDirection:'column', gap:'var(--space-md)' }}>
        {filtered.length === 0 ? (
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', padding:'64px 0', gap:12 }}>
            <span style={{ fontSize:48 }}>{catIcon(cat)}</span>
            <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:16 }}>
              {query ? 'No results' : `No products in ${cat.name} yet`}
            </div>
            <div style={{ color:'var(--muted)', fontSize:13 }}>
              {query ? 'Try a different search' : 'Tap Add to create the first one'}
            </div>
          </div>
        ) : filtered.map((p, i) => {
          const sc = stockColor(p.stock, critical, low);
          return (
            <div key={p.id} className="anim-fade-up" style={{ animationDelay:`${i*0.02}s`,
              display:'flex', alignItems:'center',
              background:'var(--surface-secondary)', border:'1.5px solid var(--border)',
              borderRadius:'var(--radius-lg)', padding:'var(--space-md)', gap:'var(--space-md)',
            }}>
              <div style={{
                width:48, height:48, borderRadius:'var(--radius-md)',
                background:'var(--brand-soft)', border:'1px solid var(--brand)22',
                display:'flex', alignItems:'center', justifyContent:'center',
                fontSize:22, flexShrink:0,
              }}>{catIcon(cat)}</div>

              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:14, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{p.name}</div>
                <div style={{ display:'flex', alignItems:'center', gap:6, marginTop:4, flexWrap:'wrap' }}>
                  {p.location && (
                    <span style={{ display:'flex', alignItems:'center', gap:3, color:'var(--muted)', fontSize:11 }}>
                      <svg width={10} height={10} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                      {p.location}
                    </span>
                  )}
                  <span style={{
                    padding:'2px 8px', borderRadius:'var(--radius-pill)',
                    background:sc+'1A', color:sc, fontSize:10, fontWeight:800,
                  }}>{p.stock} in stock</span>
                </div>
                <div style={{ color:'var(--brand)', fontWeight:800, fontSize:14, marginTop:4 }}>
                  {formatCurrency(p.price)}
                </div>
              </div>

              <div style={{ display:'flex', flexDirection:'column', gap:6, flexShrink:0 }}>
                <button onClick={()=>nav('/add-product',{state:{id:p.id}})} className="icon-btn" title="Edit" style={{ width:34, height:34, borderRadius:10 }}>
                  <svg width={14} height={14} viewBox="0 0 24 24" fill="none" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>
                    <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
                  </svg>
                </button>
                <button onClick={()=>handleDelete(p)} style={{
                  width:34, height:34, borderRadius:10,
                  background:'var(--error-soft)', border:'1.5px solid var(--error)44',
                  cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center',
                }} title="Delete">
                  <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="var(--error)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="3 6 5 6 21 6"/>
                    <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
                    <path d="M10 11v6M14 11v6"/>
                    <path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/>
                  </svg>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── CATEGORIES TAB (grid) ─────────────────────────────────────────────────────
function CategoriesTab({ cats, catCounts, products, critical, low, onReload }) {
  const [sheet, setSheet]   = useState(null);   // null | 'add' | categoryObj (edit)
  const [delCat, setDelCat] = useState(null);
  const [prodCount, setProdCount] = useState(0);
  const [openCat, setOpenCat] = useState(null); // category currently drilled into

  const startDelete = async (c, e) => {
    e.stopPropagation();
    const n = await getCategoryProductCount(c.id);
    setProdCount(n); setDelCat(c);
  };

  const startEdit = (c, e) => {
    e.stopPropagation();
    setSheet(c);
  };

  const doDelete = async () => {
    await deleteCategory(delCat.id);
    setDelCat(null);
    if (openCat?.id === delCat.id) setOpenCat(null);
    onReload();
  };

  const doSave = async (name, icon) => {
    if (sheet === 'add') {
      await addCategory(name, icon);
    } else {
      await updateCategory(sheet.id, name, icon);
      // keep drill-down view in sync if we just edited the open category
      if (openCat?.id === sheet.id) setOpenCat(prev => ({ ...prev, name, icon }));
    }
    onReload();
  };

  // ── Drill-down view ──
  if (openCat) {
    return (
      <>
        <CategoryProducts
          cat={openCat}
          products={products}
          critical={critical}
          low={low}
          onBack={() => setOpenCat(null)}
          onReload={onReload}
        />
      </>
    );
  }

  // ── Grid view ──
  return (
    <div style={{ flex:1, display:'flex', flexDirection:'column', minHeight:0, position:'relative' }}>
      <div className="scroll" style={{ flex:1, padding:'var(--space-md) var(--space-lg)', paddingBottom:'calc(var(--tab-height) + 90px)' }}>
        {cats.length === 0 ? (
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', padding:'64px 0', gap:12 }}>
            <span style={{ fontSize:52 }}>📁</span>
            <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:16 }}>No categories yet</div>
            <div style={{ color:'var(--muted)', fontSize:13 }}>Tap "New Category" below to create your first one</div>
          </div>
        ) : (
          <div style={{ display:'grid', gridTemplateColumns:'repeat(2, 1fr)', gap:'var(--space-md)' }}>
            {cats.map((c, i) => (
              <div
                key={c.id}
                role="button"
                tabIndex={0}
                onClick={() => setOpenCat(c)}
                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setOpenCat(c); } }}
                className="anim-fade-up"
                style={{
                  animationDelay:`${i*0.03}s`,
                  display:'flex', flexDirection:'column', alignItems:'flex-start',
                  background:'var(--surface-secondary)', border:'1.5px solid var(--border)',
                  borderRadius:'var(--radius-xl)', padding:'var(--space-lg)',
                  cursor:'pointer', fontFamily:'var(--font)', textAlign:'left',
                  position:'relative', minHeight:148,
                  transition:'border-color 0.15s, transform 0.1s',
                }}
                onMouseDown={e=>e.currentTarget.style.transform='scale(0.97)'}
                onMouseUp={e=>e.currentTarget.style.transform='scale(1)'}
                onTouchStart={e=>e.currentTarget.style.transform='scale(0.97)'}
                onTouchEnd={e=>e.currentTarget.style.transform='scale(1)'}
              >
                {/* Top row: icon + action buttons */}
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', width:'100%' }}>
                  <div style={{
                    width:52, height:52, borderRadius:'var(--radius-md)',
                    background:'var(--brand-soft)', border:'1.5px solid var(--brand)33',
                    display:'flex', alignItems:'center', justifyContent:'center',
                    fontSize:26, flexShrink:0,
                  }}>{catIcon(c)}</div>

                  <div style={{ display:'flex', gap:4 }}>
                    <button onClick={(e)=>startEdit(c, e)} className="icon-btn" title="Edit" style={{ width:30, height:30, borderRadius:9 }}>
                      <svg width={12} height={12} viewBox="0 0 24 24" fill="none" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>
                        <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
                      </svg>
                    </button>
                    <button onClick={(e)=>startDelete(c, e)} style={{
                      width:30, height:30, borderRadius:9,
                      background:'var(--error-soft)', border:'1.5px solid var(--error)44',
                      cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center',
                    }} title="Delete">
                      <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="var(--error)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="3 6 5 6 21 6"/>
                        <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
                        <path d="M10 11v6M14 11v6"/>
                        <path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/>
                      </svg>
                    </button>
                  </div>
                </div>

                {/* Name + count */}
                <div style={{ marginTop:'auto', paddingTop:'var(--space-md)', width:'100%' }}>
                  <div style={{ color:'var(--on-surface)', fontWeight:800, fontSize:15, lineHeight:1.25 }}>{c.name}</div>
                  <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginTop:6 }}>
                    <span style={{ color:'var(--muted)', fontSize:11, fontWeight:600 }}>
                      {catCounts[c.id] || 0} item{(catCounts[c.id]||0)!==1?'s':''}
                    </span>
                    <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="9 18 15 12 9 6"/>
                    </svg>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* FAB — New Category (lifted above the bottom tab bar) */}
      <button onClick={()=>setSheet('add')} aria-label="New Category" title="New Category" style={{
        position:'absolute', bottom:'calc(var(--tab-height) + 20px)', right:24,
        width:58, height:58, borderRadius:29,
        display:'flex', alignItems:'center', justifyContent:'center',
        background:'var(--brand)', color:'var(--on-brand)',
        border:'none', cursor:'pointer',
        boxShadow:'0 6px 20px var(--brand-soft)',
        zIndex:40,
      }}>
        <svg width={26} height={26} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
          <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
        </svg>
      </button>

      {/* Sheets / Modals */}
      {sheet && (
        <CategorySheet
          initial={sheet === 'add' ? null : sheet}
          onSave={doSave}
          onClose={()=>setSheet(null)}
        />
      )}
      {delCat && (
        <DeleteConfirm cat={delCat} prodCount={prodCount} onConfirm={doDelete} onClose={()=>setDelCat(null)} />
      )}
    </div>
  );
}

// ─── ALL PRODUCTS TAB ────────────────────────────────────────────────────────
function AllProductsTab({ products, cats, critical, low, onReload }) {
  const nav = useNavigate();
  const [filterCat, setFilterCat] = useState(null); // null = All
  const [query, setQuery]         = useState('');

  const filtered = useMemo(() => {
    let list = filterCat ? products.filter(p => p.category_id === filterCat) : products;
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(p =>
        p.name.toLowerCase().includes(q) ||
        (p.location||'').toLowerCase().includes(q)
      );
    }
    return list;
  }, [products, filterCat, query]);

  const handleDelete = (p) => {
    if (!confirm(`Delete "${p.name}"? This cannot be undone.`)) return;
    deleteProduct(p.id).then(onReload);
  };

  return (
    <div style={{ flex:1, display:'flex', flexDirection:'column', minHeight:0 }}>
      {/* Search */}
      <div style={{ padding:'var(--space-md) var(--space-lg)', paddingTop:'var(--space-sm)' }}>
        <div style={{
          display:'flex', alignItems:'center',
          background:'var(--surface-secondary)', border:'1.5px solid var(--border-strong)',
          borderRadius:'var(--radius-lg)', padding:'0 var(--space-md)', height:44, gap:8,
        }}>
          <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="var(--muted)" strokeWidth="2.5" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input value={query} onChange={e=>setQuery(e.target.value)}
            placeholder="Search products…"
            style={{ flex:1, background:'none', border:'none', outline:'none', color:'var(--on-surface)', fontFamily:'var(--font)', fontSize:14 }} />
          {query && (
            <button onClick={()=>setQuery('')} style={{ background:'none', border:'none', color:'var(--muted)', cursor:'pointer', fontSize:18, lineHeight:1 }}>✕</button>
          )}
        </div>
      </div>

      {/* Category filter chips */}
      <div className="scroll-x" style={{ padding:'0 var(--space-lg) var(--space-md)', display:'flex', gap:8, flexShrink:0 }}>
        {[{ id:null, name:'All', count:products.length },...cats.map(c=>({...c,count:products.filter(p=>p.category_id===c.id).length}))].map(c => (
          <button key={c.id||'all'} onClick={()=>setFilterCat(c.id)} style={{
            flexShrink:0, height:34, padding:'0 14px',
            borderRadius:'var(--radius-pill)',
            background: filterCat===c.id ? 'var(--brand)' : 'var(--surface-secondary)',
            border:`1.5px solid ${filterCat===c.id ? 'transparent' : 'var(--border-strong)'}`,
            cursor:'pointer', fontFamily:'var(--font)', fontWeight:700, fontSize:12,
            color: filterCat===c.id ? 'var(--on-brand)' : 'var(--on-surface)',
            display:'flex', alignItems:'center', gap:6, whiteSpace:'nowrap',
            transition:'all 0.15s',
          }}>
            {c.icon ? <span>{c.icon}</span> : null}
            {c.name}
            <span style={{
              background: filterCat===c.id ? 'rgba(255,255,255,0.25)' : 'var(--surface-tertiary)',
              color: filterCat===c.id ? 'var(--on-brand)' : 'var(--muted)',
              borderRadius:10, padding:'1px 6px', fontSize:10, fontWeight:800,
            }}>{c.count}</span>
          </button>
        ))}
      </div>

      {/* Count */}
      <div style={{ padding:'0 var(--space-lg) var(--space-sm)', color:'var(--muted)', fontSize:11, fontWeight:700, letterSpacing:0.5 }}>
        {filtered.length} PRODUCT{filtered.length!==1?'S':''}
      </div>

      {/* List */}
      <div className="scroll" style={{ flex:1, padding:'0 var(--space-lg)', paddingBottom:'calc(var(--tab-height) + 16px)', display:'flex', flexDirection:'column', gap:'var(--space-md)' }}>
        {filtered.length === 0 ? (
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', padding:'64px 0', gap:12 }}>
            <span style={{ fontSize:48 }}>📦</span>
            <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:16 }}>
              {query ? 'No results' : 'No products yet'}
            </div>
            <div style={{ color:'var(--muted)', fontSize:13 }}>
              {query ? 'Try a different search' : 'Add products from the Categories tab'}
            </div>
          </div>
        ) : filtered.map((p, i) => {
          const sc = stockColor(p.stock, critical, low);
          return (
            <div key={p.id} className="anim-fade-up" style={{ animationDelay:`${i*0.02}s`,
              display:'flex', alignItems:'center',
              background:'var(--surface-secondary)', border:'1.5px solid var(--border)',
              borderRadius:'var(--radius-lg)', padding:'var(--space-md)', gap:'var(--space-md)',
            }}>
              {/* Icon */}
              <div style={{
                width:48, height:48, borderRadius:'var(--radius-md)',
                background:'var(--brand-soft)', border:'1px solid var(--brand)22',
                display:'flex', alignItems:'center', justifyContent:'center',
                fontSize:22, flexShrink:0,
              }}>
                {CAT_ICON_MAP[p.category_name] || '📦'}
              </div>

              {/* Details */}
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:14, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{p.name}</div>
                <div style={{ display:'flex', alignItems:'center', gap:6, marginTop:4, flexWrap:'wrap' }}>
                  {p.location && (
                    <span style={{ display:'flex', alignItems:'center', gap:3, color:'var(--muted)', fontSize:11 }}>
                      <svg width={10} height={10} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                      {p.location}
                    </span>
                  )}
                  <span style={{
                    padding:'2px 8px', borderRadius:'var(--radius-pill)',
                    background:sc+'1A', color:sc, fontSize:10, fontWeight:800,
                  }}>{p.stock} in stock</span>
                </div>
                <div style={{ color:'var(--brand)', fontWeight:800, fontSize:14, marginTop:4 }}>
                  {formatCurrency(p.price)}
                </div>
              </div>

              {/* Actions */}
              <div style={{ display:'flex', flexDirection:'column', gap:6, flexShrink:0 }}>
                <button onClick={()=>nav('/add-product',{state:{id:p.id}})} className="icon-btn" title="Edit" style={{ width:34, height:34, borderRadius:10 }}>
                  <svg width={14} height={14} viewBox="0 0 24 24" fill="none" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>
                    <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
                  </svg>
                </button>
                <button onClick={()=>handleDelete(p)} style={{
                  width:34, height:34, borderRadius:10,
                  background:'var(--error-soft)', border:'1.5px solid var(--error)44',
                  cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center',
                }} title="Delete">
                  <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="var(--error)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="3 6 5 6 21 6"/>
                    <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
                    <path d="M10 11v6M14 11v6"/>
                    <path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/>
                  </svg>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── ROOT ─────────────────────────────────────────────────────────────────────
export default function Products() {
  const nav = useNavigate();
  const loc = useLocation();
  const [tab, setTab]         = useState(loc.state?.tab === 'categories' ? 'categories' : 'products'); // 'products' | 'categories'
  const [products, setProducts] = useState([]);
  const [cats, setCats]         = useState([]);
  const [critical, setCritical] = useState(2);
  const [low, setLow]           = useState(5);

  const load = useCallback(async () => {
    const [p, c, crit, lowT] = await Promise.all([
      listProducts(), listCategories(),
      getSetting('critical_stock'), getSetting('low_stock'),
    ]);
    setProducts(p); setCats(c);
    setCritical(parseInt(crit||'2',10)); setLow(parseInt(lowT||'5',10));
  }, []);

  useEffect(() => { load(); }, [load]);

  const catCounts = useMemo(() => {
    const m = {};
    products.forEach(p => { if (p.category_id) m[p.category_id] = (m[p.category_id]||0)+1; });
    return m;
  }, [products]);

  return (
    <div style={{ height:'100%', display:'flex', flexDirection:'column', background:'var(--surface)', position:'relative' }}>

      {/* ── Header ── */}
      <div style={{
        background:'var(--surface)', borderBottom:'1.5px solid var(--border)',
        paddingTop:'calc(var(--safe-top) + 12px)',
      }}>
        {/* Title + Add button (context-aware) */}
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'0 var(--space-lg)', paddingBottom:'var(--space-md)' }}>
          <span style={{ fontSize:22, fontWeight:900, color:'var(--on-surface)', letterSpacing:-0.5 }}>Inventory</span>
          {tab === 'products' && (
            <button onClick={()=>nav('/add-product')} style={{
              display:'flex', alignItems:'center', gap:6,
              background:'var(--brand)', color:'var(--on-brand)',
              border:'none', borderRadius:'var(--radius-md)',
              padding:'8px 14px', fontFamily:'var(--font)',
              fontWeight:700, fontSize:13, cursor:'pointer',
            }}>
              <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              Add Product
            </button>
          )}
        </div>

        {/* Tab bar */}
        <div style={{ display:'flex', padding:'0 var(--space-lg)', gap:'var(--space-sm)' }}>
          {[
            { key:'products',   label:'All Products', icon:'📦', count: products.length },
            { key:'categories', label:'Categories', icon:'📁', count: cats.length },
          ].map(t => (
            <button key={t.key} onClick={()=>setTab(t.key)} style={{
              flex:1, display:'flex', alignItems:'center', justifyContent:'center', gap:6,
              padding:'10px 0', borderBottom:`2.5px solid ${tab===t.key ? 'var(--brand)' : 'transparent'}`,
              background:'none', borderLeft:'none', borderRight:'none', borderTop:'none',
              cursor:'pointer', fontFamily:'var(--font)', fontWeight:700, fontSize:13,
              color: tab===t.key ? 'var(--brand)' : 'var(--muted-strong)',
              transition:'color 0.15s',
            }}>
              <span>{t.icon}</span>
              {t.label}
              <span style={{
                background: tab===t.key ? 'var(--brand-soft)' : 'var(--surface-tertiary)',
                color: tab===t.key ? 'var(--brand)' : 'var(--muted)',
                borderRadius:10, padding:'1px 7px', fontSize:10, fontWeight:800,
              }}>{t.count}</span>
            </button>
          ))}
        </div>
      </div>

      {/* ── Tab content ── */}
      {tab === 'categories' ? (
        <CategoriesTab cats={cats} catCounts={catCounts} products={products} critical={critical} low={low} onReload={load} />
      ) : (
        <AllProductsTab products={products} cats={cats} critical={critical} low={low} onReload={load} />
      )}
    </div>
  );
}
