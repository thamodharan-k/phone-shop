import { useState } from 'react';
import { getSetting } from '../db/database.js';

export default function PinLock({ onUnlock }) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [shakeKey, setShakeKey] = useState(0);

  const handleKey = async (k) => {
    if (k === 'del') { setPin(p => p.slice(0,-1)); setError(''); return; }
    const next = pin + k;
    setPin(next);
    if (next.length === 4) {
      const saved = await getSetting('pin_code');
      if (next === saved) onUnlock();
      else { setError('Incorrect PIN'); setPin(''); setShakeKey(k => k + 1); }
    }
  };

  return (
    <div style={{ height:'100%', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', background:'var(--surface)', gap:32 }}>
      <div style={{ textAlign:'center' }}>
        <div style={{ fontSize:28, fontWeight:900, color:'var(--on-surface)' }}>SRI DHARANI MOBILES</div>
        <div style={{ color:'var(--muted)', marginTop:8 }}>Enter PIN to unlock</div>
      </div>

      <div key={shakeKey} className={shakeKey ? 'anim-shake' : ''} style={{ display:'flex', gap:16 }}>
        {[0,1,2,3].map(i => (
          <div key={i} style={{ width:16, height:16, borderRadius:8, background: i<pin.length?'var(--brand)':'var(--surface-tertiary)', border:`2px solid ${error ? 'var(--error)' : 'var(--border)'}`, transition:'background 0.15s, border-color 0.15s' }} />
        ))}
      </div>

      {error && <div style={{ color:'var(--error)', fontWeight:600, fontSize:14 }}>{error}</div>}

      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,72px)', gap:12 }}>
        {['1','2','3','4','5','6','7','8','9','','0','del'].map((k,i) => (
          <button key={i} onClick={()=>k&&handleKey(k)} style={{ width:72, height:72, borderRadius:36, background:k?'var(--surface-secondary)':'transparent', border:k?'1px solid var(--border)':'none', cursor:k?'pointer':'default', color:'var(--on-surface)', fontFamily:'var(--font)', fontSize:k==='del'?20:22, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center' }}>
            {k==='del'?'⌫':k}
          </button>
        ))}
      </div>
    </div>
  );
}
