import { useEffect, useRef, useState, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { getProductByBarcode } from '../db/database.js';
import { useCart } from '../state/context.jsx';
import { playBeep } from '../utils/sound.js';
import { setPendingBarcode } from '../utils/scanBridge.js';

export default function Scanner() {
  const nav      = useNavigate();
  const loc      = useLocation();
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const intervalRef = useRef(null);
  const [status, setStatus] = useState('Initializing camera…');
  const [torch,  setTorch]  = useState(false);
  const [scanned, setScanned] = useState(false); // prevents double-scan
  const { addItem } = useCart();

  const returnTo   = loc.state?.returnTo;

  // ── Stop camera cleanly ──────────────────────────────────────────────────
  const stopCamera = useCallback(() => {
    if (intervalRef.current) { clearInterval(intervalRef.current); intervalRef.current = null; }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, []);

  // ── Close scanner and navigate ────────────────────────────────────────────
  const closeAndNav = useCallback((to, opts) => {
    stopCamera();
    if (to === -1) nav(-1);
    else nav(to, opts);
  }, [stopCamera, nav]);

  // ── Handle detected barcode ───────────────────────────────────────────────
  const handleBarcode = useCallback(async (code) => {
    if (scanned) return; // prevent firing twice
    setScanned(true);
    stopCamera();        // stop camera immediately after scan
    playBeep();
    setStatus(`✓ Found: ${code}`);

    if (returnTo === 'add-product') {
      // Go back to the Add Product screen that's already in history (rather
      // than pushing/replacing another '/add-product' entry on top of it —
      // that used to leave two stacked entries pointing at the same screen,
      // which made the later "Save & Add" nav(-1) silently no-op).
      setPendingBarcode(code);
      nav(-1);
      return;
    }

    const product = await getProductByBarcode(code);
    if (product) {
      if (product.stock <= 0) {
        alert(`${product.name} is out of stock.`);
        closeAndNav(-1);
        return;
      }
      addItem(product);
      nav(returnTo === 'products' ? '/products' : '/cart');
    } else {
      nav('/add-product', { state: { barcode: code, returnTo: returnTo || 'cart' } });
    }
  }, [scanned, stopCamera, playBeep, returnTo, nav, addItem]);

  // ── Start camera ──────────────────────────────────────────────────────────
  useEffect(() => {
    (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
        });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        setStatus('Point at a barcode…');

        if ('BarcodeDetector' in window) {
          const detector = new window.BarcodeDetector({
            formats: ['ean_13', 'ean_8', 'code_128', 'qr_code', 'upc_a', 'upc_e'],
          });
          intervalRef.current = setInterval(async () => {
            if (!videoRef.current || scanned) return;
            try {
              const barcodes = await detector.detect(videoRef.current);
              if (barcodes.length > 0) {
                await handleBarcode(barcodes[0].rawValue);
              }
            } catch (_) {}
          }, 300);
        } else {
          setStatus('BarcodeDetector not supported on this device.');
        }
      } catch (e) {
        setStatus('Camera access denied. Please enable in browser settings.');
      }
    })();

    return () => {
      stopCamera();
    }; // cleanup on unmount
  }, []);                      // run once only

  // ── Torch toggle ──────────────────────────────────────────────────────────
  const toggleTorch = async () => {
    if (!streamRef.current) return;
    const track = streamRef.current.getVideoTracks()[0];
    try {
      await track.applyConstraints({ advanced: [{ torch: !torch }] });
      setTorch(!torch);
    } catch (_) { alert('Torch not supported on this device.'); }
  };

  return (
    <div style={{ height:'100%', background:'#000', position:'relative', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center' }}>
      <video ref={videoRef} style={{ position:'absolute', inset:0, width:'100%', height:'100%', objectFit:'cover' }} playsInline muted />

      {/* Dark overlay */}
      <div style={{ position:'absolute', inset:0, background:'rgba(0,0,0,0.6)' }} />

      {/* Scan frame */}
      <div style={{ position:'relative', width:280, height:180, borderRadius:12, border:'2px solid var(--brand)', boxShadow:'0 0 0 9999px rgba(0,0,0,0.6), 0 0 32px var(--brand-soft)', display:'flex', alignItems:'center', justifyContent:'center' }}>
        <div style={{ position:'absolute', top:-1,    left:0,   width:32, height:32, borderTop:'4px solid var(--brand)', borderLeft:'4px solid var(--brand)', borderRadius:'12px 0 0 0' }} />
        <div style={{ position:'absolute', top:-1,    right:0,  width:32, height:32, borderTop:'4px solid var(--brand)', borderRight:'4px solid var(--brand)', borderRadius:'0 12px 0 0' }} />
        <div style={{ position:'absolute', bottom:-1, left:0,   width:32, height:32, borderBottom:'4px solid var(--brand)', borderLeft:'4px solid var(--brand)', borderRadius:'0 0 0 12px' }} />
        <div style={{ position:'absolute', bottom:-1, right:0,  width:32, height:32, borderBottom:'4px solid var(--brand)', borderRight:'4px solid var(--brand)', borderRadius:'0 0 12px 0' }} />
        <div className="anim-scan-line" style={{ position:'absolute', left:8, right:8, height:2, background:'var(--brand)', boxShadow:'0 0 8px var(--brand)' }} />
      </div>

      <div style={{ position:'relative', marginTop:24, color:'#fff', fontWeight:600, fontSize:14, textAlign:'center', padding:'0 24px' }}>{status}</div>

      {/* Controls */}
      <div style={{ position:'absolute', top:0, left:0, right:0, display:'flex', justifyContent:'space-between', alignItems:'center', padding:'calc(var(--safe-top) + 16px) var(--space-lg) 16px' }}>
        <button onClick={() => closeAndNav(-1)} style={{ width:44, height:44, borderRadius:22, background:'rgba(0,0,0,0.6)', border:'1px solid rgba(255,255,255,0.2)', color:'#fff', fontSize:18, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }}>✕</button>
        <button onClick={toggleTorch} style={{ width:44, height:44, borderRadius:22, background: torch ? 'var(--brand)' : 'rgba(0,0,0,0.6)', border:'1px solid rgba(255,255,255,0.2)', color: torch ? 'var(--on-brand)' : '#fff', fontSize:18, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }}>🔦</button>
      </div>

      <style>{`@keyframes scanLine { 0%,100%{transform:translateY(-60px)} 50%{transform:translateY(60px)} }`}</style>
    </div>
  );
}
