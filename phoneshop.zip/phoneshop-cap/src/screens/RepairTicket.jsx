import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { createRepairTicket, updateRepairTicket, listRepairTickets, deleteRepairTicket, getAllSettings, formatCurrency } from '../db/database.js';
import UpiPaymentModal from '../components/UpiPaymentModal.jsx';

const STATUSES = ['Received','In-Progress','Ready','Delivered','Cancelled'];
const COLORS   = { Received:'#7BB7FF','In-Progress':'#FFB84D',Ready:'#B8FF5E',Delivered:'#5EE5A0',Cancelled:'#FF5E78' };
const PAY_MODES = ['Cash', 'UPI', 'Card', 'Credit'];

export default function RepairTicket() {
  const nav = useNavigate();
  const loc = useLocation();
  const editId = loc.state?.id || null;

  const [customer, setCustomer] = useState('');
  const [phone, setPhone]       = useState('');
  const [device, setDevice]     = useState('');
  const [imei, setImei]         = useState('');
  const [issue, setIssue]       = useState('');
  const [parts, setParts]       = useState('');
  const [labour, setLabour]     = useState('');
  const [partsCost, setPartsCost] = useState('');
  const [paid, setPaid]         = useState('');
  const [status, setStatus]     = useState('Received');
  const [notes, setNotes]       = useState('');
  const [saving, setSaving]     = useState(false);
  const [payMode, setPayMode]   = useState('Cash');
  const [upiInfo, setUpiInfo]   = useState({ upi_id:'', upi_qr_image:'' });
  const [showUpiModal, setShowUpiModal] = useState(false);

  useEffect(() => {
    getAllSettings().then(s => setUpiInfo({ upi_id: s.upi_id || '', upi_qr_image: s.upi_qr_image || '' }));
  }, []);

  useEffect(() => {
    if (!editId) return;
    (async () => {
      const all = await listRepairTickets();
      const t = all.find(x => x.id === editId);
      if (!t) return;
      setCustomer(t.customer_name);
      // Older/newer records may store the phone with a country code (e.g.
      // "+919876543210"); the editable field only ever holds the 10-digit
      // local number, with +91 shown as a fixed prefix — so take the last
      // 10 digits regardless of what's stored.
      const digits = (t.customer_phone || '').replace(/\D/g, '');
      setPhone(digits.length > 10 ? digits.slice(-10) : digits);
      setDevice(t.device_model);
      setImei(t.imei||''); setIssue(t.issue||''); setParts(t.parts||'');
      setLabour(String(t.labour_charge)); setPartsCost(String(t.parts_cost));
      setPaid(String(t.paid_amount)); setStatus(t.status); setNotes(t.notes||'');
      setPayMode(t.payment_mode || 'Cash');
    })();
  }, [editId]);

  const total = (parseFloat(labour)||0) + (parseFloat(partsCost)||0);

  const save = async () => {
    if (!customer.trim()) return alert('Customer name required.');
    if (!device.trim())   return alert('Device model required.');
    if (phone.length > 0 && phone.length !== 10) return alert('Phone number must be exactly 10 digits (or left blank).');
    setSaving(true);
    try {
      const data = { customer_name:customer, customer_phone: phone ? `+91${phone}` : '', device_model:device, imei, issue, parts, labour_charge:parseFloat(labour)||0, parts_cost:parseFloat(partsCost)||0, paid_amount:parseFloat(paid)||0, status, notes, payment_mode:payMode };
      if (editId) await updateRepairTicket(editId, data);
      else await createRepairTicket(data);
      nav(-1);
    } catch(e) { alert('Save failed: '+e.message); }
    finally { setSaving(false); }
  };

  const handleDelete = async () => {
    if (!confirm('Delete this repair ticket?')) return;
    await deleteRepairTicket(editId);
    nav(-1);
  };

  return (
    <div style={{ height:'100%', display:'flex', flexDirection:'column', background:'var(--surface)' }}>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'var(--space-lg)', paddingTop:'calc(var(--safe-top)+16px)', borderBottom:'1px solid var(--border)' }}>
        <button onClick={()=>nav(-1)} className="icon-btn">✕</button>
        <span style={{ fontSize:16, fontWeight:700, color:'var(--on-surface)' }}>{editId?'Edit Ticket':'New Repair'}</span>
        {editId ? <button onClick={handleDelete} style={{ background:'none', border:'none', color:'var(--error)', fontSize:18, cursor:'pointer' }}>🗑️</button> : <div style={{ width:36 }} />}
      </div>

      <div className="scroll" style={{ flex:1, padding:'var(--space-lg)', display:'flex', flexDirection:'column', gap:'var(--space-md)', paddingBottom:80 }}>
        <F label="CUSTOMER NAME *" v={customer} s={setCustomer} />
        <F label="PHONE" v={phone} s={v=>setPhone(v.replace(/[^0-9]/g,'').slice(0,10))} type="tel" prefix="+91"
          error={phone.length > 0 && phone.length < 10 ? 'Enter a valid 10-digit number' : null} />
        <F label="DEVICE MODEL *" v={device} s={setDevice} placeholder="e.g. iPhone 14, Samsung S23" />
        <F label="IMEI / Serial No." v={imei} s={setImei} />
        <F label="ISSUE" v={issue} s={setIssue} multiline placeholder="Describe the problem" />
        <F label="PARTS USED" v={parts} s={setParts} multiline placeholder="List any parts replaced" />

        <div style={{ display:'flex', gap:'var(--space-md)' }}>
          <div style={{ flex:1 }}><F label="LABOUR (₹)" v={labour} s={setLabour} type="number" placeholder="0" /></div>
          <div style={{ flex:1 }}><F label="PARTS COST (₹)" v={partsCost} s={setPartsCost} type="number" placeholder="0" /></div>
        </div>

        <div style={{ background:'var(--brand-soft)', borderRadius:'var(--radius-md)', padding:'var(--space-md)', display:'flex', justifyContent:'space-between' }}>
          <span style={{ color:'var(--muted)', fontWeight:600 }}>Total Cost</span>
          <span style={{ color:'var(--brand)', fontWeight:800, fontSize:16 }}>{formatCurrency(total)}</span>
        </div>

        <F label="AMOUNT PAID (₹)" v={paid} s={setPaid} type="number" placeholder="0" />

        <div>
          <div className="label">PAYMENT MODE</div>
          <div style={{ display:'flex', gap:6 }}>
            {PAY_MODES.map(m => (
              <button key={m} onClick={()=>setPayMode(m)} style={{
                flex:1, padding:'9px 4px', borderRadius:'var(--radius-md)',
                background: payMode===m ? 'var(--surface-inverse)' : 'var(--surface-tertiary)',
                border:`1.5px solid ${payMode===m ? 'var(--border-strong)' : 'var(--border)'}`,
                cursor:'pointer', color: payMode===m ? 'var(--on-surface-inverse)' : 'var(--on-surface)',
                fontWeight:700, fontSize:11, fontFamily:'var(--font)', transition:'all 0.15s',
              }}>{m}</button>
            ))}
          </div>
          {payMode === 'UPI' && (
            <button
              onClick={()=>setShowUpiModal(true)}
              style={{ width:'100%', marginTop:8, display:'flex', alignItems:'center', justifyContent:'center', gap:8, padding:12, borderRadius:'var(--radius-md)', background:'var(--brand-soft)', border:'1.5px solid var(--brand)', cursor:'pointer', fontFamily:'var(--font)', fontWeight:700, fontSize:13, color:'var(--brand)' }}>
              📱 Show UPI QR to Customer
            </button>
          )}
        </div>

        {/* Generate Bill — only once a payment has been recorded on a saved ticket */}
        {editId && (parseFloat(paid) || 0) > 0 && (
          <button
            onClick={() => nav(`/repair-receipt/${editId}`)}
            style={{
              display:'flex', alignItems:'center', justifyContent:'center', gap:8,
              padding:14, borderRadius:'var(--radius-lg)',
              background:'var(--surface-tertiary)', border:'2px solid var(--brand)',
              cursor:'pointer', fontFamily:'var(--font)', fontWeight:800, fontSize:14,
              color:'var(--brand)',
            }}>
            <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="6 9 6 2 18 2 18 9"/>
              <path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/>
              <rect x="6" y="14" width="12" height="8"/>
            </svg>
            Generate & Print Bill
          </button>
        )}

        <div>
          <div className="label">STATUS</div>
          <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
            {STATUSES.map(st=>(
              <button key={st} onClick={()=>setStatus(st)} style={{ padding:'8px 14px', borderRadius:'var(--radius-pill)', background:status===st?(COLORS[st]+'44'):'var(--surface-tertiary)', border:`1px solid ${status===st?COLORS[st]:'transparent'}`, cursor:'pointer', fontFamily:'var(--font)', fontWeight:700, fontSize:12, color:status===st?COLORS[st]:'var(--muted)', whiteSpace:'nowrap' }}>{st}</button>
            ))}
          </div>
        </div>

        <F label="NOTES" v={notes} s={setNotes} multiline />

        <button className="btn-primary" style={{ padding:16, borderRadius:'var(--radius-lg)', fontSize:15 }} onClick={save} disabled={saving}>
          {saving?'Saving…':editId?'Save Changes':'Create Ticket'}
        </button>
      </div>

      {showUpiModal && (
        <UpiPaymentModal
          amount={(parseFloat(labour)||0) + (parseFloat(partsCost)||0)}
          upiId={upiInfo.upi_id}
          qrImage={upiInfo.upi_qr_image}
          onConfirm={()=>setShowUpiModal(false)}
          onClose={()=>setShowUpiModal(false)}
        />
      )}
    </div>
  );
}

function F({ label, v, s, type='text', placeholder='', multiline, prefix, error }) {
  return (
    <div>
      <div className="label">{label}</div>
      {multiline
        ? <textarea value={v} onChange={e=>s(e.target.value)} placeholder={placeholder} style={{ width:'100%', background:'var(--surface-secondary)', border:'1px solid var(--border)', borderRadius:'var(--radius-md)', padding:'10px var(--space-md)', color:'var(--on-surface)', fontFamily:'var(--font)', fontSize:14, minHeight:72, resize:'vertical', outline:'none' }} />
        : prefix
          ? (
            <div style={{ display:'flex', alignItems:'stretch', border:'1.5px solid var(--border-strong)', borderRadius:'var(--radius-md)', overflow:'hidden' }}>
              <span style={{ display:'flex', alignItems:'center', padding:'0 var(--space-md)', background:'var(--surface-tertiary)', color:'var(--muted)', fontWeight:700, fontSize:14, borderRight:'1px solid var(--divider)' }}>
                {prefix}
              </span>
              <input className="input" value={v} onChange={e=>s(e.target.value)} type={type} placeholder={placeholder} maxLength={10}
                style={{ border:'none', borderRadius:0, flex:1 }} />
            </div>
          )
          : <input className="input" value={v} onChange={e=>s(e.target.value)} type={type} placeholder={placeholder} />
      }
      {error && <div style={{ marginTop:4, fontSize:11, color:'var(--error)' }}>{error}</div>}
    </div>
  );
}
