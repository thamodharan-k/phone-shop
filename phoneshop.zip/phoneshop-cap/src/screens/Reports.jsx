import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  listInvoices, getInvoiceWithItems, getAllSettings,
  recordPayment, markInvoicePaid, formatCurrency, formatPaymentStatus,
  listInvoicesForDate,
  listRepairTickets, listRepairTicketsForDate, getRevenueBreakdown,
} from '../db/database.js';
import { useSheetOpen } from '../utils/sheetRegistry.js';

const RANGES = [
  { label:'Today', ms: 86400000 },
  { label:'Week',  ms: 604800000 },
  { label:'Month', ms: 2592000000 },
  { label:'All',   ms: 9999999999999 },
];

// ─── Helpers ───────────────────────────────────────────────────────────────
const getPaidAmount = (inv) => inv.paid_amount ?? (inv.paid ? inv.total : 0);
const getBalance    = (inv) => Math.max(0, parseFloat((inv.total - getPaidAmount(inv)).toFixed(2)));

// ─── Collect Payment Panel (shown inside BillDetail for unpaid Credit bills) ──
function CollectPayment({ inv, onPaid }) {
  const [amount, setAmount]   = useState('');
  const [busy, setBusy]       = useState(false);
  const balance = getBalance(inv);

  const handlePartial = async () => {
    const n = parseFloat(amount);
    if (isNaN(n) || n <= 0) { alert('Enter a valid amount.'); return; }
    if (n > balance + 0.01) { alert(`Amount cannot exceed balance due of ${formatCurrency(balance)}.`); return; }
    setBusy(true);
    try {
      const result = await recordPayment(inv.id, n);
      onPaid(result);
      setAmount('');
    } catch(e) { alert(e.message); }
    finally { setBusy(false); }
  };

  const handleFullyPaid = async () => {
    if (!confirm(`Mark this bill as fully paid? Remaining balance: ${formatCurrency(balance)}`)) return;
    setBusy(true);
    try {
      const result = await markInvoicePaid(inv.id);
      onPaid(result);
    } catch(e) { alert(e.message); }
    finally { setBusy(false); }
  };

  return (
    <div style={{
      background:'var(--error-soft)', border:'1.5px solid var(--error)44',
      borderRadius:'var(--radius-lg)', padding:'var(--space-md)',
      marginBottom:'var(--space-md)', display:'flex', flexDirection:'column', gap:'var(--space-md)',
    }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <span style={{ color:'var(--error)', fontWeight:800, fontSize:13, letterSpacing:0.3 }}>
          🔴 CREDIT — BALANCE DUE
        </span>
        <span style={{ color:'var(--error)', fontWeight:900, fontSize:18 }}>{formatCurrency(balance)}</span>
      </div>

      {getPaidAmount(inv) > 0 && (
        <div style={{ display:'flex', justifyContent:'space-between', fontSize:12, color:'var(--muted)' }}>
          <span>Already paid</span>
          <span style={{ fontWeight:700, color:'var(--on-surface)' }}>{formatCurrency(getPaidAmount(inv))} of {formatCurrency(inv.total)}</span>
        </div>
      )}

      <div style={{ display:'flex', gap:8 }}>
        <input
          className="input" type="number" min="0" max={balance}
          value={amount} onChange={e => setAmount(e.target.value)}
          placeholder={`Enter amount (max ${formatCurrency(balance)})`}
          style={{ flex:1 }} disabled={busy}
        />
        <button
          onClick={handlePartial} disabled={busy || !amount}
          style={{
            padding:'0 18px', borderRadius:'var(--radius-md)',
            background:'var(--surface-inverse)', border:'none', cursor:'pointer',
            color:'var(--on-surface-inverse)', fontWeight:800, fontFamily:'var(--font)', fontSize:13,
            opacity: busy || !amount ? 0.5 : 1, whiteSpace:'nowrap',
          }}>
          Add Payment
        </button>
      </div>

      <button
        onClick={handleFullyPaid} disabled={busy}
        style={{
          width:'100%', padding:13, borderRadius:'var(--radius-md)',
          background:'var(--success)', border:'none', cursor:'pointer',
          color:'#04220F', fontWeight:800, fontFamily:'var(--font)', fontSize:14,
          display:'flex', alignItems:'center', justifyContent:'center', gap:8,
          opacity: busy ? 0.6 : 1,
        }}>
        <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="20 6 9 17 4 12"/>
        </svg>
        Mark Fully Paid
      </button>
    </div>
  );
}

// ─── Bill Detail Sheet ────────────────────────────────────────────────────────
function BillDetail({ inv: initialInv, store, onClose, onUpdated }) {
  const nav = useNavigate();
  const [inv, setInv] = useState(initialInv);
  useSheetOpen(true);
  const date = new Date(inv.created_at).toLocaleString('en-IN');
  const balance = getBalance(inv);
  const isUnpaidCredit = inv.payment_mode === 'Credit' && !inv.paid;

  const handlePaymentUpdate = (result) => {
    const updated = { ...inv, paid_amount: result.paid_amount, paid: result.paid ? 1 : 0 };
    setInv(updated);
    onUpdated && onUpdated(updated);
  };

  return (
    <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.75)', zIndex:500, display:'flex', flexDirection:'column', justifyContent:'flex-end' }}>
      <div style={{ background:'var(--surface-secondary)', borderRadius:'var(--radius-xl) var(--radius-xl) 0 0', maxHeight:'90vh', display:'flex', flexDirection:'column', animation:'slideUp 0.3s cubic-bezier(.32,1.2,.64,1)' }}>
        {/* Header */}
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'var(--space-lg)', borderBottom:'1.5px solid var(--border)' }}>
          <div>
            <div style={{ fontSize:16, fontWeight:800, color:'var(--on-surface)' }}>{inv.invoice_no}</div>
            <div style={{ color:'var(--muted)', fontSize:12, marginTop:2 }}>{date}</div>
          </div>
          <button onClick={onClose} className="icon-btn">✕</button>
        </div>

        <div className="scroll" style={{ flex:1, padding:'var(--space-lg)', paddingBottom:24 }}>
          {/* Store info */}
          <div style={{ background:'var(--surface-tertiary)', borderRadius:'var(--radius-md)', padding:'var(--space-md)', marginBottom:'var(--space-md)', fontFamily:'var(--font-mono)' }}>
            <div style={{ textAlign:'center', fontWeight:700, fontSize:15, color:'var(--on-surface)', marginBottom:4 }}>{store.store_name||'SRI DHARANI MOBILES'}</div>
            {store.store_address && <div style={{ textAlign:'center', color:'var(--muted)', fontSize:11 }}>{store.store_address}</div>}
            {store.store_phone   && <div style={{ textAlign:'center', color:'var(--muted)', fontSize:11 }}>Ph: {store.store_phone}</div>}
          </div>

          {/* ── Collect Payment — only for unpaid Credit bills ── */}
          {isUnpaidCredit && (
            <CollectPayment inv={inv} onPaid={handlePaymentUpdate} />
          )}

          {/* Customer details */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:'var(--space-md)' }}>
            {[
              ['Customer', inv.customer_name||'Walk-in'],
              ['Phone',    inv.customer_phone||'—'],
              ['Payment',  inv.payment_mode],
              ['Status',   formatPaymentStatus(inv)],
            ].map(([k,v]) => (
              <div key={k} style={{ background:'var(--surface-tertiary)', borderRadius:'var(--radius-md)', padding:'var(--space-sm) var(--space-md)' }}>
                <div style={{ color:'var(--muted)', fontSize:10, fontWeight:700, letterSpacing:0.5 }}>{k.toUpperCase()}</div>
                <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:13, marginTop:2 }}>{v}</div>
              </div>
            ))}
          </div>

          {/* Items */}
          <div style={{ fontSize:11, fontWeight:700, color:'var(--muted)', letterSpacing:0.5, marginBottom:8 }}>ITEMS</div>
          <div style={{ background:'var(--surface-secondary)', border:'1.5px solid var(--border)', borderRadius:'var(--radius-lg)', overflow:'hidden', marginBottom:'var(--space-md)' }}>
            <div style={{ display:'flex', padding:'var(--space-sm) var(--space-md)', background:'var(--surface-tertiary)', borderBottom:'1px solid var(--border)' }}>
              <span style={{ flex:1, color:'var(--muted)', fontSize:11, fontWeight:700 }}>ITEM</span>
              <span style={{ width:40, textAlign:'right', color:'var(--muted)', fontSize:11, fontWeight:700 }}>QTY</span>
              <span style={{ width:80, textAlign:'right', color:'var(--muted)', fontSize:11, fontWeight:700 }}>AMT</span>
            </div>
            {(inv.items||[]).map((it,i) => (
              <div key={i} style={{ display:'flex', alignItems:'center', padding:'var(--space-md)', borderBottom:i<(inv.items||[]).length-1?'1px solid var(--divider)':'none' }}>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ color:'var(--on-surface)', fontWeight:600, fontSize:13, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{it.name}</div>
                  <div style={{ color:'var(--muted)', fontSize:11 }}>{formatCurrency(it.price)} each</div>
                </div>
                <span style={{ width:40, textAlign:'right', color:'var(--muted-strong)', fontWeight:700, fontSize:13 }}>×{it.qty}</span>
                <span style={{ width:80, textAlign:'right', color:'var(--on-surface)', fontWeight:800, fontSize:13 }}>{formatCurrency(it.amount)}</span>
              </div>
            ))}
          </div>

          {/* Totals */}
          <div style={{ background:'var(--surface-secondary)', border:'1.5px solid var(--border)', borderRadius:'var(--radius-lg)', padding:'var(--space-md)', display:'flex', flexDirection:'column', gap:8 }}>
            {[
              ['Subtotal',  formatCurrency(inv.subtotal)],
              inv.discount_amount > 0 && ['Discount', `-${formatCurrency(inv.discount_amount)}`],
              ['GST',       formatCurrency(inv.gst_amount)],
            ].filter(Boolean).map(([k,v]) => (
              <div key={k} style={{ display:'flex', justifyContent:'space-between' }}>
                <span style={{ color:'var(--muted)', fontWeight:600, fontSize:13 }}>{k}</span>
                <span style={{ color:'var(--on-surface)', fontWeight:700, fontSize:13 }}>{v}</span>
              </div>
            ))}
            <div style={{ height:1.5, background:'var(--border-strong)', margin:'2px 0' }} />
            <div style={{ display:'flex', justifyContent:'space-between' }}>
              <span style={{ color:'var(--on-surface)', fontWeight:800, fontSize:16 }}>TOTAL</span>
              <span style={{ color:'var(--brand)', fontWeight:900, fontSize:18 }}>{formatCurrency(inv.total)}</span>
            </div>

            {/* Paid / Balance breakdown — only shown if not fully paid from the start */}
            {!inv.paid && (
              <>
                <div style={{ height:1, background:'var(--divider)', margin:'2px 0' }} />
                <div style={{ display:'flex', justifyContent:'space-between' }}>
                  <span style={{ color:'var(--muted)', fontWeight:600, fontSize:13 }}>Paid so far</span>
                  <span style={{ color:'var(--success)', fontWeight:700, fontSize:13 }}>{formatCurrency(getPaidAmount(inv))}</span>
                </div>
                <div style={{ display:'flex', justifyContent:'space-between' }}>
                  <span style={{ color:'var(--error)', fontWeight:700, fontSize:14 }}>Balance Due</span>
                  <span style={{ color:'var(--error)', fontWeight:900, fontSize:16 }}>{formatCurrency(balance)}</span>
                </div>
              </>
            )}
          </div>

          {/* Reprint an already-generated bill */}
          <button
            onClick={() => nav(`/receipt/${inv.id}`)}
            style={{
              width:'100%', marginTop:'var(--space-lg)',
              display:'flex', alignItems:'center', justifyContent:'center', gap:8,
              padding:15, borderRadius:'var(--radius-lg)',
              background:'var(--brand)', border:'none', cursor:'pointer',
              color:'var(--on-brand)', fontFamily:'var(--font)', fontWeight:800, fontSize:15,
            }}>
            <svg width={17} height={17} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="6 9 6 2 18 2 18 9"/>
              <path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/>
              <rect x="6" y="14" width="12" height="8"/>
            </svg>
            Print Bill
          </button>
        </div>
      </div>
      <style>{`@keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}`}</style>
    </div>
  );
}

// ─── Revenue Breakdown Modal ────────────────────────────────────────────────
function RevenueBreakdown({ data, rangeLabel, onClose }) {
  useSheetOpen(true);
  const modeRows = [
    { key:'Cash',   label:'Cash',   color:'var(--success)', icon:'💵' },
    { key:'UPI',    label:'UPI',    color:'var(--brand)',   icon:'📱' },
    { key:'Card',   label:'Card',   color:'var(--info)',    icon:'💳' },
    { key:'Credit', label:'Credit / Outstanding', color:'var(--warning)', icon:'🧾' },
  ];
  const total = data.total || 0;

  return (
    <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.75)', zIndex:500, display:'flex', flexDirection:'column', justifyContent:'flex-end' }} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{ background:'var(--surface-secondary)', borderRadius:'var(--radius-xl) var(--radius-xl) 0 0', maxHeight:'85vh', display:'flex', flexDirection:'column', animation:'slideUp 0.3s cubic-bezier(.32,1.2,.64,1)' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'var(--space-lg)', borderBottom:'1.5px solid var(--border)' }}>
          <div>
            <div style={{ fontSize:16, fontWeight:800, color:'var(--on-surface)' }}>Revenue Breakdown</div>
            <div style={{ color:'var(--muted)', fontSize:12, marginTop:2 }}>{rangeLabel}</div>
          </div>
          <button onClick={onClose} className="icon-btn">✕</button>
        </div>

        <div className="scroll" style={{ flex:1, padding:'var(--space-lg)', paddingBottom:24 }}>
          <div style={{ textAlign:'center', marginBottom:'var(--space-lg)' }}>
            <div style={{ color:'var(--muted)', fontSize:11, fontWeight:700, letterSpacing:0.5 }}>TOTAL REVENUE</div>
            <div style={{ color:'var(--brand)', fontWeight:900, fontSize:32, marginTop:4 }}>{formatCurrency(total)}</div>
            <div style={{ color:'var(--muted)', fontSize:12, marginTop:4 }}>
              {formatCurrency(data.sales_revenue)} sales · {formatCurrency(data.repair_revenue)} repairs
            </div>
          </div>

          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {modeRows.map(m => {
              const amt = data.by_mode?.[m.key] || 0;
              const pct = total > 0 ? Math.round((amt / total) * 100) : 0;
              return (
                <div key={m.key} style={{ background:'var(--surface-tertiary)', borderRadius:'var(--radius-lg)', padding:'var(--space-md)' }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
                    <span style={{ display:'flex', alignItems:'center', gap:8, color:'var(--on-surface)', fontWeight:700, fontSize:14 }}>
                      <span>{m.icon}</span>{m.label}
                    </span>
                    <span style={{ color:m.color, fontWeight:900, fontSize:16 }}>{formatCurrency(amt)}</span>
                  </div>
                  <div style={{ height:6, background:'var(--surface)', borderRadius:3, overflow:'hidden' }}>
                    <div style={{ width:`${pct}%`, height:'100%', background:m.color, borderRadius:3, transition:'width 0.3s' }} />
                  </div>
                  <div style={{ color:'var(--muted)', fontSize:10, fontWeight:600, marginTop:4 }}>{pct}% of total</div>
                </div>
              );
            })}
          </div>

          <div style={{ display:'flex', gap:'var(--space-md)', marginTop:'var(--space-lg)' }}>
            <div style={{ flex:1, background:'var(--surface-tertiary)', borderRadius:'var(--radius-md)', padding:'var(--space-md)', textAlign:'center' }}>
              <div style={{ color:'var(--on-surface)', fontWeight:900, fontSize:16 }}>{data.sales_count}</div>
              <div style={{ color:'var(--muted)', fontSize:10, fontWeight:700, marginTop:2 }}>SALES BILLS</div>
            </div>
            <div style={{ flex:1, background:'var(--surface-tertiary)', borderRadius:'var(--radius-md)', padding:'var(--space-md)', textAlign:'center' }}>
              <div style={{ color:'var(--on-surface)', fontWeight:900, fontSize:16 }}>{data.repair_count}</div>
              <div style={{ color:'var(--muted)', fontSize:10, fontWeight:700, marginTop:2 }}>REPAIR BILLS</div>
            </div>
          </div>
        </div>
      </div>
      <style>{`@keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}`}</style>
    </div>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────
export default function Reports() {
  const nav = useNavigate();
  const [invoices, setInvoices] = useState([]);
  const [repairs,  setRepairs]  = useState([]);
  const [revenue,  setRevenue]  = useState({ total:0, sales_revenue:0, repair_revenue:0, by_mode:{}, sales_count:0, repair_count:0 });
  const [range,    setRange]    = useState(0);
  const [fromDate, setFromDate] = useState(''); // 'YYYY-MM-DD' — set together, override `range` when both present
  const [toDate,   setToDate]   = useState('');
  const [selected, setSelected] = useState(null);
  const [store,    setStore]    = useState({});
  const [showRevenue, setShowRevenue] = useState(false);

  const hasCustomRange = !!fromDate; // a single date alone is valid — treated as that one day
  const effectiveTo = toDate || fromDate;

  const load = useCallback(async () => {
    if (hasCustomRange) {
      // Guard against the user picking From after To — swap so the query always makes sense
      const [from, to] = fromDate <= effectiveTo ? [fromDate, effectiveTo] : [effectiveTo, fromDate];
      const [inv, rep, rev, s] = await Promise.all([
        listInvoicesForDate(from, to), listRepairTicketsForDate(from, to),
        getRevenueBreakdown(null, from, to), getAllSettings(),
      ]);
      setInvoices(inv); setRepairs(rep); setRevenue(rev); setStore(s);
    } else {
      const [inv, rep, rev, s] = await Promise.all([
        listInvoices(200), listRepairTickets(),
        getRevenueBreakdown(RANGES[range].ms), getAllSettings(),
      ]);
      const since = Date.now() - RANGES[range].ms;
      setInvoices(inv.filter(i => i.created_at >= since));
      setRepairs(rep.filter(t => t.created_at >= since));
      setRevenue(rev); setStore(s);
    }
  }, [range, fromDate, toDate, hasCustomRange, effectiveTo]);

  useEffect(() => { load(); }, [load]);

  const openBill = async (inv) => {
    const full = await getInvoiceWithItems(inv.id);
    setSelected(full);
  };

  // When a payment is recorded inside the sheet, refresh the underlying list too
  const handleInvoiceUpdated = (updated) => {
    setInvoices(prev => prev.map(i => i.id === updated.id ? { ...i, ...updated } : i));
  };

  const fmtShort = (d) => new Date(d + 'T00:00:00').toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'});
  const rangeLabel = hasCustomRange
    ? (fromDate === effectiveTo ? fmtShort(fromDate) : `${fmtShort(fromDate <= effectiveTo ? fromDate : effectiveTo)} – ${fmtShort(fromDate <= effectiveTo ? effectiveTo : fromDate)}`)
    : RANGES[range].label;

  const clearRange = () => { setFromDate(''); setToDate(''); };
  const today = new Date().toISOString().slice(0,10);

  return (
    <div style={{ height:'100%', display:'flex', flexDirection:'column', background:'var(--surface)' }}>
      {/* Header */}
      <div style={{ padding:'var(--space-lg)', paddingTop:'calc(var(--safe-top)+12px)', borderBottom:'1.5px solid var(--border)', background:'var(--surface)' }}>
        <div style={{ fontSize:22, fontWeight:900, color:'var(--on-surface)', marginBottom:'var(--space-md)' }}>Reports</div>
        <div style={{ display:'flex', gap:8 }}>
          {RANGES.map((r,i) => (
            <button key={r.label} onClick={()=>{ setRange(i); clearRange(); }}
              style={{ flex:1, padding:'8px 0', borderRadius:'var(--radius-md)', background:(!hasCustomRange && range===i)?'var(--brand)':'var(--surface-secondary)', border:`1.5px solid ${(!hasCustomRange && range===i)?'transparent':'var(--border-strong)'}`, cursor:'pointer', fontFamily:'var(--font)', fontWeight:700, fontSize:12, color:(!hasCustomRange && range===i)?'var(--on-brand)':'var(--on-surface)', transition:'all 0.15s' }}>
              {r.label}
            </button>
          ))}
        </div>

        {/* Find bills on a specific date, or between two dates */}
        <div style={{ marginTop:'var(--space-md)' }}>
          <div style={{ color:'var(--muted)', fontSize:11, fontWeight:700, letterSpacing:0.5, marginBottom:6 }}>
            FROM &nbsp;→&nbsp; TO
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ flex:1, display:'flex', alignItems:'center', gap:6, background:'var(--surface-secondary)', border:`1.5px solid ${fromDate ? 'var(--brand)' : 'var(--border-strong)'}`, borderRadius:'var(--radius-md)', padding:'0 10px', height:40 }}>
              <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="var(--muted)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink:0 }}>
                <rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
              </svg>
              <input
                type="date"
                value={fromDate}
                max={today}
                onChange={e => setFromDate(e.target.value)}
                style={{ flex:1, minWidth:0, background:'none', border:'none', outline:'none', color:'var(--on-surface)', fontFamily:'var(--font)', fontSize:12 }}
              />
            </div>
            <span style={{ color:'var(--muted)' }}>→</span>
            <div style={{ flex:1, display:'flex', alignItems:'center', gap:6, background:'var(--surface-secondary)', border:`1.5px solid ${toDate ? 'var(--brand)' : 'var(--border-strong)'}`, borderRadius:'var(--radius-md)', padding:'0 10px', height:40 }}>
              <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="var(--muted)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink:0 }}>
                <rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
              </svg>
              <input
                type="date"
                value={toDate}
                max={today}
                onChange={e => setToDate(e.target.value)}
                style={{ flex:1, minWidth:0, background:'none', border:'none', outline:'none', color:'var(--on-surface)', fontFamily:'var(--font)', fontSize:12 }}
              />
            </div>
            {hasCustomRange && (
              <button onClick={clearRange} className="icon-btn" title="Clear date filter" style={{ width:36, height:36, flexShrink:0 }}>✕</button>
            )}
          </div>
          {fromDate && !toDate && (
            <div style={{ color:'var(--brand)', fontSize:11, marginTop:6 }}>Showing bills for {fmtShort(fromDate)} only — pick a "To" date above for a range instead.</div>
          )}
        </div>
      </div>

      <div className="scroll" style={{ flex:1, padding:'var(--space-lg)', paddingBottom:'calc(var(--tab-height)+24px)' }}>
        {/* Stats — tap Revenue for the payment-type breakdown */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'var(--space-md)', marginBottom:'var(--space-lg)' }}>
          <button onClick={()=>setShowRevenue(true)} style={{ background:'var(--surface-secondary)', border:'1.5px solid var(--brand)', borderRadius:'var(--radius-lg)', padding:'var(--space-md)', textAlign:'center', cursor:'pointer', fontFamily:'var(--font)', position:'relative' }}>
            <div style={{ color:'var(--brand)', fontWeight:900, fontSize:18 }}>{formatCurrency(revenue.total)}</div>
            <div style={{ color:'var(--muted)', fontSize:10, marginTop:4, fontWeight:700, letterSpacing:0.5 }}>REVENUE ▾</div>
          </button>
          {[
            { label:'Sales Bills',  val:invoices.length, color:'var(--accent)' },
            { label:'Repair Bills', val:repairs.length,  color:'var(--info)' },
          ].map(s => (
            <div key={s.label} style={{ background:'var(--surface-secondary)', border:'1.5px solid var(--border)', borderRadius:'var(--radius-lg)', padding:'var(--space-md)', textAlign:'center' }}>
              <div style={{ color:s.color, fontWeight:900, fontSize:18 }}>{s.val}</div>
              <div style={{ color:'var(--muted)', fontSize:10, marginTop:4, fontWeight:700, letterSpacing:0.5 }}>{s.label.toUpperCase()}</div>
            </div>
          ))}
        </div>

        {/* ── Cart / Sales Bills ── */}
        <div style={{ fontSize:11, fontWeight:700, color:'var(--muted)', letterSpacing:0.5, marginBottom:10 }}>
          🧾 CART / SALES BILLS ({invoices.length})
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap:'var(--space-md)', marginBottom:'var(--space-xl)' }}>
          {invoices.length === 0 ? (
            <div style={{ padding:'32px 0', textAlign:'center' }}>
              <div style={{ fontSize:40, marginBottom:8 }}>🧾</div>
              <div style={{ color:'var(--on-surface)', fontWeight:700 }}>{hasCustomRange ? 'No sales bills in this range' : 'No sales bills yet'}</div>
              <div style={{ color:'var(--muted)', fontSize:13, marginTop:4 }}>Bills appear here after checkout</div>
            </div>
          ) : invoices.map((inv,i) => {
            const balance = getBalance(inv);
            const status = formatPaymentStatus(inv);
            const statusColor = inv.payment_mode === 'Credit'
              ? (balance > 0.01 ? 'var(--error)' : 'var(--success)')
              : 'var(--success)';
            return (
              <button key={inv.id} onClick={()=>openBill(inv)}
                className="anim-fade-up"
                style={{ animationDelay:`${i*0.02}s`, width:'100%', display:'flex', alignItems:'center', background:'var(--surface-secondary)', border:'1.5px solid var(--border)', borderRadius:'var(--radius-lg)', padding:'var(--space-md)', gap:'var(--space-md)', cursor:'pointer', fontFamily:'var(--font)', textAlign:'left', transition:'border-color 0.15s' }}>
                <div style={{ width:42, height:42, borderRadius:'var(--radius-md)', background:'var(--brand-soft)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, flexShrink:0 }}>🧾</div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:14 }}>{inv.invoice_no}</div>
                  <div style={{ color:'var(--muted)', fontSize:12, marginTop:2 }}>
                    {inv.customer_name||'Walk-in'}
                  </div>
                  <div style={{ color:'var(--muted)', fontSize:11, marginTop:1 }}>
                    {new Date(inv.created_at).toLocaleString('en-IN',{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'})}
                  </div>
                </div>
                <div style={{ textAlign:'right', flexShrink:0 }}>
                  <div style={{ color:'var(--brand)', fontWeight:900, fontSize:15 }}>{formatCurrency(inv.total)}</div>
                  <div style={{ color:statusColor, fontSize:10, fontWeight:700, marginTop:2, maxWidth:130 }}>
                    {status}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* ── Repair Bills ── */}
        <div style={{ fontSize:11, fontWeight:700, color:'var(--muted)', letterSpacing:0.5, marginBottom:10 }}>
          🔧 REPAIR BILLS ({repairs.length})
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap:'var(--space-md)' }}>
          {repairs.length === 0 ? (
            <div style={{ padding:'32px 0', textAlign:'center' }}>
              <div style={{ fontSize:40, marginBottom:8 }}>🔧</div>
              <div style={{ color:'var(--on-surface)', fontWeight:700 }}>{hasCustomRange ? 'No repair bills in this range' : 'No repair bills yet'}</div>
              <div style={{ color:'var(--muted)', fontSize:13, marginTop:4 }}>Repair tickets appear here once created</div>
            </div>
          ) : repairs.map((t,i) => {
            const balance = Math.max(0, parseFloat(((t.total_cost||0) - (t.paid_amount||0)).toFixed(2)));
            const status = formatPaymentStatus(t);
            const statusColor = t.payment_mode === 'Credit'
              ? (balance > 0.01 ? 'var(--error)' : 'var(--success)')
              : 'var(--success)';
            return (
              <button key={t.id} onClick={()=>nav(`/repair-receipt/${t.id}`)}
                className="anim-fade-up"
                style={{ animationDelay:`${i*0.02}s`, width:'100%', display:'flex', alignItems:'center', background:'var(--surface-secondary)', border:'1.5px solid var(--border)', borderRadius:'var(--radius-lg)', padding:'var(--space-md)', gap:'var(--space-md)', cursor:'pointer', fontFamily:'var(--font)', textAlign:'left', transition:'border-color 0.15s' }}>
                <div style={{ width:42, height:42, borderRadius:'var(--radius-md)', background:'var(--info)22', display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, flexShrink:0 }}>🔧</div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:14 }}>{t.ticket_no} · {t.device_model}</div>
                  <div style={{ color:'var(--muted)', fontSize:12, marginTop:2 }}>
                    {t.customer_name||'Walk-in'} · {t.status}
                  </div>
                  <div style={{ color:'var(--muted)', fontSize:11, marginTop:1 }}>
                    {new Date(t.created_at).toLocaleString('en-IN',{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'})}
                  </div>
                </div>
                <div style={{ textAlign:'right', flexShrink:0 }}>
                  <div style={{ color:'var(--brand)', fontWeight:900, fontSize:15 }}>{formatCurrency(t.total_cost||0)}</div>
                  <div style={{ color:statusColor, fontSize:10, fontWeight:700, marginTop:2, maxWidth:130 }}>
                    {status}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Bill detail sheet */}
      {selected && (
        <BillDetail
          inv={selected}
          store={store}
          onClose={() => { setSelected(null); load(); }}
          onUpdated={handleInvoiceUpdated}
        />
      )}

      {/* Revenue breakdown sheet */}
      {showRevenue && (
        <RevenueBreakdown data={revenue} rangeLabel={rangeLabel} onClose={()=>setShowRevenue(false)} />
      )}
    </div>
  );
}
