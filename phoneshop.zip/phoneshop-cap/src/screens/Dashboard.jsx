import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { getStats, getLowStockCount, listInvoices, listProducts, listRepairTickets, getSetting, getInvoiceWithItems, getAllSettings, recordPayment, markInvoicePaid, formatCurrency } from '../db/database.js';
import * as BT from '../printer/bluetooth.js';
import { useSheetOpen } from '../utils/sheetRegistry.js';

const REPAIR_COLORS = { Received:'#7BB7FF','In-Progress':'#FFB84D',Ready:'#B8FF5E',Delivered:'#5EE5A0',Cancelled:'#FF5E78' };

const getPaidAmount = (inv) => inv.paid_amount ?? (inv.paid ? inv.total : 0);
const getBalance    = (inv) => Math.max(0, parseFloat((inv.total - getPaidAmount(inv)).toFixed(2)));

// ── Collect Payment Panel ──
function CollectPayment({ inv, onPaid }) {
  const [amount, setAmount] = useState('');
  const [busy, setBusy] = useState(false);
  const balance = getBalance(inv);

  const handlePartial = async () => {
    const n = parseFloat(amount);
    if (isNaN(n) || n <= 0) { alert('Enter a valid amount.'); return; }
    if (n > balance + 0.01) { alert(`Amount cannot exceed balance due of ${formatCurrency(balance)}.`); return; }
    setBusy(true);
    try { onPaid(await recordPayment(inv.id, n)); setAmount(''); }
    catch(e) { alert(e.message); }
    finally { setBusy(false); }
  };

  const handleFullyPaid = async () => {
    if (!confirm(`Mark this bill as fully paid? Remaining balance: ${formatCurrency(balance)}`)) return;
    setBusy(true);
    try { onPaid(await markInvoicePaid(inv.id)); }
    catch(e) { alert(e.message); }
    finally { setBusy(false); }
  };

  return (
    <div style={{ background:'var(--error-soft)', border:'1.5px solid var(--error)44', borderRadius:'var(--radius-lg)', padding:'var(--space-md)', marginBottom:'var(--space-md)', display:'flex', flexDirection:'column', gap:'var(--space-md)' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <span style={{ color:'var(--error)', fontWeight:800, fontSize:13 }}>🔴 CREDIT — BALANCE DUE</span>
        <span style={{ color:'var(--error)', fontWeight:900, fontSize:18 }}>{formatCurrency(balance)}</span>
      </div>
      {getPaidAmount(inv) > 0 && (
        <div style={{ display:'flex', justifyContent:'space-between', fontSize:12, color:'var(--muted)' }}>
          <span>Already paid</span>
          <span style={{ fontWeight:700, color:'var(--on-surface)' }}>{formatCurrency(getPaidAmount(inv))} of {formatCurrency(inv.total)}</span>
        </div>
      )}
      <div style={{ display:'flex', gap:8 }}>
        <input className="input" type="number" min="0" max={balance} value={amount} onChange={e=>setAmount(e.target.value)}
          placeholder={`Enter amount (max ${formatCurrency(balance)})`} style={{ flex:1 }} disabled={busy} />
        <button onClick={handlePartial} disabled={busy || !amount}
          style={{ padding:'0 18px', borderRadius:'var(--radius-md)', background:'var(--surface-inverse)', border:'none', cursor:'pointer', color:'var(--on-surface-inverse)', fontWeight:800, fontFamily:'var(--font)', fontSize:13, opacity: busy||!amount?0.5:1, whiteSpace:'nowrap' }}>
          Add Payment
        </button>
      </div>
      <button onClick={handleFullyPaid} disabled={busy}
        style={{ width:'100%', padding:13, borderRadius:'var(--radius-md)', background:'var(--success)', border:'none', cursor:'pointer', color:'#04220F', fontWeight:800, fontFamily:'var(--font)', fontSize:14, display:'flex', alignItems:'center', justifyContent:'center', gap:8, opacity: busy?0.6:1 }}>
        <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        Mark Fully Paid
      </button>
    </div>
  );
}

// Inline bill detail (reused from Reports)
function BillDetail({ inv: initialInv, store, onClose }) {
  const [inv, setInv] = useState(initialInv);
  useSheetOpen(true);
  const date = new Date(inv.created_at).toLocaleString('en-IN');
  const balance = getBalance(inv);
  const isUnpaidCredit = inv.payment_mode === 'Credit' && !inv.paid;

  const handlePaymentUpdate = (result) => {
    setInv(prev => ({ ...prev, paid_amount: result.paid_amount, paid: result.paid ? 1 : 0 }));
  };

  return (
    <div style={{ position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.75)', zIndex:500, display:'flex', flexDirection:'column', justifyContent:'flex-end' }}>
      <div style={{ background:'var(--surface-secondary)', borderRadius:'var(--radius-xl) var(--radius-xl) 0 0', maxHeight:'90vh', display:'flex', flexDirection:'column', animation:'slideUp 0.3s cubic-bezier(.32,1.2,.64,1)' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'var(--space-lg)', borderBottom:'1.5px solid var(--border)' }}>
          <div>
            <div style={{ fontSize:16, fontWeight:800, color:'var(--on-surface)' }}>{inv.invoice_no}</div>
            <div style={{ color:'var(--muted)', fontSize:12, marginTop:2 }}>{date}</div>
          </div>
          <button onClick={onClose} className="icon-btn">✕</button>
        </div>
        <div className="scroll" style={{ flex:1, padding:'var(--space-lg)', paddingBottom:24 }}>
          {isUnpaidCredit && <CollectPayment inv={inv} onPaid={handlePaymentUpdate} />}

          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:'var(--space-md)' }}>
            {[['Customer',inv.customer_name||'Walk-in'],['Phone',inv.customer_phone||'—'],['Payment',inv.payment_mode],['Status',inv.paid?'✅ Paid':balance<inv.total?'🟡 Partial':'🔴 Unpaid']].map(([k,v])=>(
              <div key={k} style={{ background:'var(--surface-tertiary)', borderRadius:'var(--radius-md)', padding:'var(--space-sm) var(--space-md)' }}>
                <div style={{ color:'var(--muted)', fontSize:10, fontWeight:700, letterSpacing:0.5 }}>{k.toUpperCase()}</div>
                <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:13, marginTop:2 }}>{v}</div>
              </div>
            ))}
          </div>
          <div style={{ background:'var(--surface-secondary)', border:'1.5px solid var(--border)', borderRadius:'var(--radius-lg)', overflow:'hidden', marginBottom:'var(--space-md)' }}>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 40px 70px', padding:'var(--space-sm) var(--space-md)', background:'var(--surface-tertiary)', borderBottom:'1px solid var(--border)', fontSize:10, fontWeight:700, color:'var(--muted)', gap:4 }}>
              <span>ITEM</span><span style={{ textAlign:'right' }}>QTY</span><span style={{ textAlign:'right' }}>AMT</span>
            </div>
            {(inv.items||[]).map((it,i)=>(
              <div key={i} style={{ display:'grid', gridTemplateColumns:'1fr 40px 70px', padding:'var(--space-md)', borderBottom:i<(inv.items||[]).length-1?'1px solid var(--divider)':'none', gap:4, alignItems:'center' }}>
                <div>
                  <div style={{ color:'var(--on-surface)', fontWeight:600, fontSize:13 }}>{it.name}</div>
                  <div style={{ color:'var(--muted)', fontSize:11 }}>{formatCurrency(it.price)} each</div>
                </div>
                <span style={{ textAlign:'right', color:'var(--muted-strong)', fontWeight:700, fontSize:13 }}>×{it.qty}</span>
                <span style={{ textAlign:'right', color:'var(--on-surface)', fontWeight:800, fontSize:13 }}>{formatCurrency(it.amount)}</span>
              </div>
            ))}
          </div>
          <div style={{ background:'var(--surface-secondary)', border:'1.5px solid var(--border)', borderRadius:'var(--radius-lg)', padding:'var(--space-md)', display:'flex', flexDirection:'column', gap:8 }}>
            {[['Subtotal',formatCurrency(inv.subtotal)],inv.discount_amount>0&&['Discount',`-${formatCurrency(inv.discount_amount)}`],['GST',formatCurrency(inv.gst_amount)]].filter(Boolean).map(([k,v])=>(
              <div key={k} style={{ display:'flex', justifyContent:'space-between' }}>
                <span style={{ color:'var(--muted)', fontWeight:600, fontSize:13 }}>{k}</span>
                <span style={{ color:'var(--on-surface)', fontWeight:700, fontSize:13 }}>{v}</span>
              </div>
            ))}
            <div style={{ height:1.5, background:'var(--border-strong)', margin:'2px 0' }} />
            <div style={{ display:'flex', justifyContent:'space-between' }}>
              <span style={{ color:'var(--on-surface)', fontWeight:800, fontSize:16 }}>TOTAL</span>
              <span style={{ color:'var(--brand)', fontWeight:900, fontSize:18 }}>{formatCurrency(inv.total)}</span>
            </div>
            {!inv.paid && (
              <>
                <div style={{ height:1, background:'var(--divider)', margin:'2px 0' }} />
                <div style={{ display:'flex', justifyContent:'space-between' }}>
                  <span style={{ color:'var(--muted)', fontWeight:600, fontSize:13 }}>Paid so far</span>
                  <span style={{ color:'var(--success)', fontWeight:700, fontSize:13 }}>{formatCurrency(getPaidAmount(inv))}</span>
                </div>
                <div style={{ display:'flex', justifyContent:'space-between' }}>
                  <span style={{ color:'var(--error)', fontWeight:700, fontSize:14 }}>Balance Due</span>
                  <span style={{ color:'var(--error)', fontWeight:900, fontSize:16 }}>{formatCurrency(balance)}</span>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
      <style>{`@keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}`}</style>
    </div>
  );
}

function SectionHeader({ title, sub, action, onAction }) {
  return (
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', padding:'var(--space-xl) var(--space-lg) var(--space-md)' }}>
      <div>
        <div style={{ fontSize:18, fontWeight:800, color:'var(--on-surface)', letterSpacing:-0.3 }}>{title}</div>
        <div style={{ color:'var(--muted)', fontSize:11, marginTop:2, fontWeight:600 }}>{sub}</div>
      </div>
      <button onClick={onAction} style={{ background:'none', border:'none', color:'var(--brand)', fontWeight:700, fontSize:13, cursor:'pointer', fontFamily:'var(--font)' }}>{action}</button>
    </div>
  );
}

export default function Dashboard() {
  const nav = useNavigate();
  const [store, setStore] = useState('SRI DHARANI MOBILES');
  const [stock, setStock] = useState({ critical:0, low:0, total_stock:0 });
  const [todayStats, setTodayStats] = useState({ count:0, items_sold:0 });
  const [recent, setRecent] = useState([]);
  const [lowStock, setLowStock] = useState([]);
  const [alertsEnabled, setAlertsEnabled] = useState(true);
  const [repairs, setRepairs] = useState([]);
  const [selectedBill, setSelectedBill] = useState(null);
  const [storeSettings, setStoreSettings] = useState({});
  const [printerConnected, setPrinterConnected] = useState(false);
  const [printerName, setPrinterName] = useState('');

  const load = useCallback(async () => {
    const DAY = 24*3600*1000;
    const [stats, st, name, inv, prods, reps, lowT, critT, settings] = await Promise.all([
      getStats(DAY), getLowStockCount(), getSetting('store_name'),
      listInvoices(5), listProducts(), listRepairTickets(),
      getSetting('low_stock'), getSetting('critical_stock'), getAllSettings(),
    ]);
    setTodayStats({ count:stats.count, items_sold:stats.items_sold });
    if (name) setStore(name);
    setRecent(inv);
    setStoreSettings(settings);

    // Respect the Alerts tab toggles: a disabled alert contributes nothing
    // to the counts shown on the dashboard, and — if both are off — the
    // "Low Stock Alerts" list is hidden entirely rather than shown empty.
    const criticalEnabled = settings.critical_stock_alert_enabled !== '0';
    const lowEnabled      = settings.low_stock_alert_enabled !== '0';
    const lowN  = parseInt(lowT  || '5', 10);
    const critN = parseInt(critT || '2', 10);

    setStock({
      ...st,
      critical: criticalEnabled ? st.critical : 0,
      low:      lowEnabled ? st.low : 0,
    });

    const threshold = lowEnabled ? lowN : (criticalEnabled ? critN : -1);
    setLowStock(
      threshold < 0 ? [] : prods.filter(p=>p.stock<=threshold).sort((a,b)=>a.stock-b.stock).slice(0,5)
    );
    setAlertsEnabled(criticalEnabled || lowEnabled);
    setRepairs(reps.filter(r=>r.status!=='Delivered'&&r.status!=='Cancelled').slice(0,4));

    // Printer status: a printer is saved AND currently has an active BLE connection.
    const savedAddr = settings.bt_printer_address;
    const liveConnectedId = BT.getConnectedDeviceId();
    setPrinterConnected(Boolean(savedAddr) && liveConnectedId === savedAddr);
    setPrinterName(settings.bt_printer_name || '');
  }, []);

  useEffect(() => { load(); }, [load]);

  const openBill = async (inv) => {
    const full = await getInvoiceWithItems(inv.id);
    setSelectedBill(full);
  };

  const hour = new Date().getHours();
  const greeting = hour<12?'Good morning':hour<17?'Good afternoon':'Good evening';
  const today = new Date().toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long'});
  const lowPct = stock.total_stock>0?Math.min(100,((stock.critical+stock.low)/Math.max(1,stock.total_stock))*100):0;

  return (
    <div className="scroll" style={{ height:'100%', paddingBottom:'calc(var(--tab-height) + 24px)' }}>
      {/* Header */}
      <div className="anim-fade-up" style={{ padding:'var(--space-lg)', paddingTop:'calc(var(--safe-top) + 16px)', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div>
          <div style={{ color:'var(--muted)', fontSize:10, letterSpacing:1.5, fontWeight:700 }}>{today.toUpperCase()}</div>
          <div style={{ color:'var(--muted-strong)', fontSize:14, marginTop:6, fontWeight:500 }}>{greeting},</div>
          <div style={{ color:'var(--on-surface)', fontSize:26, fontWeight:900, marginTop:2 }}>
            {store} <span style={{ color:'var(--accent)' }}>●</span>
          </div>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          {/* Printer connection status — informational only, not tappable */}
          <div
            title={printerConnected ? `Printer: ${printerName}` : 'No printer connected'}
            style={{
              width:38, height:38, borderRadius:12,
              background: printerConnected ? 'var(--success-soft)' : 'var(--surface-tertiary)',
              border:`1.5px solid ${printerConnected ? 'var(--success)' : 'var(--icon-btn-border)'}`,
              display:'flex', alignItems:'center', justifyContent:'center',
              position:'relative', flexShrink:0,
            }}>
            <svg width={17} height={17} viewBox="0 0 24 24" fill="none"
              stroke={printerConnected ? 'var(--success)' : 'var(--muted)'}
              strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="6 9 6 2 18 2 18 9"/>
              <path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/>
              <rect x="6" y="14" width="12" height="8"/>
            </svg>
            {/* status dot */}
            <span style={{
              position:'absolute', bottom:-2, right:-2,
              width:11, height:11, borderRadius:6,
              background: printerConnected ? 'var(--success)' : 'var(--error)',
              border:'2px solid var(--surface)',
            }} />
          </div>

          <button className="icon-btn" onClick={() => nav('/reports')} title="Reports & Analytics">
            <svg width={18} height={18} viewBox="0 0 24 24" fill="none" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>
            </svg>
          </button>
        </div>
      </div>

      {/* Pulse Card */}
      <div className="anim-fade-up delay-1" style={{ margin:'0 var(--space-lg)' }}>
        <div style={{ background:'linear-gradient(135deg,var(--surface-secondary),var(--surface-tertiary))', border:'1px solid var(--border)', borderRadius:'var(--radius-xl)', padding:'var(--space-xl)', position:'relative', overflow:'hidden' }}>
          <div style={{ position:'absolute', inset:0, background:'radial-gradient(circle at 80% 20%, var(--brand-soft), transparent 60%)', pointerEvents:'none' }} />
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <span style={{ color:'var(--brand)', fontSize:10, fontWeight:800, letterSpacing:1.5 }}>INVENTORY PULSE</span>
            <span style={{ display:'flex', alignItems:'center', gap:6, background:'var(--accent-soft)', padding:'4px 10px', borderRadius:999 }}>
              <span style={{ width:6, height:6, borderRadius:3, background:'var(--accent)', display:'block', animation:'pulse 2s infinite' }} />
              <span style={{ color:'var(--accent)', fontSize:9, fontWeight:800 }}>LIVE</span>
            </span>
          </div>
          <div style={{ display:'flex', alignItems:'center', marginTop:'var(--space-lg)' }}>
            <div style={{ flex:1 }}>
              <div style={{ color:'var(--on-surface)', fontSize:48, fontWeight:900, letterSpacing:-2, lineHeight:1 }}>{stock.total_stock}</div>
              <div style={{ color:'var(--muted-strong)', fontSize:12, fontWeight:600, marginTop:4 }}>units in stock</div>
            </div>
            <div style={{ width:80, height:80, borderRadius:40, background:'var(--surface-tertiary)', display:'flex', alignItems:'center', justifyContent:'center', position:'relative', overflow:'hidden' }}>
              <svg viewBox="0 0 80 80" style={{ position:'absolute', inset:0, width:80, height:80 }}>
                <circle cx="40" cy="40" r="36" fill="none" stroke="var(--brand)" strokeWidth="6" strokeOpacity="0.4" strokeDasharray={`${lowPct*2.26} 226`} strokeLinecap="round" transform="rotate(-90 40 40)" />
              </svg>
              <div style={{ display:'flex', flexDirection:'column', alignItems:'center', zIndex:1 }}>
                <span style={{ color:'var(--on-surface)', fontSize:18, fontWeight:800 }}>{stock.critical+stock.low}</span>
                <span style={{ color:'var(--muted)', fontSize:9, fontWeight:700 }}>alerts</span>
              </div>
            </div>
          </div>
          <div style={{ display:'flex', marginTop:'var(--space-lg)', background:'rgba(255,255,255,0.04)', borderRadius:'var(--radius-md)', padding:'var(--space-md)' }}>
            {[{val:todayStats.count,label:'bills today'},{val:todayStats.items_sold,label:'items sold'},{val:stock.critical,label:'critical',color:'var(--coral)'}].map((s,i)=>(
              <div key={i} style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', borderRight:i<2?'1px solid var(--border)':'none' }}>
                <span style={{ color:s.color||'var(--on-surface)', fontSize:18, fontWeight:800 }}>{s.val}</span>
                <span style={{ color:'var(--muted)', fontSize:10, fontWeight:600, marginTop:2 }}>{s.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Repairs */}
      <SectionHeader title="Active Repairs" sub={`${repairs.length} in workshop`} action="View All ›" onAction={()=>nav('/repairs')} />
      {repairs.length===0 ? (
        <div style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:8, padding:'var(--space-xl)', background:'var(--surface-secondary)', border:'1px solid var(--border)', borderRadius:'var(--radius-lg)', margin:'0 var(--space-lg)' }}>
          <span style={{ color:'var(--muted)', fontWeight:600 }}>No active repairs</span>
        </div>
      ) : (
        <div className="scroll-x" style={{ display:'flex', gap:'var(--space-md)', padding:'0 var(--space-lg) 4px' }}>
          {repairs.map((t,i)=>{
            const color = REPAIR_COLORS[t.status]||'#7BB7FF';
            return (
              <div key={t.id} onClick={()=>nav('/repair-ticket',{state:{id:t.id}})} style={{ width:200, background:'var(--surface-secondary)', border:'1px solid var(--border)', borderRadius:'var(--radius-md)', padding:'var(--space-md)', cursor:'pointer', flexShrink:0, animation:`fadeInUp 0.4s ${0.1+i*0.05}s both` }}>
                <span style={{ display:'inline-flex', alignItems:'center', gap:4, padding:'3px 8px', borderRadius:999, background:color+'22', color, fontSize:10, fontWeight:800 }}>● {t.status}</span>
                <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:14, marginTop:8 }}>{t.customer_name}</div>
                <div style={{ color:'var(--muted-strong)', fontSize:12 }}>{t.device_model}</div>
                <div style={{ display:'flex', justifyContent:'space-between', marginTop:10, paddingTop:8, borderTop:'1px solid var(--divider)' }}>
                  <span style={{ color:'var(--muted)', fontSize:10, fontWeight:700 }}>{t.ticket_no}</span>
                  <span style={{ color:'var(--brand)', fontWeight:800, fontSize:13 }}>{formatCurrency(t.total_cost)}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Low Stock — hidden entirely when both alert toggles are off in Settings → Alerts */}
      {alertsEnabled && (
        <>
          <SectionHeader title="Low Stock Alerts" sub="Restock soon" action="Inventory ›" onAction={()=>nav('/products')} />
          <div className="card" style={{ margin:'0 var(--space-lg)' }}>
            {lowStock.length===0 ? (
              <div style={{ padding:'var(--space-xl)', textAlign:'center', color:'var(--success)', fontWeight:600 }}>✅ All stock healthy</div>
            ) : lowStock.map((p,i)=>(
              <div key={p.id} style={{ display:'flex', alignItems:'center', padding:'var(--space-md)', gap:'var(--space-md)', borderBottom:i<lowStock.length-1?'1px solid var(--divider)':undefined }}>
                <div style={{ width:3, height:32, borderRadius:2, background:p.stock<=2?'var(--coral)':'var(--warning)', flexShrink:0 }} />
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ color:'var(--on-surface)', fontWeight:600, fontSize:14, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{p.name}</div>
                  <div style={{ color:'var(--muted)', fontSize:11, marginTop:2 }}>{p.category_name||'—'}</div>
                </div>
                <div style={{ textAlign:'right', flexShrink:0 }}>
                  <div style={{ color:p.stock<=2?'var(--coral)':'var(--warning)', fontWeight:800, fontSize:18 }}>{p.stock}</div>
                  <div style={{ color:'var(--muted)', fontSize:9, fontWeight:700, letterSpacing:1 }}>LEFT</div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {/* Recent Bills */}
      <SectionHeader title="Recent Bills" sub={`Last ${recent.length} invoices`} action="All ›" onAction={()=>nav('/reports')} />
      <div className="card" style={{ margin:'0 var(--space-lg) var(--space-lg)' }}>
        {recent.length===0 ? (
          <div style={{ padding:'var(--space-xl)', textAlign:'center', color:'var(--muted)', fontWeight:600 }}>No bills yet</div>
        ) : recent.map((inv,i)=>(
          <button key={inv.id} onClick={()=>openBill(inv)} style={{ width:'100%', display:'flex', alignItems:'center', padding:'var(--space-md)', gap:'var(--space-md)', borderBottom:i<recent.length-1?'1px solid var(--divider)':undefined, background:'none', border:'none', cursor:'pointer', fontFamily:'var(--font)', textAlign:'left' }}>
            <div style={{ width:36, height:36, borderRadius:10, background:'var(--brand-soft)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>🧾</div>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ color:'var(--on-surface)', fontWeight:600, fontSize:14 }}>{inv.invoice_no}</div>
              <div style={{ color:'var(--muted)', fontSize:11, marginTop:2 }}>{inv.customer_name||'Walk-in'} · {inv.payment_mode}</div>
            </div>
            <span style={{ color:'var(--on-surface)', fontWeight:800, fontSize:14, flexShrink:0 }}>{formatCurrency(inv.total)}</span>
          </button>
        ))}
      </div>

      {selectedBill && <BillDetail inv={selectedBill} store={storeSettings} onClose={()=>{ setSelectedBill(null); load(); }} />}
    </div>
  );
}
