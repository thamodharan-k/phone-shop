import { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAllSettings, setSetting, exportBackup, resetAllData, resetSalesData, addKnownPrinter } from '../db/database.js';
import * as BT from '../printer/bluetooth.js';
import { PAPER_SIZES } from '../printer/bluetooth.js';
import { useTheme } from '../state/context.jsx';
import BluetoothPrinterModal from '../components/BluetoothPrinterModal.jsx';
import { useSheetOpen } from '../utils/sheetRegistry.js';

const TABS = [
  { key:'store',      label:'Store',      icon:'🏪' },
  { key:'alerts',     label:'Alerts',     icon:'🔔' },
  { key:'security',   label:'Security',   icon:'🔒' },
  { key:'appearance', label:'Appearance', icon:'🎨' },
  { key:'hardware',   label:'Hardware',   icon:'🖨️' },
  { key:'data',       label:'Data',       icon:'💾' },
];

const PRESET_COLORS = [
  { label:'Cyan',   value:'#00E5FF' },{ label:'Yellow', value:'#FACC15' },
  { label:'Green',  value:'#22C55E' },{ label:'Purple', value:'#A855F7' },
  { label:'Orange', value:'#F97316' },{ label:'Pink',   value:'#EC4899' },
  { label:'Red',    value:'#EF4444' },{ label:'Blue',   value:'#3B82F6' },
];

// ─── Hardware Tab Component ────────────────────────────────────────────────────
function HardwareTab({ s, upd, setShowBT }) {
  const paperMm    = parseInt(s.paper_width || '57', 10);
  const [testing, setTesting]   = useState(false);
  const [saving,  setSaving]    = useState(false);
  const [checking, setChecking] = useState(false);
  const [liveStatus, setLiveStatus] = useState(null); // null | 'ok' | 'fail'
  const [widthInput, setWidthInput] = useState(String(paperMm));

  useEffect(() => { setWidthInput(String(paperMm)); }, [paperMm]);

  const MIN_MM = 25, MAX_MM = 120;

  const savePaperWidth = async (mm) => {
    upd('paper_width', String(mm));
    setSaving(true);
    await setSetting('paper_width', String(mm));
    setSaving(false);
  };

  const applyCustomWidth = () => {
    const n = parseInt(widthInput, 10);
    if (isNaN(n)) { setWidthInput(String(paperMm)); return; }
    const clamped = Math.min(MAX_MM, Math.max(MIN_MM, n));
    setWidthInput(String(clamped));
    if (clamped !== paperMm) savePaperWidth(clamped);
  };

  const handleCheckConnectivity = async () => {
    if (!s.bt_printer_address) { alert('No printer connected. Tap "Manage Bluetooth" first.'); return; }
    setChecking(true); setLiveStatus(null);
    try {
      const { ok, reason } = await BT.checkConnectivity(s.bt_printer_address);
      setLiveStatus(ok ? 'ok' : 'fail');
      if (!ok) alert('Not reachable: ' + (reason || 'Unknown error.'));
    } finally {
      setChecking(false);
    }
  };

  const handleTestPrint = async () => {
    if (!s.bt_printer_address) { alert('No printer connected. Tap "Manage Bluetooth" first.'); return; }
    setTesting(true);
    try {
      const { ok, reason } = await BT.ensureEnabled();
      if (!ok) { alert(reason || 'Bluetooth unavailable.'); return; }
      await BT.connect(s.bt_printer_address);
      setLiveStatus('ok');
      await BT.printTest(paperMm, {
        store_name:    s.store_name,
        store_tagline: s.store_tagline,
        store_address: s.store_address,
        store_phone:   s.store_phone,
        gst_number:    s.gst_number,
      });
      alert('Test print sent! Check your printer.');
    } catch(e) {
      setLiveStatus('fail');
      alert('Print error: ' + e.message);
    }
    finally { setTesting(false); }
  };

  // Receipt preview string based on paper chars — header reflects the
  // merchant's actual configured store info, not placeholder demo text.
  const W = BT.charsForWidth(paperMm);
  const centerLine = (text) => {
    const t = String(text || '').slice(0, W);
    const pad = Math.max(0, Math.floor((W - t.length) / 2));
    return ' '.repeat(pad) + t;
  };
  const storeName    = s.store_name    || '(Set your store name in Store tab)';
  const storeTagline = s.store_tagline || '';
  const storeAddress = s.store_address || '';
  const previewLines = [
    centerLine(storeName),
    ...(storeTagline ? [centerLine(storeTagline)] : []),
    ...(storeAddress ? [centerLine(storeAddress)] : []),
    '-'.repeat(Math.min(W, 36)),
    'INV-0001         30 Jun 2026',
    'Customer:           Walk-in',
    '-'.repeat(Math.min(W, 36)),
    'ITEM'.padEnd(Math.max(8,W-15)) + ' RATE QTY  AMT',
    '-'.repeat(Math.min(W, 36)),
    ('iPhone 15').padEnd(Math.max(8,W-15)) + '74900  x1 74900',
    ('AirPods Pro').padEnd(Math.max(8,W-15)) + '24900  x1 24900',
    '-'.repeat(Math.min(W, 36)),
    `Subtotal${' '.repeat(Math.max(1,W-25))}₹99800`,
    `GST (0%)${' '.repeat(Math.max(1,W-21))}₹0`,
    '='.repeat(Math.min(W, 36)),
    `TOTAL${' '.repeat(Math.max(1,W-17))}₹99800`,
    '='.repeat(Math.min(W, 36)),
    '  Thank you for shopping!',
  ];

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:'var(--space-lg)' }}>

      {/* Printer connection status */}
      {s.bt_printer_name ? (
        <div style={{ display:'flex', alignItems:'center', gap:10, padding:'var(--space-md)', background: liveStatus==='fail' ? 'var(--error-soft)' : 'var(--success-soft)', borderRadius:'var(--radius-md)', border:`1px solid ${liveStatus==='fail' ? 'var(--error)33' : 'var(--success)33'}` }}>
          <span style={{ width:10, height:10, borderRadius:5, background: liveStatus==='fail' ? 'var(--error)' : 'var(--success)', display:'block', flexShrink:0 }} />
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:14 }}>{s.bt_printer_name}</div>
            <div style={{ color:'var(--muted)', fontSize:11, marginTop:1 }}>{s.bt_printer_address}</div>
          </div>
          <span style={{ background: liveStatus==='fail' ? 'var(--error)' : 'var(--success)', color:'#04220F', fontSize:10, fontWeight:800, padding:'3px 9px', borderRadius:999 }}>
            {liveStatus==='fail' ? 'NOT REACHABLE' : liveStatus==='ok' ? 'VERIFIED' : 'PAIRED'}
          </span>
        </div>
      ) : (
        <div style={{ display:'flex', alignItems:'center', gap:10, padding:'var(--space-md)', background:'var(--surface-tertiary)', borderRadius:'var(--radius-md)' }}>
          <span style={{ width:10, height:10, borderRadius:5, background:'var(--muted)', display:'block', flexShrink:0 }} />
          <div style={{ color:'var(--muted)', fontSize:13 }}>No printer connected. Tap below to pair one.</div>
        </div>
      )}

      {s.bt_printer_name && (
        <button onClick={handleCheckConnectivity} disabled={checking} className="btn-ghost" style={{ width:'100%' }}>
          {checking ? '⏳ Checking…' : '📶 Check Bluetooth Connectivity'}
        </button>
      )}

      <button className="btn-ghost" style={{ width:'100%' }} onClick={()=>setShowBT(true)}>
        🔵 {s.bt_printer_name ? 'Manage Bluetooth / Switch Printer' : 'Scan & Pair Printer'}
      </button>

      {/* Divider */}
      <div style={{ height:1, background:'var(--divider)' }} />

      {/* Paper Width */}
      <div>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'var(--space-md)' }}>
          <div>
            <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:15 }}>Paper Width</div>
            <div style={{ color:'var(--muted)', fontSize:12, marginTop:2 }}>Select your printer's roll size</div>
          </div>
          <span style={{ color:'var(--brand)', fontWeight:900, fontSize:20 }}>{paperMm} <span style={{ fontSize:13, fontWeight:600 }}>mm</span></span>
        </div>

        {/* Size buttons */}
        <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
          {PAPER_SIZES.map(ps => (
            <button key={ps.mm} onClick={() => savePaperWidth(ps.mm)} style={{
              padding:'9px 16px', borderRadius:'var(--radius-pill)',
              background: paperMm === ps.mm ? 'var(--brand)' : 'var(--surface-tertiary)',
              border: `1.5px solid ${paperMm === ps.mm ? 'transparent' : 'var(--border-strong)'}`,
              cursor:'pointer', fontFamily:'var(--font)', fontWeight:700, fontSize:13,
              color: paperMm === ps.mm ? 'var(--on-brand)' : 'var(--on-surface)',
              transition:'all 0.15s',
            }}>
              {ps.label}{paperMm === ps.mm ? ' ✦' : ''}
            </button>
          ))}
        </div>

        {/* Custom width — not limited to the presets above */}
        <div style={{ marginTop:'var(--space-md)' }}>
          <div style={{ color:'var(--muted)', fontSize:12, marginBottom:6 }}>Or set an exact custom width ({MIN_MM}–{MAX_MM}mm):</div>
          <div style={{ display:'flex', gap:8 }}>
            <input
              className="input"
              type="number"
              min={MIN_MM} max={MAX_MM}
              value={widthInput}
              onChange={e => setWidthInput(e.target.value)}
              onBlur={applyCustomWidth}
              onKeyDown={e => { if (e.key === 'Enter') e.target.blur(); }}
              placeholder="e.g. 65"
              style={{ flex:1 }}
            />
            <button onClick={applyCustomWidth} className="btn-primary" style={{ padding:'0 20px', borderRadius:'var(--radius-md)' }}>
              Apply
            </button>
          </div>
        </div>
        {saving && <div style={{ color:'var(--muted)', fontSize:11, marginTop:6 }}>Saving…</div>}
      </div>

      {/* Receipt Preview */}
      <div>
        <div className="label" style={{ marginBottom:8 }}>RECEIPT PREVIEW ({W} chars wide)</div>
        <div style={{
          background:'#f5f0e8',
          borderRadius:'var(--radius-md)',
          padding:14,
          border:'1px solid #d6cebc',
          overflowX:'auto',
        }}>
          <pre style={{
            fontFamily:'var(--font-mono)', fontSize:10, lineHeight:1.6,
            color:'#2c2410', whiteSpace:'pre', margin:0,
          }}>{previewLines.join('\n')}</pre>
        </div>
      </div>

      {/* Test Print */}
      <button onClick={handleTestPrint} disabled={testing} style={{
        width:'100%', display:'flex', alignItems:'center', justifyContent:'center', gap:8,
        padding:14, borderRadius:'var(--radius-lg)',
        background:'var(--surface-tertiary)', border:'2px solid var(--border-strong)',
        cursor:'pointer', fontFamily:'var(--font)', fontWeight:700, fontSize:14,
        color:'var(--on-surface)', opacity: testing ? 0.6 : 1,
      }}>
        <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="6 9 6 2 18 2 18 9"/>
          <path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/>
          <rect x="6" y="14" width="12" height="8"/>
        </svg>
        {testing ? 'Printing test page…' : 'Print Test Page'}
      </button>
    </div>
  );
}

export default function Settings() {
  const nav = useNavigate();
  const { isDark, brandColor, toggleDark, setBrandColor } = useTheme();
  const [s, setS] = useState({});
  const [activeTab, setActiveTab] = useState('store');
  const [showBT, setShowBT] = useState(false);
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [confirmModal, setConfirmModal] = useState(null);
  useSheetOpen(!!confirmModal);
  const [confirmInput, setConfirmInput] = useState('');
  const scrollRef = useRef(null);
  const scrollingProgrammatically = useRef(false);

  const load = useCallback(async () => { setS(await getAllSettings()); }, []);
  useEffect(() => { load(); }, [load]);

  const upd = (k, v) => setS(prev => ({ ...prev, [k]: v }));
  const saveAll = async () => {
    const name = (s.store_name || '').trim();
    if (!name) { alert('Store name is required — it prints on every receipt.'); return; }

    const gstRate  = parseFloat(s.gst_rate);
    const critical = parseInt(s.critical_stock, 10);
    const low      = parseInt(s.low_stock, 10);
    if (s.gst_rate !== undefined && s.gst_rate !== '' && (isNaN(gstRate) || gstRate < 0 || gstRate > 100)) {
      alert('GST Rate must be a number between 0 and 100.'); return;
    }
    if (s.critical_stock !== undefined && s.critical_stock !== '' && (isNaN(critical) || critical < 0)) {
      alert('Critical Stock Threshold must be 0 or more.'); return;
    }
    if (s.low_stock !== undefined && s.low_stock !== '' && (isNaN(low) || low < 0)) {
      alert('Low Stock Threshold must be 0 or more.'); return;
    }
    if (!isNaN(critical) && !isNaN(low) && low < critical) {
      alert('Low Stock Threshold should be greater than or equal to Critical Stock Threshold.'); return;
    }
    const storePhoneDigits = (s.store_phone || '').replace(/\D/g, '').slice(-10);
    if (storePhoneDigits && storePhoneDigits.length !== 10) {
      alert('Store phone must be exactly 10 digits (or left blank).'); return;
    }

    const clean = { ...s, store_name: name, store_phone: storePhoneDigits ? `+91${storePhoneDigits}` : '' };
    setS(clean);
    await Promise.all(Object.entries(clean).map(([k,v]) => setSetting(k, v)));
    alert('Settings saved!');
  };

  const showConfirm = (title, message, keyword, onConfirm) => {
    setConfirmInput(''); setConfirmModal({ title, message, keyword, onConfirm });
  };

  const exportData = async () => {
    const data = await exportBackup();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `phoneshop-backup-${Date.now()}.json`; a.click();
    URL.revokeObjectURL(url);
  };

  // ── Swipeable category carousel ─────────────────────────────────────────
  const goToTab = (key) => {
    const idx = TABS.findIndex(t => t.key === key);
    if (idx < 0 || !scrollRef.current) return;
    scrollingProgrammatically.current = true;
    scrollRef.current.scrollTo({ left: idx * scrollRef.current.clientWidth, behavior: 'smooth' });
    setActiveTab(key);
    setTimeout(() => { scrollingProgrammatically.current = false; }, 400);
  };

  const handleCarouselScroll = (e) => {
    if (scrollingProgrammatically.current) return;
    const { scrollLeft, clientWidth } = e.target;
    const idx = Math.round(scrollLeft / clientWidth);
    const key = TABS[idx]?.key;
    if (key && key !== activeTab) setActiveTab(key);
  };

  const renderPanel = (key) => {
    switch(key) {
      case 'store': return (
        <>
          <Field label="Store Name" value={s.store_name||''} onChange={v=>upd('store_name',v)} />
          <Field label="Tagline" value={s.store_tagline||''} onChange={v=>upd('store_tagline',v)} />
          <Field label="Address" value={s.store_address||''} onChange={v=>upd('store_address',v)} multiline />
          <Field label="Phone" value={(s.store_phone||'').replace(/\D/g,'').slice(-10)}
            onChange={v=>upd('store_phone', v.replace(/[^0-9]/g,'').slice(0,10))} type="tel" prefix="+91" />
          <Field label="GST Number" value={s.gst_number||''} onChange={v=>upd('gst_number',v)} />
          <NumberField label="GST Rate (%)" value={s.gst_rate??'0'} onChange={v=>upd('gst_rate',v)} min={0} max={100} />

          <div style={{ height:1, background:'var(--divider)', margin:'4px 0' }} />
          <div style={{ fontSize:11, fontWeight:700, color:'var(--muted)', letterSpacing:0.5 }}>UPI PAYMENTS</div>
          <Field label="UPI ID" value={s.upi_id||''} onChange={v=>upd('upi_id',v)} placeholder="yourshop@upi" />
          <UpiQrField value={s.upi_qr_image||''} onChange={v=>upd('upi_qr_image',v)} />
          <Toggle
            label="Print QR Code on Bill"
            sub="Include the UPI QR image on printed UPI receipts"
            on={s.upi_qr_print_enabled!=='0'}
            onToggle={()=>{ const next = s.upi_qr_print_enabled==='0' ? '1' : '0'; setSetting('upi_qr_print_enabled', next); upd('upi_qr_print_enabled', next); }}
          />

          <div style={{ height:1, background:'var(--divider)', margin:'4px 0' }} />
          <Field label="Thank You Message" value={s.thank_you_msg||''} onChange={v=>upd('thank_you_msg',v)} />
          <Field label="Return Policy" value={s.return_policy||''} onChange={v=>upd('return_policy',v)} multiline />
          <SaveBtn onClick={saveAll} />
        </>
      );
      case 'alerts': return (
        <>
          <Toggle
            label="Critical Stock Alert"
            sub="Flag products at or below the critical threshold"
            on={s.critical_stock_alert_enabled!=='0'}
            onToggle={()=>{ const next = s.critical_stock_alert_enabled==='0' ? '1' : '0'; setSetting('critical_stock_alert_enabled', next); upd('critical_stock_alert_enabled', next); }}
          />
          <NumberField
            label="Critical Stock Threshold"
            value={s.critical_stock??'2'}
            onChange={v=>upd('critical_stock',v)}
            min={0}
            disabled={s.critical_stock_alert_enabled==='0'}
          />

          <div style={{ height:1, background:'var(--divider)', margin:'4px 0' }} />

          <Toggle
            label="Low Stock Alert"
            sub="Flag products at or below the low-stock threshold"
            on={s.low_stock_alert_enabled!=='0'}
            onToggle={()=>{ const next = s.low_stock_alert_enabled==='0' ? '1' : '0'; setSetting('low_stock_alert_enabled', next); upd('low_stock_alert_enabled', next); }}
          />
          <NumberField
            label="Low Stock Threshold"
            value={s.low_stock??'5'}
            onChange={v=>upd('low_stock',v)}
            min={0}
            disabled={s.low_stock_alert_enabled==='0'}
          />
          <SaveBtn onClick={saveAll} />
        </>
      );
      case 'security': return (
        <>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'var(--space-md)', background:'var(--surface-secondary)', borderRadius:'var(--radius-md)', border:'1px solid var(--border)' }}>
            <div>
              <div style={{ color:'var(--on-surface)', fontWeight:600 }}>PIN Lock</div>
              <div style={{ color:'var(--muted)', fontSize:12 }}>Require PIN on app launch</div>
            </div>
            <div onClick={async()=>{
              if (s.pin_enabled==='1') { await setSetting('pin_enabled','0'); upd('pin_enabled','0'); }
              else {
                if (pin.length!==4||pin!==confirmPin) return alert('Enter a matching 4-digit PIN.');
                await setSetting('pin_enabled','1'); await setSetting('pin_code',pin); upd('pin_enabled','1'); upd('pin_code',pin); setPin(''); setConfirmPin('');
              }
            }} style={{ width:48, height:28, borderRadius:14, background:s.pin_enabled==='1'?'var(--brand)':'var(--surface-tertiary)', position:'relative', cursor:'pointer', transition:'background 0.2s' }}>
              <div style={{ width:22, height:22, borderRadius:11, background:'#fff', position:'absolute', top:3, left:s.pin_enabled==='1'?22:3, transition:'left 0.2s', boxShadow:'0 1px 4px rgba(0,0,0,0.3)' }} />
            </div>
          </div>
          {s.pin_enabled!=='1' && (
            <>
              <Field label="New PIN (4 digits)" value={pin} onChange={v=>setPin(v.replace(/\D/g,'').slice(0,4))} type="password" />
              <Field label="Confirm PIN" value={confirmPin} onChange={v=>setConfirmPin(v.replace(/\D/g,'').slice(0,4))} type="password" />
            </>
          )}
        </>
      );
      case 'appearance': return (
        <>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'var(--space-md)', background:'var(--surface-secondary)', borderRadius:'var(--radius-md)', border:'1px solid var(--border)' }}>
            <div>
              <div style={{ color:'var(--on-surface)', fontWeight:600 }}>Dark Mode</div>
              <div style={{ color:'var(--muted)', fontSize:12 }}>{isDark?'Currently dark':'Currently light'}</div>
            </div>
            <div onClick={toggleDark} style={{ width:48, height:28, borderRadius:14, background:isDark?'var(--brand)':'var(--surface-tertiary)', position:'relative', cursor:'pointer', transition:'background 0.2s' }}>
              <div style={{ width:22, height:22, borderRadius:11, background:'#fff', position:'absolute', top:3, left:isDark?22:3, transition:'left 0.2s', boxShadow:'0 1px 4px rgba(0,0,0,0.3)' }} />
            </div>
          </div>
          <div style={{ height:1, background:'var(--divider)', margin:'4px 0' }} />
          <div style={{ fontSize:11, fontWeight:700, color:'var(--muted)', letterSpacing:0.5, marginBottom:8 }}>THEME COLOR</div>
          <div style={{ display:'flex', flexWrap:'wrap', gap:10 }}>
            {PRESET_COLORS.map(c=>(
              <button key={c.value} onClick={()=>setBrandColor(c.value)} style={{ width:44, height:44, borderRadius:22, background:c.value, border:brandColor===c.value?'3px solid var(--on-surface)':'3px solid transparent', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', boxShadow:'0 2px 8px rgba(0,0,0,0.2)' }}>
                {brandColor===c.value && <span style={{ color:'#000', fontWeight:800, fontSize:16 }}>✓</span>}
              </button>
            ))}
          </div>
          <div style={{ color:'var(--muted)', fontSize:12, marginTop:8 }}>Current: <span style={{ color:'var(--brand)', fontWeight:700 }}>{brandColor}</span></div>
        </>
      );
      case 'hardware': return (
        <HardwareTab s={s} upd={upd} setShowBT={setShowBT} />
      );
      case 'data': return (
        <>
          <button className="btn-ghost" style={{ width:'100%' }} onClick={exportData}>💾 Export Backup (JSON)</button>
          <div style={{ height:1, background:'var(--divider)', margin:'8px 0' }} />
          <button className="btn-ghost" style={{ width:'100%', color:'var(--warning)' }} onClick={()=>showConfirm('Reset Sales','Clear all invoices but keep products.\n\nType confirm to proceed.','confirm',async()=>{await resetSalesData();alert('Sales data cleared.');})}>
            🔄 Reset Sales Data
          </button>
          <button onClick={()=>showConfirm('Factory Reset','⚠️ This permanently erases ALL data:\nProducts, categories, invoices, repairs, and all settings.\n\nThe app will be completely blank after this.\n\nType confirm to proceed.','confirm',async()=>{await resetAllData(); window.location.reload();})} style={{ width:'100%', padding:'12px 16px', borderRadius:'var(--radius-md)', background:'var(--error)', border:'none', cursor:'pointer', color:'#fff', fontWeight:700, fontFamily:'var(--font)', display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
            🗑️ Factory Reset
          </button>
        </>
      );
    }
  };

  return (
    <div style={{ height:'100%', display:'flex', flexDirection:'column', background:'var(--surface)' }}>
      {/* Quick-jump pill tabs */}
      <div className="scroll-x" style={{ background:'var(--surface-secondary)', borderBottom:'1px solid var(--border)', paddingTop:'var(--safe-top)' }}>
        <div style={{ display:'flex', padding:'10px var(--space-md)', gap:4, minWidth:'max-content' }}>
          {TABS.map(t=>(
            <button key={t.key} onClick={()=>goToTab(t.key)} style={{ display:'flex', alignItems:'center', gap:6, padding:'8px var(--space-md)', borderRadius:'var(--radius-pill)', background:activeTab===t.key?'var(--brand)':'transparent', border:'none', cursor:'pointer', fontFamily:'var(--font)', fontWeight:600, fontSize:13, color:activeTab===t.key?'var(--on-brand)':'var(--muted)', whiteSpace:'nowrap' }}>
              <span>{t.icon}</span>{t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Swipeable category carousel */}
      <div
        ref={scrollRef}
        onScroll={handleCarouselScroll}
        style={{
          flex:1, display:'flex', overflowX:'auto', overflowY:'hidden',
          scrollSnapType:'x mandatory', WebkitOverflowScrolling:'touch',
        }}
      >
        {TABS.map(t => (
          <div
            key={t.key}
            className="scroll"
            style={{
              flex:'0 0 100%', width:'100%', scrollSnapAlign:'start',
              padding:'var(--space-lg)', display:'flex', flexDirection:'column',
              gap:'var(--space-md)', paddingBottom:40,
            }}
          >
            {renderPanel(t.key)}
          </div>
        ))}
      </div>

      {/* Position dots */}
      <div style={{ display:'flex', justifyContent:'center', gap:6, padding:'8px 0 10px' }}>
        {TABS.map(t => (
          <span key={t.key} onClick={()=>goToTab(t.key)} style={{
            width: activeTab===t.key ? 16 : 6, height:6, borderRadius:3,
            background: activeTab===t.key ? 'var(--brand)' : 'var(--border-strong)',
            transition:'all 0.2s', cursor:'pointer',
          }} />
        ))}
      </div>

      {showBT && (
        <BluetoothPrinterModal
          onClose={()=>setShowBT(false)}
          activeAddress={s.bt_printer_address}
          onConnected={async(name,addr)=>{
            await setSetting('bt_printer_name',name);
            await setSetting('bt_printer_address',addr);
            await addKnownPrinter(name, addr);
            upd('bt_printer_name',name);
            upd('bt_printer_address',addr);
          }}
        />
      )}

      {confirmModal && (
        <div className="modal-overlay">
          <div style={{ background:'var(--surface-secondary)', borderRadius:'var(--radius-lg)', padding:'var(--space-xl)', margin:'var(--space-lg)', width:'calc(100% - 32px)' }}>
            <div style={{ fontSize:17, fontWeight:700, color:'var(--on-surface)', marginBottom:8 }}>{confirmModal.title}</div>
            <div style={{ color:'var(--muted)', marginBottom:16, lineHeight:1.6, whiteSpace:'pre-line' }}>{confirmModal.message}</div>
            <input className="input" value={confirmInput} onChange={e=>setConfirmInput(e.target.value)} placeholder={`Type '${confirmModal.keyword}' to confirm`} autoCapitalize="none" style={{ marginBottom:16 }} />
            <div style={{ display:'flex', gap:10 }}>
              <button className="btn-ghost" style={{ flex:1 }} onClick={()=>setConfirmModal(null)}>Cancel</button>
              <button onClick={()=>{ if(confirmInput.toLowerCase()!==confirmModal.keyword){alert(`Type '${confirmModal.keyword}'`);return;} confirmModal.onConfirm(); setConfirmModal(null); }} style={{ flex:1, padding:12, borderRadius:'var(--radius-md)', background:'var(--error)', border:'none', cursor:'pointer', color:'#fff', fontWeight:700, fontFamily:'var(--font)', opacity:confirmInput.toLowerCase()===confirmModal.keyword?1:0.4 }}>Proceed</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Field({ label, value, onChange, type='text', multiline, placeholder, prefix }) {
  return (
    <div>
      <div className="label">{label}</div>
      {multiline
        ? <textarea value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} style={{ width:'100%', background:'var(--surface-secondary)', border:'1px solid var(--border)', borderRadius:'var(--radius-md)', padding:'10px var(--space-md)', color:'var(--on-surface)', fontFamily:'var(--font)', fontSize:14, minHeight:72, resize:'vertical', outline:'none' }} />
        : prefix
          ? (
            <div style={{ display:'flex', alignItems:'stretch', border:'1.5px solid var(--border-strong)', borderRadius:'var(--radius-md)', overflow:'hidden' }}>
              <span style={{ display:'flex', alignItems:'center', padding:'0 var(--space-md)', background:'var(--surface-tertiary)', color:'var(--muted)', fontWeight:700, fontSize:14, borderRight:'1px solid var(--divider)' }}>
                {prefix}
              </span>
              <input className="input" value={value} onChange={e=>onChange(e.target.value)} type={type} placeholder={placeholder} maxLength={10}
                style={{ border:'none', borderRadius:0, flex:1 }} />
            </div>
          )
          : <input className="input" value={value} onChange={e=>onChange(e.target.value)} type={type} placeholder={placeholder} />
      }
    </div>
  );
}

/**
 * Numeric field that clears itself the moment it's focused if it's currently
 * showing "0" — so the cashier can just start typing instead of selecting/
 * backspacing the placeholder zero first. If left empty on blur, it quietly
 * reverts to "0" so downstream math (which treats '' the same as 0 anyway)
 * always has something sensible printed on screen.
 */
function NumberField({ label, value, onChange, placeholder='0', min, max, disabled }) {
  return (
    <div>
      <div className="label">{label}</div>
      <input
        className="input"
        type="number"
        min={min}
        max={max}
        placeholder={placeholder}
        disabled={disabled}
        value={value}
        onFocus={e => { if (e.target.value === '0') onChange(''); }}
        onBlur={e => { if (e.target.value.trim() === '') onChange('0'); }}
        onChange={e => onChange(e.target.value)}
        style={disabled ? { opacity:0.5 } : undefined}
      />
    </div>
  );
}

/** Standard iOS-style switch used across the Settings screen. */
function Toggle({ on, onToggle, label, sub }) {
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'var(--space-md)', background:'var(--surface-secondary)', borderRadius:'var(--radius-md)', border:'1px solid var(--border)' }}>
      <div>
        <div style={{ color:'var(--on-surface)', fontWeight:600 }}>{label}</div>
        {sub && <div style={{ color:'var(--muted)', fontSize:12 }}>{sub}</div>}
      </div>
      <div onClick={onToggle} style={{ width:48, height:28, borderRadius:14, background:on?'var(--brand)':'var(--surface-tertiary)', position:'relative', cursor:'pointer', transition:'background 0.2s', flexShrink:0 }}>
        <div style={{ width:22, height:22, borderRadius:11, background:'#fff', position:'absolute', top:3, left:on?22:3, transition:'left 0.2s', boxShadow:'0 1px 4px rgba(0,0,0,0.3)' }} />
      </div>
    </div>
  );
}

/** UPI QR code image upload — reads a PNG/JPEG as base64 for local storage, preview, and printing. */
function UpiQrField({ value, onChange }) {
  const MAX_BYTES = 2 * 1024 * 1024; // 2MB — generous for a QR image, keeps settings storage light
  const [error, setError] = useState('');

  const handleFile = (e) => {
    const file = e.target.files?.[0];
    e.target.value = ''; // allow re-selecting the same file later
    if (!file) return;
    setError('');
    if (!/^image\/(png|jpeg)$/.test(file.type)) {
      setError('Please choose a PNG or JPEG image.');
      return;
    }
    if (file.size > MAX_BYTES) {
      setError('Image is too large — please use a file under 2MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => onChange(reader.result);
    reader.onerror = () => setError('Could not read that image — please try again.');
    reader.readAsDataURL(file);
  };

  return (
    <div>
      <div className="label">UPI QR CODE (PNG)</div>
      {value ? (
        <div style={{ display:'flex', alignItems:'center', gap:12, background:'var(--surface-secondary)', border:'1px solid var(--border)', borderRadius:'var(--radius-md)', padding:'var(--space-md)' }}>
          <div style={{ background:'#fff', borderRadius:8, padding:6, flexShrink:0 }}>
            <img src={value} alt="UPI QR" style={{ width:64, height:64, objectFit:'contain', display:'block' }} />
          </div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:13 }}>QR code uploaded</div>
            <div style={{ color:'var(--muted)', fontSize:11, marginTop:2 }}>Shown at checkout and printed on UPI bills</div>
          </div>
          <button onClick={()=>onChange('')} style={{ background:'var(--error-soft)', border:'1.5px solid var(--error)44', borderRadius:'var(--radius-md)', padding:'6px 12px', color:'var(--error)', fontWeight:700, cursor:'pointer', fontFamily:'var(--font)', fontSize:12, flexShrink:0 }}>
            Remove
          </button>
        </div>
      ) : (
        <label style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:8, padding:'var(--space-md)', background:'var(--surface-secondary)', border:'1.5px dashed var(--border-strong)', borderRadius:'var(--radius-md)', cursor:'pointer', color:'var(--muted)', fontFamily:'var(--font)', fontSize:13, fontWeight:600 }}>
          <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
          Upload QR code image
          <input type="file" accept="image/png,image/jpeg" onChange={handleFile} style={{ display:'none' }} />
        </label>
      )}
      {error && <div style={{ color:'var(--error)', fontSize:12, marginTop:6 }}>{error}</div>}
    </div>
  );
}

function SaveBtn({ onClick }) {
  return <button className="btn-primary" style={{ width:'100%', marginTop:8 }} onClick={onClick}>Save Settings</button>;
}
