import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { listCategories, addProduct, updateProduct, listProducts, getProductByBarcode } from '../db/database.js';
import { takePendingBarcode } from '../utils/scanBridge.js';
import { showToast } from '../utils/toast.js';

export default function AddProduct() {
  const nav = useNavigate();
  const loc = useLocation();
  const editId = loc.state?.id || null;

  const [cats, setCats] = useState([]);
  const [name, setName] = useState('');
  const [barcode, setBarcode] = useState(loc.state?.barcode || '');
  const [categoryId, setCategoryId] = useState(null);
  const [price, setPrice] = useState('');
  const [stock, setStock] = useState('');
  const [size, setSize] = useState('');
  const [location, setLocation] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    // If we just came back from the scanner (see Scanner.jsx / scanBridge.js),
    // pick up the scanned code here instead of via route state.
    const scanned = takePendingBarcode();
    if (scanned) setBarcode(scanned);

    (async () => {
      const c = await listCategories();
      setCats(c);
      if (editId) {
        const all = await listProducts();
        const p = all.find(x => x.id === editId);
        if (p) {
          setName(p.name); setBarcode(p.barcode||'');
          setCategoryId(p.category_id); setPrice(String(p.price));
          setStock(String(p.stock)); setSize(p.size||''); setLocation(p.location||'');
        }
      } else {
        // Pre-select the category we were opened from (e.g. "Add Product"
        // tapped from inside a category's drill-down view), falling back to
        // the first category if none was specified.
        const defaultId = loc.state?.defaultCategoryId;
        if (defaultId && c.some(cat => cat.id === defaultId)) setCategoryId(defaultId);
        else if (c.length > 0) setCategoryId(c[0].id);
      }
    })();
  }, [editId]);

  const save = async () => {
    if (!name.trim()) return alert('Product name is required.');
    if (!categoryId) return alert('Please select a category.');
    const priceNum = parseFloat(price);
    const stockNum = parseInt(stock, 10);
    if (isNaN(priceNum) || priceNum < 0) return alert('Enter a valid price.');
    if (isNaN(stockNum) || stockNum < 0) return alert('Enter a valid stock.');
    setSaving(true);
    try {
      if (barcode) {
        const dup = await getProductByBarcode(barcode);
        // A duplicate is only a problem if it belongs to some *other* product —
        // editing a product without changing its own barcode should still work.
        if (dup && dup.id !== editId) return alert('A product with this barcode already exists.');
      }
      if (editId) {
        await updateProduct(editId, { name, barcode: barcode||null, category_id: categoryId, price: priceNum, stock: stockNum, size: size||null, location: location||null });
        showToast('Product updated successfully!');
      } else {
        await addProduct({ name, barcode: barcode||null, category_id: categoryId, price: priceNum, stock: stockNum, size: size||null, location: location||null });
        showToast('Product added successfully!');
      }
      nav(-1);
    } catch(e) { alert('Save failed: '+e.message); }
    finally { setSaving(false); }
  };

  return (
    <div style={{ height:'100%', display:'flex', flexDirection:'column', background:'var(--surface)' }}>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'var(--space-lg)', paddingTop:'calc(var(--safe-top) + 16px)', borderBottom:'1px solid var(--border)' }}>
        <button onClick={()=>nav(-1)} className="icon-btn">✕</button>
        <span style={{ fontSize:16, fontWeight:700, color:'var(--on-surface)' }}>{editId?'Edit Product':'Add Product'}</span>
        <div style={{ width:36 }} />
      </div>

      <div className="scroll" style={{ flex:1, padding:'var(--space-lg)', display:'flex', flexDirection:'column', gap:'var(--space-md)', paddingBottom:80 }}>
        {/* Category */}
        <div>
          <div className="label">CATEGORY *</div>
          {cats.length === 0 ? (
            <div style={{ display:'flex', alignItems:'center', gap:8, padding:'var(--space-md)', background:'var(--warning-soft)', borderRadius:'var(--radius-md)', border:'1px solid var(--warning)' }}>
              <span>⚠️</span>
              <span style={{ color:'var(--muted)', fontSize:13 }}>No categories yet. </span>
              <button onClick={()=>nav('/categories')} style={{ background:'none', border:'none', color:'var(--brand)', fontWeight:700, cursor:'pointer', fontFamily:'var(--font)', fontSize:13 }}>Create one →</button>
            </div>
          ) : (
            <div className="scroll-x" style={{ display:'flex', gap:8 }}>
              {cats.map(c => (
                <button key={c.id} onClick={()=>setCategoryId(c.id)} style={{ flexShrink:0, height:36, padding:'0 var(--space-lg)', borderRadius:'var(--radius-pill)', background:categoryId===c.id?'var(--surface-inverse)':'var(--surface-tertiary)', border:'none', cursor:'pointer', fontFamily:'var(--font)', fontWeight:600, fontSize:13, color:categoryId===c.id?'var(--on-surface-inverse)':'var(--on-surface)', whiteSpace:'nowrap' }}>{c.name}</button>
              ))}
            </div>
          )}
        </div>

        <Field label="PRODUCT NAME *" value={name} onChange={setName} placeholder="e.g. iPhone 15 128GB" />

        {/* Barcode with scan */}
        <div>
          <div className="label">BARCODE</div>
          <div style={{ display:'flex', gap:8 }}>
            <input className="input" value={barcode} onChange={e=>setBarcode(e.target.value)} placeholder="Enter manually or scan" style={{ flex:1 }} />
            <button onClick={()=>nav('/scanner', {state:{returnTo:'add-product', existingId:editId||''}})} style={{ width:44, height:44, borderRadius:'var(--radius-md)', background:'var(--brand)', border:'none', cursor:'pointer', fontSize:20, display:'flex', alignItems:'center', justifyContent:'center' }}>📷</button>
          </div>
        </div>

        <div style={{ display:'flex', gap:'var(--space-md)' }}>
          <div style={{ flex:1 }}><Field label="PRICE (₹) *" value={price} onChange={setPrice} type="number" placeholder="0" /></div>
          <div style={{ flex:1 }}><Field label="STOCK *" value={stock} onChange={setStock} type="number" placeholder="0" /></div>
        </div>

        <Field label="STORAGE / VARIANT" value={size} onChange={setSize} placeholder="e.g. 128GB, 256GB, Blue" />
        <Field label="LOCATION" value={location} onChange={setLocation} placeholder="e.g. Shelf A2" />

        <button className="btn-primary" style={{ marginTop:8, padding:16, borderRadius:'var(--radius-lg)', fontSize:15, display:'flex', alignItems:'center', justifyContent:'center', gap:8, opacity: saving ? 0.7 : 1 }} onClick={save} disabled={saving}>
          {saving ? (
            <>
              <div style={{ width:16, height:16, borderRadius:8, border:'2px solid currentColor', borderTopColor:'transparent', animation:'spin 0.8s linear infinite' }} />
              Saving…
            </>
          ) : (editId ? '✓ Save Changes' : '✓ Save & Add')}
        </button>
      </div>

      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

function Field({ label, value, onChange, type='text', placeholder }) {
  return (
    <div>
      <div className="label">{label}</div>
      <input className="input" value={value} onChange={e=>onChange(e.target.value)} type={type} placeholder={placeholder} />
    </div>
  );
}
