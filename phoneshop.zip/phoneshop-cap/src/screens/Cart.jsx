import { useState, useMemo, useCallback, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../state/context.jsx';
import { createInvoice, getSetting, getAllSettings, listProducts, formatCurrency } from '../db/database.js';
import UpiPaymentModal from '../components/UpiPaymentModal.jsx';

const PAY_MODES = ['Cash', 'UPI', 'Card', 'Credit'];

const CAT_ICONS = {
  Smartphones:'📱', Audio:'🎧', 'Power & Charging':'🔋',
  Accessories:'🔌', 'Cases & Covers':'🛡️', Tablets:'📲',
  Smartwatches:'⌚', Laptops:'💻', Gaming:'🎮', Cameras:'📷',
};

// Modern scan icon — same as tab bar
const ScanIcon = ({ size = 20, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 7V5a2 2 0 012-2h2"/>
    <path d="M17 3h2a2 2 0 012 2v2"/>
    <path d="M21 17v2a2 2 0 01-2 2h-2"/>
    <path d="M7 21H5a2 2 0 01-2-2v-2"/>
    <line x1="7"  y1="8" x2="7"  y2="16" strokeWidth="1.5"/>
    <line x1="10" y1="8" x2="10" y2="16" strokeWidth="2.5"/>
    <line x1="13" y1="8" x2="13" y2="16" strokeWidth="1.5"/>
    <line x1="16" y1="8" x2="16" y2="16" strokeWidth="2.5"/>
  </svg>
);

export default function Cart() {
  const nav = useNavigate();
  const { items, updateQty, removeItem, clearCart, subtotal, addItem } = useCart();

  const [customer,    setCustomer]    = useState('');
  const [phone,       setPhone]       = useState('');
  const [discount,    setDiscount]    = useState('');
  const [payMode,     setPayMode]     = useState('Cash');
  const [gstRate,     setGstRate]     = useState(0);   // default 0%
  const [processing,  setProcessing]  = useState(false);
  const [query,       setQuery]       = useState('');
  const [allProds,    setAllProds]    = useState([]);
  const [prodsLoaded, setProdsLoaded] = useState(false);
  const [upiInfo,     setUpiInfo]     = useState({ upi_id:'', upi_qr_image:'' });
  const [showUpiModal, setShowUpiModal] = useState(false);
  const [pendingAction, setPendingAction] = useState(null); // 'done' | 'print'

  // Load saved GST rate + UPI details from settings
  useEffect(() => {
    getSetting('gst_rate').then(v => {
      const n = parseFloat(v || '0');
      setGstRate(isNaN(n) ? 0 : n);
    });
    getAllSettings().then(s => setUpiInfo({ upi_id: s.upi_id || '', upi_qr_image: s.upi_qr_image || '' }));
  }, []);

  // Load products on first search keystroke
  const ensureProds = useCallback(async () => {
    if (prodsLoaded) return;
    setAllProds(await listProducts());
    setProdsLoaded(true);
  }, [prodsLoaded]);

  const handleQueryChange = async (v) => {
    setQuery(v);
    if (v.trim()) await ensureProds();
  };

  // Dropdown search results
  const searchResults = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return allProds
      .filter(p => p.name.toLowerCase().includes(q) || (p.barcode || '').includes(q))
      .slice(0, 8);
  }, [query, allProds]);

  const addProduct = (p) => {
    if (p.stock <= 0) { alert(`${p.name} is out of stock.`); return; }
    addItem(p);
    setQuery('');
  };

  // Billing math
  const discountAmt   = parseFloat(discount) || 0;
  const afterDiscount = Math.max(0, subtotal - discountAmt);
  const gst           = parseFloat((afterDiscount * (gstRate / 100)).toFixed(2));
  const total         = parseFloat((afterDiscount + gst).toFixed(2));

  // ── Common checkout: validates stock live, creates invoice, returns invoice object ──
  const doCheckout = async () => {
    if (items.length === 0) { alert('Add items to the bill first.'); return null; }
    if (phone.length > 0 && phone.length !== 10) {
      alert('Customer phone number must be exactly 10 digits (or left blank).');
      return null;
    }

    // Live stock check against DB — catches cases where stock changed since item was added
    const allProds = await listProducts();
    const stockErrors = [];
    for (const it of items) {
      const prod = allProds.find(p => p.id === it.product_id);
      if (!prod) {
        stockErrors.push(`"${it.name}" no longer exists in inventory.`);
      } else if (prod.stock < it.qty) {
        stockErrors.push(`"${it.name}": only ${prod.stock} in stock, but ${it.qty} in cart.`);
      }
    }
    if (stockErrors.length > 0) {
      alert('Stock issue — please fix before billing:\n\n' + stockErrors.join('\n'));
      return null;
    }

    // Use the GST rate currently shown on screen (which the cashier may have
    // edited for this bill) rather than silently re-reading the saved default
    // from settings — otherwise the printed/saved total can differ from what
    // was displayed at checkout.
    const inv = await createInvoice(items, {
      customer_name:   customer,
      customer_phone:  phone ? `+91${phone}` : '',
      gst_rate:        gstRate,
      discount_amount: discountAmt,
      payment_mode:    payMode,
    });
    clearCart();
    setCustomer(''); setPhone(''); setDiscount(''); setPayMode('Cash');
    return inv;
  };

  // ── Done: save bill, go to Reports ──
  const handleDone = async () => {
    if (processing) return;
    if (payMode === 'UPI') { setPendingAction('done'); setShowUpiModal(true); return; }
    setProcessing(true);
    try {
      await doCheckout();
      nav('/reports');
    } catch(e) { alert('Checkout failed: ' + e.message); }
    finally { setProcessing(false); }
  };

  // ── Print: save bill, open receipt for printing ──
  const handlePrint = async () => {
    if (processing) return;
    if (payMode === 'UPI') { setPendingAction('print'); setShowUpiModal(true); return; }
    setProcessing(true);
    try {
      const inv = await doCheckout();
      if (inv) nav(`/receipt/${inv.id}`, { state: { justCompleted: true } });
    } catch(e) { alert('Checkout failed: ' + e.message); }
    finally { setProcessing(false); }
  };

  // ── Called from the UPI modal once the cashier confirms payment was received ──
  const handleUpiConfirmed = async () => {
    setProcessing(true);
    try {
      const inv = await doCheckout();
      setShowUpiModal(false);
      if (!inv) return;
      if (pendingAction === 'print') nav(`/receipt/${inv.id}`, { state: { justCompleted: true } });
      else nav('/reports');
    } catch(e) { alert('Checkout failed: ' + e.message); }
    finally { setProcessing(false); setPendingAction(null); }
  };

  // ── Footer height so content doesn't hide under it ──
  // Was previously a hardcoded guess (220px). That guess didn't always match
  // the footer's real rendered height (payment chips can wrap, font scaling
  // varies by device), so on some phones the keyboard-avoidance math was
  // wrong and fields like Customer Name ended up scrolled out of view instead
  // of settling just above the keyboard. Now we measure the real footer and
  // publish it as --fixed-footer-h, which index.css uses for scroll-margin-bottom.
  const footerRef = useRef(null);
  const [footerH, setFooterH] = useState(0);

  useEffect(() => {
    if (items.length === 0) { setFooterH(0); return; }
    const el = footerRef.current;
    if (!el) return;
    const measure = () => setFooterH(el.getBoundingClientRect().height);
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [items.length]);

  useEffect(() => {
    document.documentElement.style.setProperty('--fixed-footer-h', `${footerH}px`);
    return () => document.documentElement.style.setProperty('--fixed-footer-h', '0px');
  }, [footerH]);

  return (
    <div style={{ height:'100%', display:'flex', flexDirection:'column', background:'var(--surface)', position:'relative' }}>

      {/* ── Header ── */}
      <div style={{
        background:'var(--surface)', borderBottom:'1.5px solid var(--border)',
        padding:'var(--space-md) var(--space-lg)',
        paddingTop:'calc(var(--safe-top) + 12px)',
      }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'var(--space-md)' }}>
          <div>
            <div style={{ fontSize:22, fontWeight:900, color:'var(--on-surface)' }}>Current Bill</div>
            <div style={{ color:'var(--muted)', fontSize:12, marginTop:2 }}>
              {items.length > 0 ? `${items.length} item${items.length!==1?'s':''}` : 'Scan or search to add items'}
            </div>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <button
              onClick={() => nav('/reports')}
              className="icon-btn"
              title="View previous bills">
              <svg width={17} height={17} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
                <polyline points="14 2 14 8 20 8"/>
                <line x1="9" y1="13" x2="15" y2="13"/>
                <line x1="9" y1="17" x2="13" y2="17"/>
              </svg>
            </button>
            {items.length > 0 && (
              <button
                onClick={() => { if (confirm('Clear all items?')) clearCart(); }}
                style={{ background:'var(--error-soft)', border:'1.5px solid var(--error)44', borderRadius:'var(--radius-md)', padding:'6px 12px', color:'var(--error)', fontWeight:700, cursor:'pointer', fontFamily:'var(--font)', fontSize:13 }}>
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Search bar */}
        <div style={{ position:'relative' }}>
          <div style={{ display:'flex', alignItems:'center', background:'var(--surface-secondary)', border:'1.5px solid var(--border-strong)', borderRadius:'var(--radius-lg)', padding:'0 var(--space-md)', height:48, gap:10 }}>
            <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="var(--muted)" strokeWidth="2.5" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input
              value={query} onChange={e => handleQueryChange(e.target.value)}
              placeholder="Search by name or barcode…"
              style={{ flex:1, background:'none', border:'none', outline:'none', color:'var(--on-surface)', fontFamily:'var(--font)', fontSize:14 }} />
            {query && (
              <button onClick={() => setQuery('')} style={{ background:'none', border:'none', color:'var(--muted)', cursor:'pointer', fontSize:18, lineHeight:1 }}>✕</button>
            )}
          </div>

          {/* Dropdown */}
          {searchResults.length > 0 && (
            <div style={{ position:'absolute', top:'calc(100% + 6px)', left:0, right:0, background:'var(--surface-elevated)', border:'1.5px solid var(--border-strong)', borderRadius:'var(--radius-lg)', zIndex:50, overflow:'hidden', boxShadow:'0 8px 32px rgba(0,0,0,0.45)' }}>
              {searchResults.map((p, i) => (
                <button key={p.id} onClick={() => addProduct(p)}
                  disabled={p.stock <= 0}
                  style={{ width:'100%', display:'flex', alignItems:'center', gap:'var(--space-md)', padding:'var(--space-md)', background: p.stock <= 0 ? 'var(--surface-tertiary)' : 'none', border:'none', cursor: p.stock <= 0 ? 'not-allowed' : 'pointer', fontFamily:'var(--font)', borderBottom:i<searchResults.length-1?'1px solid var(--divider)':'none', textAlign:'left', opacity: p.stock <= 0 ? 0.55 : 1 }}>
                  <span style={{ fontSize:22, flexShrink:0 }}>{CAT_ICONS[p.category_name]||'📦'}</span>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:14, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{p.name}</div>
                    <div style={{ display:'flex', alignItems:'center', gap:6, marginTop:4, flexWrap:'wrap' }}>
                      {p.location && (
                        <span style={{
                          display:'flex', alignItems:'center', gap:3,
                          background:'var(--warning-soft)', border:'1px solid var(--warning)55',
                          borderRadius:'var(--radius-pill)', padding:'2px 8px',
                          color:'var(--warning)', fontSize:10, fontWeight:800,
                        }}>
                          <svg width={10} height={10} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                          {p.location}
                        </span>
                      )}
                      <span style={{ color:'var(--muted)', fontSize:11 }}>{p.stock} in stock</span>
                    </div>
                  </div>
                  <div style={{ textAlign:'right', flexShrink:0 }}>
                    <div style={{ color:'var(--brand)', fontWeight:800, fontSize:14 }}>{formatCurrency(p.price)}</div>
                    <div style={{ color: p.stock > 0 ? 'var(--success)' : 'var(--error)', fontSize:10, fontWeight:800 }}>
                      {p.stock > 0 ? `${p.stock} in stock` : 'OUT OF STOCK'}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
          {query.trim() && searchResults.length === 0 && prodsLoaded && (
            <div style={{ position:'absolute', top:'calc(100% + 6px)', left:0, right:0, background:'var(--surface-elevated)', border:'1.5px solid var(--border-strong)', borderRadius:'var(--radius-lg)', zIndex:50, padding:'var(--space-lg)', textAlign:'center', color:'var(--muted)', fontSize:13 }}>
              No products found for "{query}"
            </div>
          )}
        </div>
      </div>

      {/* ── Empty state ── */}
      {items.length === 0 && !query && (
        <div style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:20, padding:'var(--space-xl)', paddingBottom:120 }}>
          <div style={{
            width:88, height:88, borderRadius:44,
            background:'var(--surface-secondary)', border:'2px solid var(--border-strong)',
            display:'flex', alignItems:'center', justifyContent:'center',
          }}>
            <ScanIcon size={38} color="var(--muted)" />
          </div>
          <div style={{ textAlign:'center' }}>
            <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:18 }}>Cart is empty</div>
            <div style={{ color:'var(--muted)', fontSize:13, marginTop:6, lineHeight:1.6 }}>
              Tap the scan button below,{'\n'}or search by name above
            </div>
          </div>
        </div>
      )}

      {/* ── Cart items + billing form ── */}
      {items.length > 0 && (
        <div className="scroll" style={{ flex:1, padding:'var(--space-md) var(--space-lg)', display:'flex', flexDirection:'column', gap:'var(--space-md)', paddingBottom: footerH + 88 }}>

          {/* Items */}
          {items.map(it => (
            <div key={it.product_id} style={{ display:'flex', alignItems:'center', background:'var(--surface-secondary)', border:'1.5px solid var(--border)', borderRadius:'var(--radius-lg)', padding:'var(--space-md)', gap:'var(--space-md)' }}>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ color:'var(--on-surface)', fontWeight:700, fontSize:14, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{it.name}</div>
                <div style={{ color:'var(--brand)', fontWeight:800, fontSize:13, marginTop:3 }}>{formatCurrency(it.price)}</div>
              </div>
              <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                <button onClick={() => updateQty(it.product_id, it.qty-1)}
                  style={{ width:34, height:34, borderRadius:10, background:'var(--surface-tertiary)', border:'1.5px solid var(--border-strong)', cursor:'pointer', fontSize:20, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center', color:'var(--on-surface)' }}>−</button>
                <span style={{ color:'var(--on-surface)', fontWeight:800, minWidth:30, textAlign:'center', fontSize:16 }}>{it.qty}</span>
                <button onClick={() => updateQty(it.product_id, it.qty+1)}
                  disabled={it.qty >= (it.stock ?? 9999)}
                  style={{ width:34, height:34, borderRadius:10, background: it.qty >= (it.stock ?? 9999) ? 'var(--surface-tertiary)' : 'var(--brand)', border:'none', cursor: it.qty >= (it.stock ?? 9999) ? 'not-allowed' : 'pointer', fontSize:20, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center', color: it.qty >= (it.stock ?? 9999) ? 'var(--muted)' : 'var(--on-brand)', opacity: it.qty >= (it.stock ?? 9999) ? 0.4 : 1 }}>+</button>
                <button onClick={() => removeItem(it.product_id)}
                  style={{ width:34, height:34, background:'var(--error-soft)', border:'1.5px solid var(--error)44', borderRadius:10, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }}>
                  <svg width={15} height={15} viewBox="0 0 24 24" fill="none" stroke="var(--error)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6M14 11v6"/>
                  </svg>
                </button>
              </div>
              <span style={{ color:'var(--on-surface)', fontWeight:800, fontSize:14, flexShrink:0, minWidth:64, textAlign:'right' }}>{formatCurrency(it.price * it.qty)}</span>
            </div>
          ))}

          {/* Customer */}
          <div style={{ borderRadius:'var(--radius-lg)', border:'1.5px solid var(--border)', overflow:'hidden', background:'var(--surface-secondary)' }}>
            <div style={{ padding:'var(--space-sm) var(--space-md)', borderBottom:'1px solid var(--divider)', fontSize:11, fontWeight:700, color:'var(--muted)', letterSpacing:0.5 }}>
              CUSTOMER (optional)
            </div>
            <input className="input" value={customer} onChange={e => setCustomer(e.target.value)} placeholder="Customer name" style={{ borderRadius:0, border:'none', borderBottom:'1px solid var(--divider)' }} />
            <div style={{ display:'flex', alignItems:'stretch' }}>
              <span style={{ display:'flex', alignItems:'center', padding:'0 var(--space-md)', background:'var(--surface-tertiary)', color:'var(--muted)', fontWeight:700, fontSize:14, borderRight:'1px solid var(--divider)' }}>
                +91
              </span>
              <input className="input" value={phone}
                onChange={e => setPhone(e.target.value.replace(/[^0-9]/g, '').slice(0, 10))}
                placeholder="10-digit phone number" type="tel" inputMode="numeric" maxLength={10}
                style={{ borderRadius:0, border:'none', flex:1 }} />
            </div>
            {phone.length > 0 && phone.length < 10 && (
              <div style={{ padding:'4px var(--space-md) 8px', fontSize:11, color:'var(--error)' }}>
                Enter a valid 10-digit number
              </div>
            )}
          </div>

          {/* Discount + GST */}
          <div style={{ display:'flex', gap:'var(--space-md)' }}>
            <div style={{ flex:1 }}>
              <div className="label">DISCOUNT (₹)</div>
              <input className="input" value={discount} onChange={e => {
                const v = e.target.value;
                if (v === '') { setDiscount(''); return; }
                const n = parseFloat(v);
                if (isNaN(n) || n < 0) return;
                setDiscount(String(Math.min(n, subtotal))); // can't discount more than the bill itself
              }} placeholder="0" type="number" min="0" max={subtotal} />
            </div>
            <div style={{ flex:1 }}>
              <div className="label">GST (%)</div>
              <input className="input" value={gstRate} type="number" min="0" max="100" placeholder="0"
                onFocus={e => { if (e.target.value === '0') setGstRate(''); }}
                onBlur={e => { if (e.target.value.trim() === '') setGstRate(0); }}
                onChange={e => {
                  const v = e.target.value;
                  if (v === '') { setGstRate(''); return; }
                  const n = parseFloat(v);
                  if (isNaN(n)) return;
                  setGstRate(Math.max(0, Math.min(100, n))); // GST is always 0-100%
                }} />
            </div>
          </div>


          {/* Bill summary */}
          <div style={{ background:'var(--surface-secondary)', border:'1.5px solid var(--border)', borderRadius:'var(--radius-lg)', overflow:'hidden' }}>
            <div style={{ padding:'var(--space-sm) var(--space-md)', borderBottom:'1px solid var(--divider)', fontSize:11, fontWeight:700, color:'var(--muted)', letterSpacing:0.5 }}>
              BILL SUMMARY
            </div>
            <div style={{ padding:'var(--space-md)', display:'flex', flexDirection:'column', gap:8 }}>
              {[
                ['Subtotal',                          formatCurrency(subtotal)],
                discountAmt > 0 && ['Discount',       `-${formatCurrency(discountAmt)}`],
                gstRate > 0     && [`GST (${gstRate}%)`, formatCurrency(gst)],
              ].filter(Boolean).map(([k, v]) => (
                <div key={k} style={{ display:'flex', justifyContent:'space-between' }}>
                  <span style={{ color:'var(--muted)', fontWeight:600, fontSize:14 }}>{k}</span>
                  <span style={{ color:'var(--on-surface)', fontWeight:700, fontSize:14 }}>{v}</span>
                </div>
              ))}
              <div style={{ height:1.5, background:'var(--border-strong)', margin:'4px 0' }} />
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <span style={{ color:'var(--on-surface)', fontWeight:800, fontSize:17 }}>Total</span>
                <span style={{ color:'var(--brand)', fontWeight:900, fontSize:22 }}>{formatCurrency(total)}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Fixed billing footer — only when items exist ── */}
      {items.length > 0 && (
        <div ref={footerRef} style={{
          position:'absolute', bottom:`calc(var(--tab-height))`,
          left:0, right:0,
          background:'var(--surface-secondary)',
          borderTop:'2px solid var(--border-strong)',
          padding:'var(--space-md) var(--space-lg)',
          paddingBottom:'calc(var(--space-md) + var(--safe-bottom))',
          display:'flex', flexDirection:'column', gap:'var(--space-md)',
          boxShadow:'0 -4px 20px rgba(0,0,0,0.2)',
        }}>
          {/* Payment mode chips */}
          <div style={{ display:'flex', gap:6 }}>
            {PAY_MODES.map(m => (
              <button key={m} onClick={() => setPayMode(m)} style={{
                flex:1, padding:'9px 4px',
                borderRadius:'var(--radius-md)',
                background: payMode===m ? 'var(--surface-inverse)' : 'var(--surface-tertiary)',
                border:`1.5px solid ${payMode===m ? 'var(--border-strong)' : 'var(--border)'}`,
                cursor:'pointer',
                color: payMode===m ? 'var(--on-surface-inverse)' : 'var(--on-surface)',
                fontWeight:700, fontSize:11, fontFamily:'var(--font)',
                transition:'all 0.15s',
              }}>{m}</button>
            ))}
          </div>

          {/* ── Two action buttons: Done + Print ── */}
          <div style={{ display:'flex', gap:'var(--space-md)' }}>

            {/* Done — saves bill, goes to Reports */}
            <button
              onClick={handleDone}
              disabled={processing}
              style={{
                flex:1, display:'flex', alignItems:'center', justifyContent:'center', gap:8,
                padding:15, borderRadius:'var(--radius-lg)',
                background:'var(--surface-tertiary)',
                border:'2px solid var(--border-strong)',
                cursor:'pointer', fontFamily:'var(--font)', fontWeight:800, fontSize:15,
                color:'var(--on-surface)', opacity: processing ? 0.5 : 1,
                transition:'opacity 0.15s',
              }}>
              {/* Checkmark icon */}
              <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
              Done
            </button>

            {/* Print — saves bill, opens receipt */}
            <button
              onClick={handlePrint}
              disabled={processing}
              style={{
                flex:2, display:'flex', alignItems:'center', justifyContent:'center', gap:8,
                padding:15, borderRadius:'var(--radius-lg)',
                background:'var(--brand)',
                border:'none',
                cursor:'pointer', fontFamily:'var(--font)', fontWeight:800, fontSize:15,
                color:'var(--on-brand)', opacity: processing ? 0.5 : 1,
                transition:'opacity 0.15s',
                boxShadow:'0 4px 16px var(--brand-soft)',
              }}>
              {processing ? (
                <>
                  <div style={{ width:16, height:16, borderRadius:8, border:'2px solid var(--on-brand)', borderTopColor:'transparent', animation:'spin 0.8s linear infinite' }} />
                  Processing…
                </>
              ) : (
                <>
                  {/* Printer icon */}
                  <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="6 9 6 2 18 2 18 9"/>
                    <path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/>
                    <rect x="6" y="14" width="12" height="8"/>
                  </svg>
                  Print & Save  {formatCurrency(total)}
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* ── Fixed Scan Button — bottom-right pill, clear of the Cart tab's
             circular center FAB directly below (stacking two circles on the
             same axis was causing accidental taps between them) ── */}
      <button
        onClick={() => nav('/scanner', { state: { returnTo: 'cart' } })}
        style={{
          position:'absolute',
          bottom: items.length > 0
            ? `calc(var(--tab-height) + ${footerH}px + 20px)`   // above billing footer
            : `calc(var(--tab-height) + 28px)`,                  // clear of the tab bar's center FAB
          right:20,
          display:'flex', alignItems:'center', gap:8,
          padding:'14px 20px', borderRadius:'var(--radius-pill)',
          background:'linear-gradient(135deg, var(--brand), #7C5CFF)',
          border:'none',
          cursor:'pointer', fontFamily:'var(--font)', fontWeight:800, fontSize:14,
          color:'#001722',
          boxShadow:'0 6px 24px var(--brand-soft), 0 2px 8px rgba(0,0,0,0.3)',
          zIndex:60,
          transition:'bottom 0.2s ease, transform 0.1s',
        }}
        onMouseDown={e => e.currentTarget.style.transform='scale(0.95)'}
        onMouseUp={e   => e.currentTarget.style.transform='scale(1)'}
        onTouchStart={e => e.currentTarget.style.transform='scale(0.95)'}
        onTouchEnd={e   => e.currentTarget.style.transform='scale(1)'}
        title="Scan barcode"
      >
        <ScanIcon size={20} color="#001722" />
        Scan
      </button>

      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>

      {showUpiModal && (
        <UpiPaymentModal
          amount={total}
          upiId={upiInfo.upi_id}
          qrImage={upiInfo.upi_qr_image}
          busy={processing}
          onConfirm={handleUpiConfirmed}
          onClose={() => { setShowUpiModal(false); setPendingAction(null); }}
        />
      )}
    </div>
  );
}
