import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import App from '../App.jsx';

beforeEach(() => { localStorage.clear(); });

describe('Category sheet hides the tab bar (regression: this used the older .modal-overlay CSS class, which I had not fixed in the previous pass)', () => {
  it('unmounts the nav/tab bar while "New Category" is open, and restores it on close', async () => {
    render(<App />);
    await waitFor(() => expect(document.querySelector('nav')).toBeTruthy(), { timeout: 5000 });

    window.history.pushState({}, '', '#/products');
    fireEvent(window, new PopStateEvent('popstate'));

    fireEvent.click(await screen.findByText('Categories'));
    fireEvent.click(await screen.findByLabelText('New Category'));

    await screen.findByText('New Category');
    await waitFor(() => expect(document.querySelector('nav')).toBeFalsy());

    // Closing restores the tab bar.
    const nameInput = screen.getByPlaceholderText('e.g. Smartphones');
    expect(nameInput).toBeInTheDocument();
    fireEvent.click(document.querySelector('.modal-overlay'));
    await waitFor(() => expect(document.querySelector('nav')).toBeTruthy());
  });
});
