import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import App from '../App.jsx';

beforeEach(() => { localStorage.clear(); });

describe('Repair ticket flow', () => {
  it('creates a new repair ticket without throwing', async () => {
    render(<App />);
    await waitFor(() => expect(document.querySelector('nav')).toBeTruthy(), { timeout: 5000 });

    fireEvent.click(screen.getByText('Repairs'));
    const addBtn = await screen.findByText('+');
    fireEvent.click(addBtn);

    const customerLabel = await screen.findByText('CUSTOMER NAME *');
    const customerField = customerLabel.parentElement.querySelector('input');
    fireEvent.change(customerField, { target: { value: 'Test Customer' } });

    const deviceLabel = screen.getByText('DEVICE MODEL *');
    const deviceField = deviceLabel.parentElement.querySelector('input');
    fireEvent.change(deviceField, { target: { value: 'iPhone 12' } });

    const createBtn = screen.getByText(/Create Ticket/i);
    fireEvent.click(createBtn);

    // Should return to the repairs list showing the new ticket, no crash
    await waitFor(() => expect(screen.getByText(/Test Customer/i)).toBeInTheDocument(), { timeout: 3000 });
  });
});

describe('Settings save', () => {
  it('updates and saves the store name without throwing', async () => {
    render(<App />);
    await waitFor(() => expect(document.querySelector('nav')).toBeTruthy(), { timeout: 5000 });

    fireEvent.click(screen.getByText('Settings'));
    const nameField = await screen.findByDisplayValue('SRI DHARANI MOBILES');
    fireEvent.change(nameField, { target: { value: 'Updated Store Name' } });

    const saveBtn = screen.getAllByText(/Save Settings/i)[0];
    fireEvent.click(saveBtn);

    // alert() is used for the success message in this app; jsdom stubs it —
    // just confirm no exception was thrown and the field kept the new value.
    await waitFor(() => expect(screen.getByDisplayValue('Updated Store Name')).toBeInTheDocument());
  });
});
