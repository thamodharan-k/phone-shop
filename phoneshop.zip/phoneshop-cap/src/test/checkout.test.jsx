import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import App from '../App.jsx';

beforeEach(() => { localStorage.clear(); });

describe('Checkout flow', () => {
  it('adds a seeded product to the cart and completes a Cash sale', async () => {
    render(<App />);
    await waitFor(() => expect(document.querySelector('nav')).toBeTruthy(), { timeout: 5000 });

    // Go to Cart, search for a demo product
    fireEvent.click(screen.getByLabelText('Cart'));
    const search = await screen.findByPlaceholderText(/search by name or barcode/i);
    fireEvent.change(search, { target: { value: 'iPhone 15 128GB' } });

    // Wait for the dropdown result and tap it to add to cart
    const result = await waitFor(() => screen.getByText('iPhone 15 128GB Black'), { timeout: 3000 });
    fireEvent.click(result);

    // Bill summary + Done/Print controls should now be present
    await waitFor(() => expect(screen.getByText('Done')).toBeInTheDocument());
    expect(screen.getByText(/Print & Save/i)).toBeInTheDocument();

    // Complete the sale (defaults to Cash)
    fireEvent.click(screen.getByText('Done'));

    // Should navigate to Reports and show the new bill without throwing
    await waitFor(() => expect(screen.getByText(/CART \/ SALES BILLS/i)).toBeInTheDocument(), { timeout: 3000 });
    await waitFor(() => expect(screen.getByText('INV-0001')).toBeInTheDocument(), { timeout: 3000 });
  });
});
