import 'fake-indexeddb/auto';
import '@testing-library/jest-dom/vitest';
import { vi } from 'vitest';

// jsdom doesn't implement matchMedia, ResizeObserver, or canvas 2D context —
// stub the minimum the app touches during normal render/boot.
window.matchMedia = window.matchMedia || (() => ({
  matches: false, addListener: () => {}, removeListener: () => {},
  addEventListener: () => {}, removeEventListener: () => {},
}));

global.ResizeObserver = class {
  observe() {} unobserve() {} disconnect() {}
};

HTMLCanvasElement.prototype.getContext = () => ({
  fillRect: () => {}, drawImage: () => {},
  getImageData: () => ({ data: new Uint8ClampedArray(4) }),
  putImageData: () => {}, clearRect: () => {},
});

window.visualViewport = window.visualViewport || {
  height: 800, width: 400,
  addEventListener: () => {}, removeEventListener: () => {},
};

// Capacitor native plugins have no implementation outside an actual native
// runtime — mock them so importing App.jsx doesn't throw in a plain browser/
// test environment (mirrors how these calls already fail-soft in the app's
// own try/catch blocks when running in a browser).
vi.mock('@capacitor/app', () => ({
  App: { addListener: vi.fn().mockResolvedValue({ remove: vi.fn() }), exitApp: vi.fn() },
}));
vi.mock('@capacitor/keyboard', () => ({
  Keyboard: { addListener: vi.fn().mockResolvedValue({ remove: vi.fn() }) },
}));
vi.mock('@capacitor-community/bluetooth-le', () => ({
  BleClient: {
    initialize: vi.fn().mockResolvedValue(),
    isEnabled: vi.fn().mockResolvedValue(false),
    isLocationEnabled: vi.fn().mockResolvedValue({ value: true }),
    requestLEScan: vi.fn().mockResolvedValue(),
    stopLEScan: vi.fn().mockResolvedValue(),
    connect: vi.fn().mockResolvedValue(),
    disconnect: vi.fn().mockResolvedValue(),
    write: vi.fn().mockResolvedValue(),
  },
}));
