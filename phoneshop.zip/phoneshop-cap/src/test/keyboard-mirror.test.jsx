import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import App from '../App.jsx';

beforeEach(() => { localStorage.clear(); });

describe('Keyboard-typing visibility', () => {
  it('keeps the real input in place (not hidden) and shows a synced mirror above the keyboard while typing', async () => {
    render(<App />);
    await waitFor(() => expect(document.querySelector('nav')).toBeTruthy(), { timeout: 5000 });

    fireEvent.click(screen.getByLabelText('Cart'));
    const search = await screen.findByPlaceholderText(/search by name or barcode/i);
    fireEvent.change(search, { target: { value: 'iPhone 15 128GB' } });
    const result = await waitFor(() => screen.getByText('iPhone 15 128GB Black'), { timeout: 3000 });
    fireEvent.click(result);

    const nameField = await screen.findByPlaceholderText(/customer name/i);

    // Focus it — the real field must remain the same element, still in the
    // document in its normal spot (never removed/replaced/hidden).
    fireEvent.focus(nameField);
    expect(document.body.contains(nameField)).toBe(true);
    expect(nameField.style.display).not.toBe('none');
    expect(nameField.classList.contains('field-floating')).toBe(false); // old approach is gone

    // Type into the real field — mirror bar should appear and sync live
    fireEvent.change(nameField, { target: { value: 'Ravi Kumar' } });
    fireEvent.input(nameField, { target: { value: 'Ravi Kumar' } });

    await waitFor(() => {
      const mirror = document.querySelector('.field-mirror');
      expect(mirror).toBeTruthy();
      expect(mirror.style.display).not.toBe('none');
      expect(mirror.querySelector('.field-mirror-value').textContent).toBe('Ravi Kumar');
    });

    // The original field is still showing the same text at the same time
    expect(nameField.value).toBe('Ravi Kumar');

    // Blur — mirror should hide, original field remains untouched in the DOM
    fireEvent.blur(nameField);
    await new Promise(r => setTimeout(r, 150));
    const mirror = document.querySelector('.field-mirror');
    expect(mirror.style.display).toBe('none');
    expect(document.body.contains(nameField)).toBe(true);
  });
});
