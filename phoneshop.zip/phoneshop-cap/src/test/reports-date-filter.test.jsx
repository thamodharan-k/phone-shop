import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import App from '../App.jsx';

beforeEach(() => { localStorage.clear(); });

describe('Reports date filter', () => {
  it('applies filtering as soon as only a From date is picked (regression: previously required both From and To)', async () => {
    render(<App />);
    await waitFor(() => expect(document.querySelector('nav')).toBeTruthy(), { timeout: 5000 });

    fireEvent.click(screen.getByText('Settings')); // just to get off Dashboard first
    fireEvent.click(screen.getByText('Home'));

    // Navigate to Reports via Dashboard's "View Reports" or similar isn't guaranteed —
    // go straight there via the nav helper exposed through browser history instead:
    window.history.pushState({}, '', '#/reports');
    fireEvent(window, new PopStateEvent('popstate'));

    const fromInputs = await screen.findAllByDisplayValue('');
    // The date inputs are type="date" with no display value initially; locate via label text instead
    const fromLabel = screen.getByText(/FROM/i);
    expect(fromLabel).toBeInTheDocument();

    const today = new Date().toISOString().slice(0,10);
    const dateInputs = document.querySelectorAll('input[type="date"]');
    expect(dateInputs.length).toBe(2);

    fireEvent.change(dateInputs[0], { target: { value: today } });

    // Should now show the single-date hint, confirming filtering is active with just From set
    await waitFor(() => expect(screen.getByText(/Showing bills for/i)).toBeInTheDocument(), { timeout: 3000 });
  });
});
