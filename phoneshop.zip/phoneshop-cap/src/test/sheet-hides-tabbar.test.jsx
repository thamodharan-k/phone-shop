import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import App from '../App.jsx';
import { createInvoice } from '../db/database.js';

beforeEach(() => { localStorage.clear(); });

describe('Full-screen sheets hide the tab bar (regression: Print Bill button was hidden behind it)', () => {
  it('unmounts the nav/tab bar while a bill-detail sheet is open, and restores it on close', async () => {
    render(<App />);
    // App mounting also runs initDb() internally — wait for the tab bar,
    // which only appears once ready, as a signal the DB is initialized.
    await waitFor(() => expect(document.querySelector('nav')).toBeTruthy(), { timeout: 5000 });

    // Now it's safe to seed an invoice for Reports to display.
    await createInvoice(
      [{ product_id: 'no-such-product', name: 'Test Item', price: 100, qty: 1 }],
      { customer_name: 'Walk-in', customer_phone: '', payment_mode: 'Cash', discount_amount: 0, gst_rate: 0 }
    );

    window.history.pushState({}, '', '#/reports');
    fireEvent(window, new PopStateEvent('popstate'));

    const billButton = await screen.findByText(/INV-0001/i, {}, { timeout: 3000 });
    fireEvent.click(billButton.closest('button'));

    // Once the sheet is open, the tab bar (a <nav>) must not be in the document at all —
    // guarantees it can never render on top of / bleed through the sheet regardless of
    // how a given WebView stacks `position: fixed` elements.
    await waitFor(() => expect(document.querySelector('nav')).toBeFalsy());

    // The Print Bill button must be present and reachable now that the tab bar is gone.
    expect(screen.getByText(/print bill/i)).toBeInTheDocument();

    // Closing the sheet restores the tab bar.
    fireEvent.click(screen.getByText('✕'));
    await waitFor(() => expect(document.querySelector('nav')).toBeTruthy());
  });
});
