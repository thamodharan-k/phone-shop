import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import App from '../App.jsx';

// Each test gets a fresh IndexedDB (fake-indexeddb resets per-file, but we
// also clear localStorage so the factory-reset flag doesn't leak between runs).
beforeEach(() => {
  localStorage.clear();
});

describe('App boot', () => {
  it('initializes the DB, seeds demo data, and reaches the Dashboard', async () => {
    render(<App />);
    // Splash -> ready -> Dashboard. Give initDb() + seeding time to complete.
    await waitFor(() => expect(screen.getByText(/SRI DHARANI MOBILES/i)).toBeInTheDocument(), { timeout: 5000 });
  });
});

describe('Main tab navigation', () => {
  it('renders Home, Inventory, Cart, Repairs, Settings without throwing', async () => {
    render(<App />);
    await waitFor(() => expect(document.querySelector('nav')).toBeTruthy(), { timeout: 5000 });

    const tabs = ['Home', 'Inventory', 'Repairs', 'Settings'];
    for (const label of tabs) {
      const tab = screen.getByText(label);
      fireEvent.click(tab);
      // give React + async data loads a tick
      await new Promise(r => setTimeout(r, 150));
    }

    // Cart is the center FAB (aria-label, not a text tab)
    const cartBtn = screen.getByLabelText('Cart');
    fireEvent.click(cartBtn);
    await new Promise(r => setTimeout(r, 150));
  });
});
