# PhoneShop POS — Capacitor Android Build Guide

## Stack
- Frontend: React + Vite (web)
- Bridge: Capacitor 7
- Database: IndexedDB (offline, no server needed)
- BT Printer: @capacitor-community/bluetooth-le + ESC/POS bytes

---

## Build Steps

### 1. Install Node.js (v18+)
Download from nodejs.org

### 2. Install dependencies
```
cd phoneshop-cap
npm install
```

### 3. Build web app
```
npm run build
```

### 4. Sync to Android
```
npx cap sync android
```

### 5. Open in Android Studio
```
npx cap open android
```
OR manually open the `android/` folder in Android Studio.

### 6. Build APK
Build → Build Bundle(s)/APK(s) → Build APK(s)

APK location:
`android/app/build/outputs/apk/debug/app-debug.apk`

---

## Bluetooth Printer Setup (in the app)
1. Power on your ESC/POS thermal printer
2. Settings → Hardware → Scan & Pair
3. Select your printer from the list
4. Done — it saves automatically

Supported: Any BLE ESC/POS thermal printer (58mm / 80mm)

---

## Permissions (already in AndroidManifest.xml)
- BLUETOOTH_SCAN, BLUETOOTH_CONNECT (Android 12+)
- BLUETOOTH, BLUETOOTH_ADMIN (Android 6-11)
- ACCESS_FINE_LOCATION (BT scanning)
- CAMERA (barcode scanner)
